import { ClientAccount } from '../types';

export type AccountStatus = 'paid' | 'due' | 'critical' | 'excused' | 'terminated';

/** Mirrors the server-side computeStatus() in server.ts so the UI can react
 * instantly without waiting on a round-trip after local state changes. */
export function computeAccountStatus(client: ClientAccount): AccountStatus {
  if (client.terminated) return 'terminated';
  const now = new Date();
  const monthKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  if (client.payments && client.payments[monthKey]) return 'paid';
  if (client.excusedMonths && client.excusedMonths.includes(monthKey)) return 'excused';
  const grace = client.graceDays ?? 5;
  if (now.getDate() > grace) return 'critical';
  return 'due';
}

export const STATUS_LABEL: Record<AccountStatus, { en: string; ar: string }> = {
  paid: { en: 'Paid', ar: 'مدفوع' },
  due: { en: 'Payment due', ar: 'الدفع مستحق' },
  critical: { en: 'Overdue — grace period passed', ar: 'متأخر — انتهت مهلة السماح' },
  excused: { en: 'Excused this month', ar: 'معفى هذا الشهر' },
  terminated: { en: 'Terminated', ar: 'منتهي' },
};

export const STATUS_COLOR: Record<AccountStatus, string> = {
  paid: '#34d399',
  due: '#fbbf24',
  critical: '#fb7185',
  excused: '#a5b4fc',
  terminated: '#71717a',
};
