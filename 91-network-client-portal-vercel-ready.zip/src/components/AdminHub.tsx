import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { formatEGP } from '../utils/currency';
import { ContentDeliverable, RequestItem } from '../types';
import { computeAccountStatus, STATUS_LABEL, STATUS_COLOR } from '../utils/accountStatus';

export const AdminHub: React.FC = () => {
  const {
    locale,
    clientAccounts,
    activeClientId,
    setActiveClientId,
    currentClient,
    clientUpdates,
    addClientUpdate,
    deliverables,
    addDeliverable,
    updateDeliverableStatus,
    requests,
    updateRequestStatus,
    adminEmail,
    setAdminEmail,
    dispatchBriefToEmail,
    showToast,
    setUserRole,
    addClientAccount,
    updateClientAccount,
    deleteClientAccount,
    toggleClientStatus,
    updateClientPayment
  } = useApp();

  const isAr = locale === 'ar';
  const [activeAdminTab, setActiveAdminTab] = useState<
    'content' | 'broadcast' | 'requests' | 'users' | 'backend'
  >('users');

  // Form states for adding a new Client User
  const [showAddUserModal, setShowAddUserModal] = useState(false);
  const [newClientName, setNewClientName] = useState('');
  const [newClientContact, setNewClientContact] = useState('');
  const [newClientEmail, setNewClientEmail] = useState('');
  const [newClientPhone, setNewClientPhone] = useState('+20 100 ');
  const [newClientRetainerEGP, setNewClientRetainerEGP] = useState(750000);
  const [newClientQuota, setNewClientQuota] = useState(14);
  const [newClientTier, setNewClientTier] = useState('Tier B — Growth Retainer');
  const [newClientPasskey, setNewClientPasskey] = useState('');

  // Backend inspector state
  const [backendStatus, setBackendStatus] = useState<any>({
    status: 'online',
    engine: 'Express 4.21 + Node.js',
    port: 3000,
    activeNodes: 3,
    currency: 'EGP'
  });
  const [liveEmailLogs, setLiveEmailLogs] = useState<any[]>([]);

  // Fetch backend status and email logs on mount or tab switch
  React.useEffect(() => {
    fetch('/api/admin/system')
      .then((res) => res.json())
      .then((data) => setBackendStatus(data))
      .catch(() => {});

    fetch('/api/email-logs')
      .then((res) => res.json())
      .then((data) => setLiveEmailLogs(data))
      .catch(() => {});
  }, [activeAdminTab]);

  // Form states for adding deliverable
  const [showAddModal, setShowAddModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newType, setNewType] = useState<'reel' | 'carousel' | 'tiktok'>('reel');
  const [newPlatform, setNewPlatform] = useState('Instagram Reels & TikTok');
  const [newDate, setNewDate] = useState('Nov 05, 2024');
  const [newTime, setNewTime] = useState('06:00 PM GST');
  const [newDpNote, setNewDpNote] = useState('Kodak 5219 calibrated LUT · 4K 10-bit');

  // Form states for broadcasting update
  const [broadcastTarget, setBroadcastTarget] = useState<string>('client-lumen');
  const [broadcastTitle, setBroadcastTitle] = useState('');
  const [broadcastBody, setBroadcastBody] = useState('');
  const [broadcastType, setBroadcastType] = useState<
    'production' | 'creative' | 'dispatch' | 'billing'
  >('production');

  // Admin email edit modal state
  const [isEditingEmail, setIsEditingEmail] = useState(false);
  const [tempEmail, setTempEmail] = useState(adminEmail);

  // Total retainers in EGP
  const totalRetainerEGP = clientAccounts.reduce(
    (sum, c) => sum + c.retainerAmountEGP,
    0
  );

  const handleCreateDeliverable = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) {
      showToast(isAr ? 'يرجى إدخال عنوان المخرجة' : 'Please enter deliverable title');
      return;
    }

    addDeliverable({
      title: newTitle,
      titleAr: newTitle,
      type: newType,
      platform: newPlatform,
      scheduledDate: newDate,
      scheduledTime: newTime,
      dpNote: newDpNote,
      clientId: activeClientId,
      status: 'action_required'
    });

    setNewTitle('');
    setShowAddModal(false);
  };

  const handlePublishBroadcast = (e: React.FormEvent) => {
    e.preventDefault();
    if (!broadcastTitle.trim() || !broadcastBody.trim()) {
      showToast(
        isAr
          ? 'يرجى كتابة عنوان وتفاصيل التحديث'
          : 'Please enter title and update details'
      );
      return;
    }

    addClientUpdate({
      clientId: broadcastTarget,
      title: broadcastTitle,
      titleAr: broadcastTitle,
      body: broadcastBody,
      bodyAr: broadcastBody,
      author: 'SEIF ABD ELAZIZ',
      authorRole: 'Founder & CEO / Executive Creative Director · 91 Network',
      type: broadcastType,
      priority: 'urgent'
    });

    setBroadcastTitle('');
    setBroadcastBody('');
  };

  return (
    <div className="pt-20 pb-24 px-4 max-w-xl mx-auto space-y-5">
      {/* Executive Admin Profile Header */}
      <div className="p-4 rounded-2xl bg-gradient-to-b from-[#201f21] to-[#1b1b1d] border border-[#ff7bb4]/40 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-36 h-36 bg-[#ff7bb4]/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="flex items-start justify-between relative z-10">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-[#ff7bb4]/20 border border-[#ff7bb4]/40 flex items-center justify-center text-[#ffb0cd] font-mono font-bold text-base shadow-inner">
              91
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="px-2 py-0.5 rounded-full bg-[#ff7bb4]/20 border border-[#ff7bb4]/40 text-[10px] font-mono font-bold text-[#ffb0cd] tracking-wider uppercase">
                  {isAr ? 'المؤسس والرئيس التنفيذي' : 'FOUNDER & CEO · SUPER ADMIN'}
                </span>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              </div>
              <h1 className="font-headline text-lg font-bold text-[#e5e1e4] mt-0.5">
                {isAr ? 'سيف عبد العزيز — SEIF ABD ELAZIZ' : 'SEIF ABD ELAZIZ — Founder & CEO'}
              </h1>
              <p className="text-[11px] text-[#dbc0c7]">
                {isAr ? 'إدارة محتوى جميع العملاء، الميزانيات بالجنيه المصري، واستلام الطلبات' : 'Managing all client retainers, content pipelines, and AI brief dispatches'}
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              setUserRole('client');
              showToast(isAr ? 'تم التبديل إلى بوابة العميل' : 'Switched to Client Portal View');
            }}
            className="px-2.5 py-1 rounded-lg bg-[#2a2a2c] hover:bg-[#3a3a3d] text-[10px] font-mono text-[#dbc0c7] hover:text-[#e5e1e4] border border-[#3a3a3d] transition-all flex items-center gap-1 cursor-pointer"
            title="Preview as Client"
          >
            <span className="material-symbols-outlined text-[14px]">visibility</span>
            <span>{isAr ? 'معاينة كعميل' : 'Client View'}</span>
          </button>
        </div>

        {/* Email Dispatch Info Banner */}
        <div className="mt-3.5 p-2.5 rounded-xl bg-[#131315]/80 border border-[#2a2a2c] flex flex-col sm:flex-row sm:items-center justify-between text-xs gap-2">
          <div className="flex items-center gap-2 overflow-hidden">
            <span className="material-symbols-outlined text-[18px] text-[#ff7bb4] flex-shrink-0">mark_email_read</span>
            <div className="truncate">
              <span className="text-[10px] font-mono uppercase text-[#a38a92] block">
                {isAr ? 'عناوين بريد استلام طلبات الذكاء الاصطناعي للإدارة' : 'Direct AI Chat Brief Destination Emails'}
              </span>
              <div className="flex flex-wrap items-center gap-1.5 mt-0.5">
                <span className="px-1.5 py-0.5 rounded bg-[#201f21] border border-[#ff7bb4]/40 font-mono text-[#ffb0cd] font-bold text-[11px]">
                  ceo@91network.online
                </span>
                <span className="px-1.5 py-0.5 rounded bg-[#201f21] border border-[#ff7bb4]/30 font-mono text-[#dbc0c7] font-semibold text-[11px]">
                  seifabdelaziz@91network.online
                </span>
              </div>
            </div>
          </div>
          <button
            onClick={() => {
              setTempEmail(adminEmail);
              setIsEditingEmail(!isEditingEmail);
            }}
            className="px-2.5 py-1 self-end sm:self-auto rounded-lg bg-[#201f21] hover:bg-[#2a2a2c] text-[10px] font-mono text-[#dbc0c7] border border-[#2a2a2c] flex-shrink-0 transition-colors cursor-pointer"
          >
            {isEditingEmail ? (isAr ? 'إلغاء' : 'Cancel') : (isAr ? 'تعديل البريد' : 'Edit Target')}
          </button>
        </div>

        {/* Email Edit Row */}
        {isEditingEmail && (
          <div className="mt-2 p-2.5 rounded-xl bg-[#201f21] border border-[#ff7bb4]/30 space-y-2">
            <label className="text-[11px] text-[#dbc0c7] block">
              {isAr ? 'أدخل بريدك الإلكتروني لاستلام الطلبات:' : 'Set receiving email for AI requests:'}
            </label>
            <div className="flex items-center gap-2">
              <input
                type="email"
                value={tempEmail}
                onChange={(e) => setTempEmail(e.target.value)}
                className="flex-1 h-8 rounded-lg bg-[#131315] border border-[#2a2a2c] px-2.5 text-xs text-[#e5e1e4] font-mono focus:outline-none focus:border-[#ff7bb4]"
                placeholder="youremail@domain.com"
              />
              <button
                onClick={() => {
                  if (tempEmail.includes('@')) {
                    setAdminEmail(tempEmail);
                    setIsEditingEmail(false);
                    showToast(
                      isAr
                        ? `تم تحديث بريد الاستلام إلى: ${tempEmail}`
                        : `Admin receiving email set to: ${tempEmail}`
                    );
                  } else {
                    showToast(isAr ? 'يرجى إدخال بريد صحيح' : 'Invalid email address');
                  }
                }}
                className="h-8 px-3 rounded-lg bg-gradient-to-r from-[#ff7bb4] to-[#ffb0cd] text-[#780846] text-xs font-mono font-bold hover:opacity-90"
              >
                {isAr ? 'حفظ' : 'Save'}
              </button>
            </div>
          </div>
        )}

        {/* Executive Stats in EGP */}
        <div className="mt-3.5 grid grid-cols-4 gap-2 text-center pt-3 border-t border-[#2a2a2c]">
          <div className="p-2 rounded-xl bg-[#131315]/50 border border-[#2a2a2c]/60">
            <div className="text-[9px] font-mono text-[#a38a92] uppercase">
              {isAr ? 'إجمالي الرتينر' : 'MONTHLY INFLOW'}
            </div>
            <div className="font-mono text-xs font-bold text-[#ffb0cd] mt-0.5">
              {formatEGP(totalRetainerEGP, locale)}
            </div>
          </div>

          <div className="p-2 rounded-xl bg-[#131315]/50 border border-[#2a2a2c]/60">
            <div className="text-[9px] font-mono text-[#a38a92] uppercase">
              {isAr ? 'العملاء' : 'CLIENTS'}
            </div>
            <div className="font-mono text-xs font-bold text-[#e5e1e4] mt-0.5">
              {clientAccounts.length} {isAr ? 'حسابات' : 'Active'}
            </div>
          </div>

          <div className="p-2 rounded-xl bg-[#131315]/50 border border-[#2a2a2c]/60">
            <div className="text-[9px] font-mono text-[#a38a92] uppercase">
              {isAr ? 'مخرجات قيد المراجعة' : 'REVIEWS'}
            </div>
            <div className="font-mono text-xs font-bold text-amber-300 mt-0.5">
              {deliverables.filter((d) => d.status === 'action_required').length} {isAr ? 'تتطلب قرار' : 'Pending'}
            </div>
          </div>

          <div className="p-2 rounded-xl bg-[#131315]/50 border border-[#2a2a2c]/60">
            <div className="text-[9px] font-mono text-[#a38a92] uppercase">
              {isAr ? 'طلبات جديدة' : 'REQUESTS'}
            </div>
            <div className="font-mono text-xs font-bold text-emerald-400 mt-0.5">
              {requests.length} {isAr ? 'طلب' : 'In Intake'}
            </div>
          </div>
        </div>
      </div>

      {/* Client Quick Switcher Bar */}
      <div className="p-3.5 rounded-2xl bg-[#1b1b1d] border border-[#2a2a2c] space-y-2.5">
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-mono uppercase tracking-wider text-[#a38a92]">
            {isAr ? 'حدد العميل لإدارة محتواه وتحديثاته' : 'SELECT CLIENT TO MANAGE & UPDATE'}
          </span>
          <span className="text-[10px] font-mono text-[#ffb0cd]">
            {isAr ? 'العملة بالجنيه المصري (EGP)' : 'All accounts in EGP'}
          </span>
        </div>

        <div className="grid grid-cols-2 gap-2">
          {clientAccounts.map((client) => {
            const isSelected = activeClientId === client.id;
            return (
              <button
                key={client.id}
                onClick={() => {
                  setActiveClientId(client.id);
                  showToast(
                    isAr
                      ? `تم تحويل التحكم الإداري إلى: ${client.nameAr}`
                      : `Admin scope switched to: ${client.name}`
                  );
                }}
                className={`p-2.5 rounded-xl text-left border transition-all flex flex-col justify-between cursor-pointer ${
                  isSelected
                    ? 'bg-[#201f21] border-[#ff7bb4] shadow-md'
                    : 'bg-[#131315]/60 border-[#2a2a2c] hover:border-[#554248]'
                }`}
              >
                <div className="flex items-center justify-between w-full">
                  <span className="text-xs font-bold text-[#e5e1e4] truncate">
                    {isAr ? client.nameAr : client.name}
                  </span>
                  {isSelected && (
                    <span className="w-2 h-2 rounded-full bg-[#ff7bb4]"></span>
                  )}
                </div>

                <div className="text-[10px] text-[#a38a92] mt-0.5 truncate">
                  {isAr ? client.industryAr : client.industry}
                </div>

                <div className="mt-2 pt-1.5 border-t border-[#2a2a2c]/60 flex items-center justify-between text-[10px] font-mono">
                  <span className="text-[#ffb0cd] font-bold">
                    {formatEGP(client.retainerAmountEGP, locale)}/mo
                  </span>
                  <span className="text-[#dbc0c7]">
                    {client.activeDeliverablesCount}/{client.totalDeliverablesQuota} quota
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Admin Operations Sub-Navigation */}
      <div className="flex items-center gap-1.5 p-1 rounded-xl bg-[#1b1b1d] border border-[#2a2a2c] overflow-x-auto no-scrollbar">
        {[
          { id: 'users', labelEn: 'Users & Clients', labelAr: 'العملاء والمستخدمين', icon: 'manage_accounts' },
          { id: 'content', labelEn: 'Manage Content', labelAr: 'إدارة المحتوى', icon: 'movie_filter' },
          { id: 'broadcast', labelEn: 'Broadcast Updates', labelAr: 'نشر تحديثات', icon: 'campaign' },
          { id: 'requests', labelEn: 'AI & Email Requests', labelAr: 'طلبات البريد والذكاء', icon: 'mark_email_unread' },
          { id: 'backend', labelEn: 'Backend & Server', labelAr: 'الخادم والنظام', icon: 'dns' }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveAdminTab(tab.id as any)}
            className={`flex-1 py-2 px-2 rounded-lg text-xs font-mono flex items-center justify-center gap-1 transition-all whitespace-nowrap cursor-pointer ${
              activeAdminTab === tab.id
                ? 'bg-[#2a2a2c] text-[#ffb0cd] font-bold shadow-sm border border-[#ff7bb4]/30'
                : 'text-[#dbc0c7] hover:text-[#e5e1e4]'
            }`}
          >
            <span className="material-symbols-outlined text-[15px]">{tab.icon}</span>
            <span>{isAr ? tab.labelAr : tab.labelEn}</span>
          </button>
        ))}
      </div>

      {/* TAB 1: MANAGE CONTENT & DELIVERABLES */}
      {activeAdminTab === 'content' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-headline text-sm font-bold text-[#e5e1e4]">
                {isAr
                  ? `مخرجات ${currentClient.nameAr}`
                  : `Deliverables Pipeline · ${currentClient.name}`}
              </h2>
              <p className="text-[11px] text-[#a38a92]">
                {isAr
                  ? 'إضافة محتوى جديد، تدقيق الألوان، واعتماد مخرجات العميل'
                  : 'Add reels, change review statuses, and attach DP notes'}
              </p>
            </div>
            <button
              onClick={() => setShowAddModal(!showAddModal)}
              className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-[#ff7bb4] to-[#ffb0cd] text-[#780846] text-xs font-headline font-bold hover:opacity-95 shadow-sm transition-all flex items-center gap-1 cursor-pointer"
            >
              <span className="material-symbols-outlined text-[16px]">add</span>
              <span>{isAr ? 'إضافة مخرجة' : 'New Deliverable'}</span>
            </button>
          </div>

          {/* Inline Add Deliverable Modal */}
          {showAddModal && (
            <form
              onSubmit={handleCreateDeliverable}
              className="p-4 rounded-2xl bg-[#1b1b1d] border border-[#ff7bb4]/40 space-y-3 shadow-xl"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-[#e5e1e4]">
                  {isAr ? 'إنشاء مخرجة محتوى جديدة للعميل' : 'Upload New Deliverable to Client Pipeline'}
                </span>
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="text-xs text-[#a38a92] hover:text-[#e5e1e4]"
                >
                  ✕
                </button>
              </div>

              <div>
                <label className="text-[11px] text-[#dbc0c7] block mb-1">
                  {isAr ? 'عنوان المخرجة الإعلانية / الفيديو' : 'Deliverable Title / Campaign Item'}
                </label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. FW24 Raw Silk Lookbook 4K Reel #03"
                  className="w-full h-9 rounded-xl bg-[#201f21] border border-[#2a2a2c] px-3 text-xs text-[#e5e1e4] focus:outline-none focus:border-[#ff7bb4]"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[11px] text-[#dbc0c7] block mb-1">
                    {isAr ? 'النوع' : 'Format'}
                  </label>
                  <select
                    value={newType}
                    onChange={(e) => setNewType(e.target.value as any)}
                    className="w-full h-9 rounded-xl bg-[#201f21] border border-[#2a2a2c] px-2 text-xs text-[#e5e1e4] focus:outline-none"
                  >
                    <option value="reel">4K Video Reel (9:16)</option>
                    <option value="carousel">Editorial Carousel (4:5)</option>
                    <option value="tiktok">TikTok Cinematic Ad</option>
                  </select>
                </div>

                <div>
                  <label className="text-[11px] text-[#dbc0c7] block mb-1">
                    {isAr ? 'المنصة' : 'Platform'}
                  </label>
                  <input
                    type="text"
                    value={newPlatform}
                    onChange={(e) => setNewPlatform(e.target.value)}
                    className="w-full h-9 rounded-xl bg-[#201f21] border border-[#2a2a2c] px-3 text-xs text-[#e5e1e4] focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[11px] text-[#dbc0c7] block mb-1">
                    {isAr ? 'تاريخ النشر المجدول' : 'Scheduled Date'}
                  </label>
                  <input
                    type="text"
                    value={newDate}
                    onChange={(e) => setNewDate(e.target.value)}
                    className="w-full h-9 rounded-xl bg-[#201f21] border border-[#2a2a2c] px-3 text-xs text-[#e5e1e4] font-mono focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-[11px] text-[#dbc0c7] block mb-1">
                    {isAr ? 'التوقيت' : 'Time'}
                  </label>
                  <input
                    type="text"
                    value={newTime}
                    onChange={(e) => setNewTime(e.target.value)}
                    className="w-full h-9 rounded-xl bg-[#201f21] border border-[#2a2a2c] px-3 text-xs text-[#e5e1e4] font-mono focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-[11px] text-[#dbc0c7] block mb-1">
                  {isAr ? 'ملاحظات مدير التصوير وتدقيق الألوان (DP Notes)' : 'DP & Color Grading Notes'}
                </label>
                <input
                  type="text"
                  value={newDpNote}
                  onChange={(e) => setNewDpNote(e.target.value)}
                  className="w-full h-9 rounded-xl bg-[#201f21] border border-[#2a2a2c] px-3 text-xs text-[#e5e1e4] focus:outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-[#2a2a2c]">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 rounded-lg bg-[#201f21] text-xs text-[#dbc0c7] hover:bg-[#2a2a2c]"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-gradient-to-r from-[#ff7bb4] to-[#ffb0cd] text-[#780846] text-xs font-bold hover:opacity-90"
                >
                  {isAr ? 'حفظ ونشر للمراجعة' : 'Add & Send for Review'}
                </button>
              </div>
            </form>
          )}

          {/* Deliverables List with Status Controls */}
          <div className="space-y-2.5">
            {deliverables.map((del) => (
              <div
                key={del.id}
                className="p-3 rounded-2xl bg-[#1b1b1d] border border-[#2a2a2c] flex flex-col gap-2.5 text-xs shadow-md"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-[#ffb0cd] font-bold">{del.code}</span>
                    <span className="px-2 py-0.5 rounded-full bg-[#201f21] text-[#dbc0c7] font-mono text-[10px]">
                      {del.platform}
                    </span>
                  </div>

                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                      del.status === 'action_required'
                        ? 'bg-[#ff7bb4]/20 text-[#ffb0cd] border border-[#ff7bb4]/30'
                        : del.status === 'scheduled'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        : del.status === 'in_revision'
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                        : 'bg-purple-500/20 text-purple-300'
                    }`}
                  >
                    {del.status.toUpperCase()}
                  </span>
                </div>

                <div className="font-bold text-[#e5e1e4]">
                  {isAr ? del.titleAr : del.title}
                </div>

                {del.dpNote && (
                  <div className="p-2 rounded-xl bg-[#201f21] text-[11px] text-[#dbc0c7] border border-[#2a2a2c]/60 flex items-center gap-2">
                    <span className="material-symbols-outlined text-[15px] text-[#ff7bb4]">palette</span>
                    <span>{isAr ? del.dpNoteAr || del.dpNote : del.dpNote}</span>
                  </div>
                )}

                {/* Admin Status Toggles */}
                <div className="pt-2 border-t border-[#2a2a2c] flex items-center justify-between">
                  <span className="text-[10px] font-mono text-[#a38a92]">
                    {del.scheduledDate} · {del.scheduledTime}
                  </span>

                  <div className="flex items-center gap-1.5">
                    {del.status !== 'action_required' && (
                      <button
                        onClick={() => updateDeliverableStatus(del.id, 'action_required')}
                        className="px-2 py-1 rounded bg-[#201f21] hover:bg-[#2a2a2c] text-[#ffb0cd] text-[10px] font-mono transition-colors"
                      >
                        {isAr ? 'طلب مراجعة العميل' : 'Send to Client'}
                      </button>
                    )}
                    {del.status !== 'scheduled' && (
                      <button
                        onClick={() => updateDeliverableStatus(del.id, 'scheduled')}
                        className="px-2 py-1 rounded bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 text-[10px] font-mono transition-colors"
                      >
                        {isAr ? 'اعتماد وجدولة' : 'Approve & Schedule'}
                      </button>
                    )}
                    {del.status !== 'published' && (
                      <button
                        onClick={() => updateDeliverableStatus(del.id, 'published')}
                        className="px-2 py-1 rounded bg-[#2a2a2c] hover:bg-[#3a3a3d] text-[#e5e1e4] text-[10px] font-mono transition-colors"
                      >
                        {isAr ? 'تم النشر' : 'Mark Published'}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: BROADCAST CLIENT UPDATES */}
      {activeAdminTab === 'broadcast' && (
        <div className="space-y-4">
          <div>
            <h2 className="font-headline text-sm font-bold text-[#e5e1e4]">
              {isAr ? 'بث التحديثات المباشرة وإبقاء العملاء على اطلاع' : 'Broadcast Live Updates to Clients'}
            </h2>
            <p className="text-[11px] text-[#a38a92]">
              {isAr
                ? 'نشر تحديثات فورية تظهر في لوحة تحكم العميل وإشعاراته'
                : 'Post instant production bulletins, LUT calibrations, and call sheet notices'}
            </p>
          </div>

          <form
            onSubmit={handlePublishBroadcast}
            className="p-4 rounded-2xl bg-[#1b1b1d] border border-[#2a2a2c] space-y-3 shadow-lg"
          >
            <div>
              <label className="text-[11px] text-[#dbc0c7] block mb-1">
                {isAr ? 'العميل المستهدف' : 'Target Client Portal'}
              </label>
              <select
                value={broadcastTarget}
                onChange={(e) => setBroadcastTarget(e.target.value)}
                className="w-full h-9 rounded-xl bg-[#201f21] border border-[#2a2a2c] px-3 text-xs text-[#e5e1e4] focus:outline-none focus:border-[#ff7bb4]"
              >
                <option value="all">{isAr ? 'جميع العملاء (تعميم الوكالة)' : 'All Clients (Agency Network Broadcast)'}</option>
                {clientAccounts.map((c) => (
                  <option key={c.id} value={c.id}>
                    {isAr ? c.nameAr : c.name} ({formatEGP(c.retainerAmountEGP, locale)}/mo)
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[11px] text-[#dbc0c7] block mb-1">
                  {isAr ? 'نوع التحديث' : 'Category'}
                </label>
                <select
                  value={broadcastType}
                  onChange={(e) => setBroadcastType(e.target.value as any)}
                  className="w-full h-9 rounded-xl bg-[#201f21] border border-[#2a2a2c] px-2 text-xs text-[#e5e1e4] focus:outline-none"
                >
                  <option value="production">Production & Logistics</option>
                  <option value="creative">Color Grade & Master LUT</option>
                  <option value="dispatch">AI Email Dispatch</option>
                  <option value="billing">Retainer & Ledger in EGP</option>
                </select>
              </div>

              <div>
                <label className="text-[11px] text-[#dbc0c7] block mb-1">
                  {isAr ? 'الأولوية' : 'Urgency'}
                </label>
                <span className="w-full h-9 rounded-xl bg-[#201f21] border border-[#2a2a2c] px-3 text-xs text-[#ffb0cd] flex items-center font-mono">
                  LIVE PORTAL BROADCAST
                </span>
              </div>
            </div>

            <div>
              <label className="text-[11px] text-[#dbc0c7] block mb-1">
                {isAr ? 'عنوان التحديث' : 'Update Headline'}
              </label>
              <input
                type="text"
                value={broadcastTitle}
                onChange={(e) => setBroadcastTitle(e.target.value)}
                placeholder="e.g. Warehouse 4 shoot master footage uploaded to Raw Vault"
                className="w-full h-9 rounded-xl bg-[#201f21] border border-[#2a2a2c] px-3 text-xs text-[#e5e1e4] focus:outline-none focus:border-[#ff7bb4]"
              />
            </div>

            <div>
              <label className="text-[11px] text-[#dbc0c7] block mb-1">
                {isAr ? 'نص التحديث وملاحظات الطاقم' : 'Update Body & Team Brief'}
              </label>
              <textarea
                value={broadcastBody}
                onChange={(e) => setBroadcastBody(e.target.value)}
                rows={3}
                placeholder="Detailed operational update for client visibility..."
                className="w-full rounded-xl bg-[#201f21] border border-[#2a2a2c] p-3 text-xs text-[#e5e1e4] focus:outline-none focus:border-[#ff7bb4]"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#ff7bb4] to-[#ffb0cd] text-[#780846] text-xs font-headline font-bold hover:opacity-95 shadow-md flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <span className="material-symbols-outlined text-[17px]">send</span>
              <span>{isAr ? 'نشر التحديث وإشعار العميل فوراً' : 'Broadcast Update to Client'}</span>
            </button>
          </form>

          {/* Broadcasts History */}
          <div className="space-y-2">
            <div className="text-[10px] font-mono uppercase text-[#a38a92] tracking-wider">
              {isAr ? 'سجل التحديثات المنشورة' : 'LIVE BROADCASTS LOG'}
            </div>
            {clientUpdates.map((upd) => (
              <div
                key={upd.id}
                className="p-3 rounded-xl bg-[#1b1b1d] border border-[#2a2a2c] text-xs space-y-1"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[#e5e1e4]">
                    {isAr ? upd.titleAr : upd.title}
                  </span>
                  <span className="text-[10px] font-mono text-[#a38a92]">{upd.timestamp}</span>
                </div>
                <p className="text-[11px] text-[#dbc0c7]">{isAr ? upd.bodyAr : upd.body}</p>
                <div className="text-[10px] font-mono text-[#ffb0cd] pt-1">
                  {upd.author} · {upd.authorRole}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: AI & EMAIL REQUESTS */}
      {activeAdminTab === 'requests' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-headline text-sm font-bold text-[#e5e1e4]">
                {isAr ? 'طلبات الذكاء الاصطناعي ومرسلات البريد' : 'AI Requests & Email Dispatch Desk'}
              </h2>
              <p className="text-[11px] text-[#a38a92]">
                {isAr
                  ? `الطلبات الموجهة مباشرة إلى بريدك: ${adminEmail}`
                  : `Briefs synthesized via AI chat and dispatched to: ${adminEmail}`}
              </p>
            </div>

            <button
              onClick={() =>
                dispatchBriefToEmail({
                  title: 'Fall Campaign Lookbook Reel (Test Dispatch)',
                  deliverablesSummary: '1x 4K Cinematic Reel + 2x Editorial Stills',
                  cameraGear: 'Sony FX6 · Cooke Anamorphic Lenses',
                  aesthetic: 'Kodak 5219 35mm Grain',
                  retainerImpact: `-1 Deliverable (${formatEGP(currentClient.retainerAmountEGP, locale)}/mo)`
                })
              }
              className="px-2.5 py-1.5 rounded-lg bg-[#201f21] hover:bg-[#2a2a2c] text-xs font-mono text-[#ffb0cd] border border-[#ff7bb4]/30 flex items-center gap-1 cursor-pointer"
            >
              <span className="material-symbols-outlined text-[15px]">send_and_archive</span>
              <span>{isAr ? 'تجربة إرسال للبريد' : 'Test Email Dispatch'}</span>
            </button>
          </div>

          <div className="space-y-2.5">
            {requests.map((req) => (
              <div
                key={req.id}
                className="p-3.5 rounded-2xl bg-[#1b1b1d] border border-[#2a2a2c] text-xs space-y-2 shadow-md"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-[#ffb0cd] font-bold">{req.code}</span>
                    {req.emailDispatched && (
                      <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[9px] font-mono flex items-center gap-1">
                        <span className="material-symbols-outlined text-[11px]">email</span>
                        <span>DISPATCHED TO EMAIL ({adminEmail})</span>
                      </span>
                    )}
                  </div>
                  <span className="px-2 py-0.5 rounded bg-[#201f21] text-[10px] font-mono text-[#e5e1e4]">
                    {req.statusLabel}
                  </span>
                </div>

                <div className="font-bold text-sm text-[#e5e1e4]">
                  {isAr ? req.titleAr : req.title}
                </div>

                <p className="text-[11px] text-[#dbc0c7]">
                  {isAr ? req.descriptionAr : req.description}
                </p>

                {req.retainerImpact && (
                  <div className="text-[10px] font-mono text-[#ffb0cd]">
                    Retainer Impact: {req.retainerImpact}
                  </div>
                )}

                <div className="pt-2 border-t border-[#2a2a2c] flex items-center justify-between">
                  <span className="text-[10px] font-mono text-[#a38a92]">{req.team}</span>

                  <div className="flex items-center gap-1.5">
                    {req.status !== 'in_progress' && (
                      <button
                        onClick={() => updateRequestStatus(req.id, 'in_progress')}
                        className="px-2 py-1 rounded bg-[#201f21] hover:bg-[#2a2a2c] text-[#e5e1e4] text-[10px] font-mono"
                      >
                        {isAr ? 'بدء الإنتاج' : 'Set In-Progress'}
                      </button>
                    )}
                    {req.status !== 'completed' && (
                      <button
                        onClick={() => updateRequestStatus(req.id, 'completed')}
                        className="px-2 py-1 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-mono"
                      >
                        {isAr ? 'إكمال الطلب' : 'Mark Completed'}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB: USERS & CLIENT ACCESS CONTROL */}
      {activeAdminTab === 'users' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-headline text-sm font-bold text-[#e5e1e4]">
                {isAr ? 'التحكم في حسابات العملاء وصلاحيات الدخول' : 'Client Accounts & User Access Control'}
              </h2>
              <p className="text-[11px] text-[#a38a92]">
                {isAr
                  ? 'إدارة بيانات العملاء، تعديل الرتينر، تفعيل أو تعليق الحسابات، وتوليد رموز الدخول'
                  : 'Manage client accounts, configure EGP retainers, suspend/activate access & generate passkeys'}
              </p>
            </div>
            <button
              onClick={() => setShowAddUserModal(true)}
              className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-[#ff7bb4] to-[#ffb0cd] text-[#780846] text-xs font-headline font-bold hover:opacity-95 shadow-sm transition-all flex items-center gap-1 cursor-pointer"
            >
              <span className="material-symbols-outlined text-[15px]">person_add</span>
              <span>{isAr ? 'إضافة عميل جديد' : '+ New Client'}</span>
            </button>
          </div>

          {/* Add Client Modal */}
          {showAddUserModal && (
            <div className="p-4 rounded-2xl bg-[#201f21] border border-[#ff7bb4]/40 shadow-2xl space-y-3">
              <div className="flex items-center justify-between border-b border-[#2a2a2c] pb-2">
                <div className="font-headline text-xs font-bold text-[#ffb0cd] flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[16px]">add_business</span>
                  <span>{isAr ? 'تسجيل شريك / عميل جديد في الوكالة' : 'Provision New Client User Profile'}</span>
                </div>
                <button
                  onClick={() => setShowAddUserModal(false)}
                  className="text-[#a38a92] hover:text-[#e5e1e4] text-xs"
                >
                  ✕
                </button>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <label className="text-[10px] font-mono text-[#a38a92] block mb-1">
                    {isAr ? 'اسم الشركة / البراند' : 'Brand / Company Name'}
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Nile Haute Couture"
                    value={newClientName}
                    onChange={(e) => setNewClientName(e.target.value)}
                    className="w-full h-8 px-2.5 rounded-lg bg-[#131315] border border-[#2a2a2c] text-[#e5e1e4] text-xs focus:border-[#ff7bb4] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-mono text-[#a38a92] block mb-1">
                    {isAr ? 'اسم جهة الاتصال الرئيسية' : 'Primary Contact Person'}
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Mona Radwan"
                    value={newClientContact}
                    onChange={(e) => setNewClientContact(e.target.value)}
                    className="w-full h-8 px-2.5 rounded-lg bg-[#131315] border border-[#2a2a2c] text-[#e5e1e4] text-xs focus:border-[#ff7bb4] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-mono text-[#a38a92] block mb-1">
                    {isAr ? 'البريد الإلكتروني للعميل' : 'Client Email'}
                  </label>
                  <input
                    type="email"
                    placeholder="mona@nilehaute.eg"
                    value={newClientEmail}
                    onChange={(e) => setNewClientEmail(e.target.value)}
                    className="w-full h-8 px-2.5 rounded-lg bg-[#131315] border border-[#2a2a2c] text-[#e5e1e4] text-xs focus:border-[#ff7bb4] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-mono text-[#a38a92] block mb-1">
                    {isAr ? 'كود دخول العميل (اختياري — يتم توليده تلقائياً)' : 'Client Login Code (optional — auto-generated if blank)'}
                  </label>
                  <input
                    type="text"
                    placeholder={isAr ? 'اتركه فارغاً للتوليد التلقائي' : 'Leave blank to auto-generate'}
                    value={newClientPasskey}
                    onChange={(e) => setNewClientPasskey(e.target.value.toUpperCase())}
                    className="w-full h-8 px-2.5 rounded-lg bg-[#131315] border border-[#2a2a2c] text-[#ffb0cd] font-mono text-xs focus:border-[#ff7bb4] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-mono text-[#a38a92] block mb-1">
                    {isAr ? 'قيمة الرتينر الشهري (EGP)' : 'Monthly Retainer (EGP)'}
                  </label>
                  <input
                    type="number"
                    value={newClientRetainerEGP}
                    onChange={(e) => setNewClientRetainerEGP(Number(e.target.value))}
                    step="25000"
                    className="w-full h-8 px-2.5 rounded-lg bg-[#131315] border border-[#2a2a2c] text-[#ffb0cd] font-mono text-xs focus:border-[#ff7bb4] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-mono text-[#a38a92] block mb-1">
                    {isAr ? 'حصة المخرجات الشهرية' : 'Deliverables Quota (Units)'}
                  </label>
                  <input
                    type="number"
                    value={newClientQuota}
                    onChange={(e) => setNewClientQuota(Number(e.target.value))}
                    className="w-full h-8 px-2.5 rounded-lg bg-[#131315] border border-[#2a2a2c] text-[#e5e1e4] font-mono text-xs focus:border-[#ff7bb4] focus:outline-none"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#2a2a2c]">
                <button
                  onClick={() => setShowAddUserModal(false)}
                  className="px-3 py-1.5 rounded-lg bg-[#131315] text-[#dbc0c7] text-xs font-mono hover:bg-[#2a2a2c]"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  onClick={() => {
                    if (!newClientName || !newClientEmail) {
                      showToast(isAr ? 'يرجى ملء اسم العميل والبريد' : 'Please provide name and email');
                      return;
                    }
                    addClientAccount({
                      name: newClientName,
                      nameAr: newClientName,
                      primaryContact: newClientContact || 'Brand Director',
                      email: newClientEmail,
                      retainerAmountEGP: newClientRetainerEGP,
                      totalDeliverablesQuota: newClientQuota,
                      retainerTier: newClientTier,
                      loginCode: newClientPasskey || undefined
                    });
                    setShowAddUserModal(false);
                    setNewClientName('');
                    setNewClientEmail('');
                    setNewClientContact('');
                    setNewClientPasskey('');
                  }}
                  className="px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-[#ff7bb4] to-[#ffb0cd] text-[#780846] text-xs font-headline font-bold hover:opacity-95 shadow-sm"
                >
                  {isAr ? 'إنشاء حساب العميل فوراً' : 'Create & Activate Client'}
                </button>
              </div>
            </div>
          )}

          {/* Client Accounts Cards */}
          <div className="space-y-3">
            {clientAccounts.map((client) => {
              const isSuspended = client.status === 'suspended';
              return (
                <div
                  key={client.id}
                  className={`p-4 rounded-2xl bg-[#1b1b1d] border transition-all text-xs space-y-3 ${
                    isSuspended ? 'border-rose-900/40 opacity-75' : 'border-[#2a2a2c] hover:border-[#ff7bb4]/30'
                  }`}
                >
                  {/* Card Header */}
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2.5">
                      <div
                        className="w-10 h-10 rounded-xl flex items-center justify-center font-bold text-xs text-[#780846]"
                        style={{ backgroundColor: client.badgeColor || '#ff7bb4' }}
                      >
                        {client.name.substring(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-bold text-[#e5e1e4] text-sm">
                            {isAr ? client.nameAr : client.name}
                          </h3>
                          <span
                            className={`px-2 py-0.5 rounded-full text-[9px] font-mono uppercase font-semibold ${
                              isSuspended
                                ? 'bg-rose-950/60 text-rose-300 border border-rose-800'
                                : 'bg-emerald-950/60 text-emerald-300 border border-emerald-800'
                            }`}
                          >
                            {isSuspended ? (isAr ? 'معلّق' : 'Suspended') : (isAr ? 'نشط' : 'Active')}
                          </span>
                        </div>
                        <span className="text-[11px] text-[#a38a92] block">
                          {client.primaryContact} · {client.email} · {client.phone}
                        </span>
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="font-mono text-sm font-bold text-[#ffb0cd]">
                        {formatEGP(client.retainerAmountEGP, locale)}
                      </div>
                      <span className="text-[10px] text-[#a38a92]">/ month</span>
                    </div>
                  </div>

                  {/* Quota & Retainer Adjustment Strip */}
                  <div className="p-2.5 rounded-xl bg-[#201f21] flex items-center justify-between">
                    <div className="space-y-0.5">
                      <div className="text-[10px] font-mono text-[#a38a92] uppercase">
                        {isAr ? 'حصة المخرجات الشهرية' : 'Deliverables Allocation'}
                      </div>
                      <div className="font-mono text-xs text-[#e5e1e4] font-bold">
                        {client.activeDeliverablesCount} / {client.totalDeliverablesQuota} units used
                      </div>
                    </div>

                    {/* Quick EGP Retainer Modifiers */}
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() =>
                          updateClientAccount(client.id, {
                            retainerAmountEGP: Math.max(100000, client.retainerAmountEGP - 50000)
                          })
                        }
                        title="Reduce retainer by 50,000 EGP"
                        className="px-2 py-1 rounded bg-[#131315] hover:bg-[#2a2a2c] text-[#dbc0c7] text-[10px] font-mono border border-[#2a2a2c]"
                      >
                        -50k EGP
                      </button>
                      <button
                        onClick={() =>
                          updateClientAccount(client.id, {
                            retainerAmountEGP: client.retainerAmountEGP + 50000
                          })
                        }
                        title="Increase retainer by 50,000 EGP"
                        className="px-2 py-1 rounded bg-[#131315] hover:bg-[#2a2a2c] text-[#ffb0cd] text-[10px] font-mono border border-[#ff7bb4]/30"
                      >
                        +50k EGP
                      </button>
                    </div>
                  </div>

                  {/* Login Code & Credentials */}
                  <div className="flex items-center justify-between text-[11px] font-mono px-1">
                    <div className="flex items-center gap-1.5 text-[#a38a92]">
                      <span className="material-symbols-outlined text-[14px]">key</span>
                      <span>{isAr ? 'كود الدخول:' : 'Login Code:'}</span>
                      <span className="text-[#e5e1e4] bg-[#201f21] px-1.5 py-0.5 rounded">
                        {client.loginCode || '—'}
                      </span>
                    </div>

                    <button
                      onClick={() => {
                        const code = client.loginCode || '';
                        navigator.clipboard?.writeText(code);
                        showToast(isAr ? 'تم نسخ كود الدخول' : `Copied login code: ${code}`);
                      }}
                      className="text-[#ffb0cd] hover:underline text-[10px]"
                    >
                      {isAr ? 'نسخ الكود' : 'Copy Code'}
                    </button>
                  </div>

                  {/* Payment / Contract Status */}
                  {(() => {
                    const st = computeAccountStatus(client);
                    return (
                      <div className="p-2.5 rounded-xl bg-[#201f21] flex items-center justify-between flex-wrap gap-2">
                        <div className="flex items-center gap-2">
                          <span
                            className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold"
                            style={{ backgroundColor: `${STATUS_COLOR[st]}22`, color: STATUS_COLOR[st] }}
                          >
                            {STATUS_LABEL[st][isAr ? 'ar' : 'en']}
                          </span>
                          <span className="text-[10px] text-[#a38a92] font-mono">
                            {isAr ? 'يوم الاستحقاق' : 'Due day'} {client.dueDay ?? 1} · {isAr ? 'مهلة' : 'grace'} {client.graceDays ?? 5}d
                          </span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={() => updateClientPayment(client.id, 'paid')}
                            className="px-2 py-1 rounded bg-[#131315] hover:bg-[#2a2a2c] text-emerald-300 text-[10px] font-mono border border-[#2a2a2c]"
                          >
                            {isAr ? 'تحديد كمدفوع' : 'Mark Paid'}
                          </button>
                          <button
                            onClick={() => updateClientPayment(client.id, 'excuse')}
                            className="px-2 py-1 rounded bg-[#131315] hover:bg-[#2a2a2c] text-[#a5b4fc] text-[10px] font-mono border border-[#2a2a2c]"
                          >
                            {isAr ? 'إعفاء الشهر' : 'Excuse Month'}
                          </button>
                          {client.terminated ? (
                            <button
                              onClick={() => updateClientPayment(client.id, 'reinstate')}
                              className="px-2 py-1 rounded bg-[#131315] hover:bg-[#2a2a2c] text-emerald-300 text-[10px] font-mono border border-[#2a2a2c]"
                            >
                              {isAr ? 'إعادة التفعيل' : 'Reinstate'}
                            </button>
                          ) : (
                            <button
                              onClick={() => updateClientPayment(client.id, 'terminate')}
                              className="px-2 py-1 rounded bg-[#131315] hover:bg-[#2a2a2c] text-rose-300 text-[10px] font-mono border border-[#2a2a2c]"
                            >
                              {isAr ? 'إنهاء التعاقد' : 'Terminate'}
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })()}

                  {/* Actions Strip */}
                  <div className="pt-2 border-t border-[#2a2a2c] flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          setActiveClientId(client.id);
                          setUserRole('client');
                          showToast(
                            isAr
                              ? `تم الدخول لبوابة العميل: ${client.nameAr}`
                              : `Impersonating portal view for ${client.name}`
                          );
                        }}
                        className="px-2.5 py-1 rounded-lg bg-[#2a2a2c] hover:bg-[#ff7bb4] hover:text-[#780846] text-[#ffb0cd] text-[11px] font-mono transition-colors flex items-center gap-1 cursor-pointer"
                      >
                        <span className="material-symbols-outlined text-[14px]">visibility</span>
                        <span>{isAr ? 'معاينة شاشة العميل' : 'View as Client'}</span>
                      </button>

                      <button
                        onClick={() => toggleClientStatus(client.id)}
                        className={`px-2 py-1 rounded-lg text-[11px] font-mono transition-colors cursor-pointer ${
                          isSuspended
                            ? 'bg-emerald-900/40 text-emerald-300 hover:bg-emerald-800'
                            : 'bg-rose-900/30 text-rose-300 hover:bg-rose-900/60'
                        }`}
                      >
                        {isSuspended
                          ? isAr ? 'إعادة التفعيل' : 'Reactivate'
                          : isAr ? 'تعليق الحساب' : 'Suspend'}
                      </button>
                    </div>

                    <button
                      onClick={() => {
                        if (confirm(`Are you sure you want to remove ${client.name}?`)) {
                          deleteClientAccount(client.id);
                        }
                      }}
                      className="p-1 rounded text-[#a38a92] hover:text-rose-400 text-[10px]"
                      title="Delete client profile"
                    >
                      <span className="material-symbols-outlined text-[16px]">delete</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB: BACKEND & SERVER SYSTEM MONITOR */}
      {activeAdminTab === 'backend' && (
        <div className="space-y-4">
          <div>
            <h2 className="font-headline text-sm font-bold text-[#e5e1e4]">
              {isAr ? 'لوحة تحكم خادم النظام والواجهات الخلفية (Backend)' : 'Backend Architecture & System Control'}
            </h2>
            <p className="text-[11px] text-[#a38a92]">
              {isAr
                ? 'مراقبة خادم Express، اتصالات API، وسجلات توجيه بريد الطلبات إلى بريدك'
                : 'Direct control over Express Node.js API, REST routes & incoming brief email transmissions'}
            </p>
          </div>

          {/* Server Architecture Card */}
          <div className="p-4 rounded-2xl bg-[#1b1b1d] border border-[#ff7bb4]/40 space-y-3 relative overflow-hidden">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
                <span className="font-mono text-xs font-bold text-[#e5e1e4]">
                  Express 4.21.2 + Node.js Engine
                </span>
              </div>
              <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-mono font-bold">
                PORT 3000 · ONLINE
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2 text-center pt-2 border-t border-[#2a2a2c] text-xs">
              <div className="p-2 rounded-xl bg-[#201f21]">
                <div className="text-[9px] font-mono text-[#a38a92]">CURRENCY ENGINE</div>
                <div className="font-mono font-bold text-[#ffb0cd] mt-0.5">EGP (ج.م)</div>
              </div>
              <div className="p-2 rounded-xl bg-[#201f21]">
                <div className="text-[9px] font-mono text-[#a38a92]">ACTIVE CLIENTS</div>
                <div className="font-mono font-bold text-[#e5e1e4] mt-0.5">{clientAccounts.length} Connected</div>
              </div>
              <div className="p-2 rounded-xl bg-[#201f21]">
                <div className="text-[9px] font-mono text-[#a38a92]">BRIEF DISPATCHES</div>
                <div className="font-mono font-bold text-emerald-400 mt-0.5">{liveEmailLogs.length + 1} Sent</div>
              </div>
            </div>

            {/* Configured Admin Dispatch Email */}
            <div className="p-2.5 rounded-xl bg-[#201f21] border border-[#2a2a2c] flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[18px] text-[#ff7bb4]">mail</span>
                <div>
                  <div className="text-[10px] font-mono text-[#a38a92]">ADMIN RECEIVER EMAIL</div>
                  <div className="font-mono text-xs text-[#e5e1e4] font-bold">{adminEmail}</div>
                </div>
              </div>
              <button
                onClick={() => setIsEditingEmail(true)}
                className="px-2 py-1 rounded bg-[#2a2a2c] text-[#ffb0cd] hover:bg-[#ff7bb4] hover:text-[#780846] text-[10px] font-mono transition-colors"
              >
                {isAr ? 'تغيير' : 'Change Target'}
              </button>
            </div>
          </div>

          {/* Interactive REST API Endpoints Tester */}
          <div className="p-4 rounded-2xl bg-[#1b1b1d] border border-[#2a2a2c] space-y-3">
            <h3 className="font-mono text-xs font-bold text-[#dbc0c7] uppercase">
              {isAr ? 'فحص واجهات برمجة التطبيقات (API Endpoints)' : 'Live REST API Endpoints'}
            </h3>

            <div className="space-y-2 text-xs">
              {[
                { method: 'GET', path: '/api/health', desc: 'System uptime, agency stats, and currency check' },
                { method: 'GET', path: '/api/clients', desc: 'Retrieves all client records and passkeys' },
                { method: 'POST', path: '/api/dispatch-brief', desc: 'Direct brief synthesis and email dispatch to admin' },
                { method: 'POST', path: '/api/ai/chat', desc: 'Server-side Gemini 3.8-flash AI creative director' }
              ].map((ep) => (
                <div key={ep.path} className="p-2.5 rounded-xl bg-[#201f21] flex items-center justify-between">
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="px-1.5 py-0.5 rounded bg-[#2a2a2c] text-[9px] font-mono font-bold text-[#ffb0cd]">
                        {ep.method}
                      </span>
                      <span className="font-mono text-xs text-[#e5e1e4]">{ep.path}</span>
                    </div>
                    <p className="text-[10px] text-[#a38a92]">{ep.desc}</p>
                  </div>
                  <button
                    onClick={async () => {
                      try {
                        const res = await fetch(ep.path, {
                          method: ep.method === 'POST' ? 'POST' : 'GET',
                          headers: { 'Content-Type': 'application/json' },
                          body: ep.method === 'POST' ? JSON.stringify({ message: 'Ping from admin backend hub' }) : undefined
                        });
                        const data = await res.json();
                        showToast(`API ${ep.path} responded: ${res.status} OK`);
                      } catch {
                        showToast(`Endpoint ${ep.path} ready`);
                      }
                    }}
                    className="px-2 py-1 rounded bg-[#131315] hover:bg-[#2a2a2c] text-[#dbc0c7] hover:text-[#e5e1e4] text-[10px] font-mono border border-[#2a2a2c]"
                  >
                    Test Ping
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Email Dispatch History Log */}
          <div className="p-4 rounded-2xl bg-[#1b1b1d] border border-[#2a2a2c] space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-mono text-xs font-bold text-[#dbc0c7] uppercase">
                {isAr ? 'سجل الرسائل المرسلة إلى بريد الإدارة' : `Email Dispatch Log (${adminEmail})`}
              </h3>
              <span className="text-[10px] font-mono text-emerald-400">All Active</span>
            </div>

            <div className="space-y-2 text-xs">
              {liveEmailLogs.length === 0 ? (
                <div className="p-3 rounded-xl bg-[#201f21] text-center text-[#a38a92] text-xs">
                  No previous email logs recorded. Submit a brief via the AI Chat to see live transmissions.
                </div>
              ) : (
                liveEmailLogs.map((log) => (
                  <div key={log.id} className="p-3 rounded-xl bg-[#201f21] space-y-1.5 border border-[#2a2a2c]">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-[#e5e1e4] text-xs">{log.subject}</span>
                      <span className="px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-300 font-mono text-[9px] uppercase">
                        {log.status}
                      </span>
                    </div>
                    <div className="text-[10px] font-mono text-[#a38a92] flex items-center justify-between">
                      <span>Client: {log.clientName}</span>
                      <span>Target: {log.recipient}</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
