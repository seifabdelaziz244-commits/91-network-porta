import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Locale,
  UserRole,
  TabType,
  ContentDeliverable,
  RequestItem,
  InvoiceItem,
  ChatMessage,
  ClientAccount,
  ClientUpdate
} from '../types';
import {
  INITIAL_DELIVERABLES,
  INITIAL_REQUESTS,
  INITIAL_INVOICES,
  INITIAL_CHAT_MESSAGES,
  CLIENT_ACCOUNTS,
  INITIAL_CLIENT_UPDATES
} from '../data/mockData';

interface AppContextType {
  locale: Locale;
  setLocale: (loc: Locale) => void;
  toggleLocale: () => void;
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;
  activeClientId: string;
  setActiveClientId: (id: string) => void;
  currentClient: ClientAccount;
  clientAccounts: ClientAccount[];
  clientUpdates: ClientUpdate[];
  addClientUpdate: (update: {
    clientId: string;
    title: string;
    titleAr: string;
    body: string;
    bodyAr: string;
    author: string;
    authorRole: string;
    type: 'production' | 'creative' | 'dispatch' | 'billing';
    priority?: 'urgent' | 'normal' | 'log';
  }) => void;
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  isVaultLocked: boolean;
  setIsVaultLocked: (locked: boolean) => void;
  isLoadingClients: boolean;
  loginAsAdmin: (password: string) => Promise<{ success: boolean; error?: string }>;
  loginAsClient: (code: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  updateClientPayment: (id: string, action: 'paid' | 'excuse' | 'terminate' | 'reinstate') => Promise<void>;
  activeDeliverableId: string | null;
  setActiveDeliverableId: (id: string | null) => void;
  isBriefModalOpen: boolean;
  setIsBriefModalOpen: (open: boolean) => void;
  deliverables: ContentDeliverable[];
  setDeliverables: React.Dispatch<React.SetStateAction<ContentDeliverable[]>>;
  addDeliverable: (item: Partial<ContentDeliverable>) => void;
  updateDeliverableStatus: (id: string, status: ContentDeliverable['status']) => void;
  requests: RequestItem[];
  setRequests: React.Dispatch<React.SetStateAction<RequestItem[]>>;
  updateRequestStatus: (id: string, status: RequestItem['status'], agencyNote?: string) => void;
  invoices: InvoiceItem[];
  chatMessages: ChatMessage[];
  approveDeliverable: (id: string) => void;
  requestRevision: (id: string, note?: string) => void;
  submitBrief: (customData?: Partial<RequestItem>) => void;
  addChatMessage: (text: string) => Promise<void>;
  isAiThinking: boolean;
  adminEmail: string;
  setAdminEmail: (email: string) => void;
  dispatchBriefToEmail: (
    brief: {
      title: string;
      titleAr?: string;
      description?: string;
      deliverablesSummary?: string;
      shootDate?: string;
      cameraGear?: string;
      aesthetic?: string;
      retainerImpact?: string;
    },
    targetEmail?: string
  ) => Promise<{ success: boolean; dispatchId: string; mailtoUrl: string }>;
  toastMessage: string | null;
  showToast: (msg: string) => void;
  addClientAccount: (clientData: Partial<ClientAccount>) => void;
  updateClientAccount: (id: string, updates: Partial<ClientAccount>) => void;
  deleteClientAccount: (id: string) => void;
  toggleClientStatus: (id: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [locale, setLocale] = useState<Locale>('en');
  const [userRole, setUserRole] = useState<UserRole>('client');
  const [activeClientId, setActiveClientId] = useState<string>('client-lumen');
  const [clientAccounts, setClientAccounts] = useState<ClientAccount[]>(CLIENT_ACCOUNTS);
  const [clientUpdates, setClientUpdates] = useState<ClientUpdate[]>(INITIAL_CLIENT_UPDATES);
  const [activeTab, setActiveTab] = useState<TabType>('home');
  const [isVaultLocked, setIsVaultLocked] = useState<boolean>(true);
  const [isLoadingClients, setIsLoadingClients] = useState<boolean>(true);
  const [activeDeliverableId, setActiveDeliverableId] = useState<string | null>(null);
  const [isBriefModalOpen, setIsBriefModalOpen] = useState<boolean>(false);
  const [deliverables, setDeliverables] = useState<ContentDeliverable[]>(INITIAL_DELIVERABLES);
  const [requests, setRequests] = useState<RequestItem[]>(INITIAL_REQUESTS);
  const [invoices] = useState<InvoiceItem[]>(INITIAL_INVOICES);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(INITIAL_CHAT_MESSAGES);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isAiThinking, setIsAiThinking] = useState<boolean>(false);
  const [adminEmail, setAdminEmail] = useState<string>(
    'ceo@91network.online, seifabdelaziz@91network.online'
  );

  useEffect(() => {
    // Update document HTML dir attribute for RTL
    document.documentElement.dir = locale === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = locale;
    document.body.dir = locale === 'ar' ? 'rtl' : 'ltr';
  }, [locale]);

  // Load real client accounts from Postgres on mount. If the API isn't reachable
  // (e.g. no Postgres connected yet), we silently keep the bundled demo accounts
  // so the app is still explorable, but nothing typed in will persist.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch('/api/clients');
        if (!res.ok) throw new Error('bad status');
        const data: ClientAccount[] = await res.json();
        if (!cancelled) setClientAccounts(data);
      } catch {
        // keep mock CLIENT_ACCOUNTS fallback
      } finally {
        if (!cancelled) setIsLoadingClients(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const toggleLocale = () => {
    setLocale((prev) => (prev === 'en' ? 'ar' : 'en'));
  };

  /** Real agency-admin login, checked server-side against ADMIN_PASSWORD. */
  const loginAsAdmin = async (password: string): Promise<{ success: boolean; error?: string }> => {
    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setUserRole('agency_admin');
        setIsVaultLocked(false);
        setActiveTab('admin');
        return { success: true };
      }
      return { success: false, error: data.error || 'Incorrect password.' };
    } catch {
      return { success: false, error: 'Could not reach the server. Check your connection.' };
    }
  };

  /** Real client login: matches the code against Postgres. No account, no access. */
  const loginAsClient = async (code: string): Promise<{ success: boolean; error?: string }> => {
    try {
      const res = await fetch('/api/clients/lookup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code }),
      });
      const data = await res.json();
      if (res.ok && data.client) {
        setClientAccounts((prev) => {
          const exists = prev.some((c) => c.id === data.client.id);
          return exists ? prev.map((c) => (c.id === data.client.id ? data.client : c)) : [data.client, ...prev];
        });
        setActiveClientId(data.client.id);
        setUserRole('client');
        setIsVaultLocked(false);
        setActiveTab('home');
        return { success: true };
      }
      return { success: false, error: data.error || "We couldn't find that code." };
    } catch {
      return { success: false, error: 'Could not reach the server. Check your connection.' };
    }
  };

  const logout = () => {
    setIsVaultLocked(true);
    setActiveTab('home');
  };

  /** Mark paid / excuse this month / terminate / reinstate — persisted server-side. */
  const updateClientPayment = async (id: string, action: 'paid' | 'excuse' | 'terminate' | 'reinstate') => {
    try {
      const res = await fetch(`/api/clients/${id}/payment`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action }),
      });
      const data = await res.json();
      if (res.ok && data.client) {
        setClientAccounts((prev) => prev.map((c) => (c.id === id ? data.client : c)));
        showToast(
          locale === 'ar'
            ? { paid: 'تم تحديد الدفع', excuse: 'تم إعفاء هذا الشهر', terminate: 'تم إنهاء التعاقد', reinstate: 'تم إعادة التفعيل' }[action]
            : { paid: 'Marked as paid', excuse: 'Excused this month', terminate: 'Contract terminated', reinstate: 'Contract reinstated' }[action]
        );
      }
    } catch {
      showToast(locale === 'ar' ? 'تعذر الاتصال بالخادم' : 'Could not reach the server.');
    }
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4500);
  };

  const EMPTY_CLIENT: ClientAccount = {
    id: 'no-clients-yet',
    name: 'No clients yet',
    nameAr: 'لا يوجد عملاء بعد',
    industry: '',
    industryAr: '',
    location: '',
    locationAr: '',
    primaryContact: locale === 'ar' ? 'أضف أول عميل من لوحة الإدارة' : 'Add your first client from the Admin Hub',
    email: '',
    phone: '',
    retainerTier: '',
    retainerTierAr: '',
    retainerAmountEGP: 0,
    activeDeliverablesCount: 0,
    totalDeliverablesQuota: 0,
    activeShootsCount: 0,
    status: 'active',
    badgeColor: '#ff7bb4',
  };
  const currentClient =
    clientAccounts.find((c) => c.id === activeClientId) || clientAccounts[0] || EMPTY_CLIENT;

  const addClientUpdate = (update: {
    clientId: string;
    title: string;
    titleAr: string;
    body: string;
    bodyAr: string;
    author: string;
    authorRole: string;
    type: 'production' | 'creative' | 'dispatch' | 'billing';
    priority?: 'urgent' | 'normal' | 'log';
  }) => {
    const newUpdate: ClientUpdate = {
      id: `upd-${Date.now()}`,
      timestamp: locale === 'ar' ? 'الآن' : 'Just now',
      ...update
    };
    setClientUpdates((prev) => [newUpdate, ...prev]);
    showToast(
      locale === 'ar'
        ? 'تم نشر التحديث وإرسال إشعار فوري للعميل بنجاح'
        : 'Update published & broadcasted to client portal!'
    );
  };

  const addDeliverable = (item: Partial<ContentDeliverable>) => {
    const newDel: ContentDeliverable = {
      id: `del-${Date.now()}`,
      code: `#DEL-${Math.floor(100 + Math.random() * 900)}`,
      clientId: activeClientId,
      type: item.type || 'reel',
      platform: item.platform || 'Instagram Reels & TikTok',
      title: item.title || 'Untitled Deliverable',
      titleAr: item.titleAr || 'مخرجة إنتاجية جديدة',
      description: item.description || 'Deliverable uploaded by 91 Network Agency Admin',
      descriptionAr: item.descriptionAr || 'تم رفع المخرجة بواسطة إدارة شبكة 91',
      status: item.status || 'action_required',
      scheduledDate: item.scheduledDate || 'Nov 04, 2024',
      scheduledTime: item.scheduledTime || '06:00 PM GST',
      scheduledTimeAr: item.scheduledTimeAr || '06:00 م بتوقيت دبي',
      aspectRatio: item.aspectRatio || '9:16',
      posterImage:
        item.posterImage ||
        'https://lh3.googleusercontent.com/aida-public/AB6AXuDO0p2-i9PmGOLkBCBx9JFRUfeJU8UbwvCDYPBcRYsxeyw4lyPgzaXA7wxKJg33q0NpSfShSbjfB3eJ62IN9MrEBYoIrznHmzB6Udb-RjNvQCl6TtdERryXNc3Z-IVajF--153FpeBRnFFgSBpqrHwfHaEVt4BhW0SBwicH2et90DUnj7OZLWofwgUntVsgzo003CnrIrCAmiQEhagTkPSgcqrzqDZhG0Bq_N0F0TjbSO8ggl0ufb8n',
      rawVaultUrl: item.rawVaultUrl || 'https://vault.91network.agency/raw/fw24-export',
      dpNote: item.dpNote || 'Color graded with Kodak 5219 calibrated LUT.',
      dpNoteAr: item.dpNoteAr || 'تم تدقيق الألوان بمعايرة كوداك 5219 LUT.',
      dpAuthor: 'Sarah T. · Lead DP',
      captionEn: item.captionEn || 'Capsule aesthetic. Directed by 91 Network.',
      captionAr: item.captionAr || 'جماليات الكبسولة. إخراج شبكة 91.',
      hashtags: item.hashtags || '#FW24 #91Network #LuxuryCinema',
      ...item
    };
    setDeliverables((prev) => [newDel, ...prev]);
    showToast(
      locale === 'ar'
        ? `تمت إضافة المخرجة ${newDel.code} بنجاح إلى جدول العميل!`
        : `Deliverable ${newDel.code} added to client schedule!`
    );
  };

  const updateDeliverableStatus = (id: string, status: ContentDeliverable['status']) => {
    setDeliverables((prev) =>
      prev.map((d) => (d.id === id ? { ...d, status } : d))
    );
    showToast(
      locale === 'ar'
        ? `تم تحديث حالة المخرجة إلى: ${status}`
        : `Deliverable status updated to: ${status}`
    );
  };

  const updateRequestStatus = (id: string, status: RequestItem['status'], agencyNote?: string) => {
    setRequests((prev) =>
      prev.map((r) =>
        r.id === id
          ? {
              ...r,
              status,
              agencyNote: agencyNote || r.agencyNote,
              dueText: 'Updated by Agency Admin'
            }
          : r
      )
    );
    showToast(
      locale === 'ar'
        ? 'تم تحديث حالة الطلب وإشعار العميل بالتقدم'
        : 'Request status updated & client notified'
    );
  };

  const approveDeliverable = (id: string) => {
    setDeliverables((prev) =>
      prev.map((d) =>
        d.id === id
          ? { ...d, status: 'scheduled' as const, approvedBy: 'Approved by Client Lead' }
          : d
      )
    );
    showToast(
      locale === 'ar'
        ? 'تم اعتماد المخرجة بنجاح وجدولتها للبث التلقائي!'
        : 'Deliverable approved & locked for scheduled auto-dispatch!'
    );
  };

  const requestRevision = (id: string, note?: string) => {
    setDeliverables((prev) =>
      prev.map((d) =>
        d.id === id
          ? {
              ...d,
              status: 'in_revision' as const,
              revisionRound: (d.revisionRound || 1) + 1,
              dpNote: note || d.dpNote
            }
          : d
      )
    );
    showToast(
      locale === 'ar'
        ? 'تم إرسال طلب التعديل إلى غرفة عمليات شبكة 91'
        : 'Revision note dispatched to 91 Network production queue'
    );
  };

  const submitBrief = (customData?: Partial<RequestItem>) => {
    const newReq: RequestItem = {
      id: `req-${Date.now()}`,
      code: customData?.code || `#REQ-${Math.floor(880 + Math.random() * 50)}`,
      clientId: activeClientId,
      title: customData?.title || 'Raw Silk Trench Coat Dusk Campaign Reel',
      titleAr: customData?.titleAr || 'ريل حملة معطف الحرير الخام عند الغسق',
      type: 'brief',
      typeLabel: 'NEW BRIEF · AUTO-SYNTHESIZED',
      typeLabelAr: 'موجز جديد · توليد ذكي',
      status: 'pending_review',
      statusLabel: 'PENDING REVIEW',
      statusLabelAr: 'قيد المراجعة',
      dueText: customData?.dueText || 'Shoot Oct 28',
      dueTextAr: customData?.dueTextAr || 'التصوير 28 أكتوبر',
      createdTime: 'Just now',
      createdTimeAr: 'الآن',
      description:
        customData?.description ||
        'Synthesized via AI Account Director. 1x 4K Cinematic Reel (30s) + 2x Editorial Stills.',
      descriptionAr:
        customData?.descriptionAr ||
        'تم توليده عبر مدير الحسابات الذكي. ريل سينمائي 4K (30 ثانية) وصورتان تحريريتان.',
      team: 'Dispatched to SEIF ABD ELAZIZ (Founder & CEO)',
      deliverablesSummary: customData?.deliverablesSummary || '1x 4K Cinematic Reel (30s) + 2x Stills',
      retainerImpact: customData?.retainerImpact || '-1 Video / -1 Photo (In EGP Retainer)',
      emailDispatched: customData?.emailDispatched ?? true,
      emailTarget: customData?.emailTarget || adminEmail,
      ...customData
    };

    setRequests((prev) => [newReq, ...prev.filter((r) => r.code !== newReq.code)]);
    showToast(
      locale === 'ar'
        ? `تم إنشاء الطلب ${newReq.code} وإرساله إلى الإدارة (سيف عبد العزيز): ${adminEmail}`
        : `Brief ${newReq.code} created & dispatched to SEIF ABD ELAZIZ (${adminEmail})`
    );
    setIsBriefModalOpen(false);
  };

  const dispatchBriefToEmail = async (
    brief: {
      title: string;
      titleAr?: string;
      description?: string;
      deliverablesSummary?: string;
      shootDate?: string;
      cameraGear?: string;
      aesthetic?: string;
      retainerImpact?: string;
    },
    targetEmail = adminEmail
  ) => {
    const dispatchId = `DISPATCH-91-${Math.floor(10000 + Math.random() * 90000)}`;
    const emailSubject = encodeURIComponent(
      `[91 Network Production Brief] ${brief.title} (${dispatchId})`
    );
    const emailBodyText = `91 NETWORK LUXURY CREATIVE AGENCY — NEW PRODUCTION BRIEF
------------------------------------------------------------
Dispatch ID: ${dispatchId}
Client: ${currentClient.name} (${currentClient.industry})
Target Email: ${targetEmail}
Status: PENDING PRODUCTION REVIEW

CAMPAIGN BRIEF SPECIFICATIONS:
- Project Title: ${brief.title}
- Target Production Date: ${brief.shootDate || 'Oct 28, 2024'}
- Deliverables Scope: ${brief.deliverablesSummary || '1x 4K Cinematic Reel (30s) + 2x Editorial Stills'}
- Camera & Technical Gear: ${brief.cameraGear || 'Sony FX6 4K 10-bit S-Log3, Cooke Anamorphic Lenses'}
- Aesthetic & Color Grade: ${brief.aesthetic || 'Cinematic dusk 35mm, Kodak 5219 LUT calibrated'}
- Account Retainer Impact: ${brief.retainerImpact || '-1 Video / -1 Photo (Retainer: ' + currentClient.retainerAmountEGP.toLocaleString() + ' EGP/mo)'}

DESCRIPTION & CREATIVE VISION:
${brief.description || 'Moodboard dusk lookbook pre-orders campaign. Directed by 91 Network Operations.'}

------------------------------------------------------------
Transmitted via 91 Network AI Intake Portal
Recipient: ${targetEmail}
Timestamp: ${new Date().toISOString()}`;

    const mailtoUrl = `mailto:${targetEmail}?subject=${emailSubject}&body=${encodeURIComponent(
      emailBodyText
    )}`;

    // Try posting to backend server if available
    try {
      await fetch('/api/dispatch-brief', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          dispatchId,
          targetEmail,
          clientName: currentClient.name,
          brief,
          bodyText: emailBodyText
        })
      });
    } catch {
      // Backend optional / offline fallback
    }

    // Automatically log request
    submitBrief({
      title: brief.title,
      titleAr: brief.titleAr || brief.title,
      description: brief.description,
      deliverablesSummary: brief.deliverablesSummary,
      emailDispatched: true,
      emailTarget: targetEmail
    });

    // Also post an automated client update
    addClientUpdate({
      clientId: activeClientId,
      title: `Creative Brief Dispatched to Agency Email (${targetEmail})`,
      titleAr: `تم إرسال موجز الإنتاج مباشرة إلى بريد إدارة الوكالة (${targetEmail})`,
      body: `AI Director generated ${brief.title} and transmitted the full specs to ${targetEmail} under reference ${dispatchId}.`,
      bodyAr: `تم إرسال متطلبات المشروع ${brief.title} بالكامل إلى البريد الإلكتروني ${targetEmail} برقم المرجع ${dispatchId}.`,
      author: '91 Studio AI Dispatcher',
      authorRole: 'Automated Brief Engine',
      type: 'dispatch',
      priority: 'urgent'
    });

    showToast(
      locale === 'ar'
        ? `تم إرسال الطلب مباشرة إلى بريدك الإلكتروني: ${targetEmail}`
        : `Request sent directly to your email: ${targetEmail}`
    );

    return { success: true, dispatchId, mailtoUrl };
  };

  const addChatMessage = async (text: string) => {
    const clientMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      sender: 'client',
      author:
        userRole === 'agency_admin' ? 'SEIF ABD ELAZIZ (Founder & CEO)' : currentClient.primaryContact,
      time: locale === 'ar' ? 'الآن' : 'Just now',
      text
    };
    setChatMessages((prev) => [...prev, clientMsg]);
    setIsAiThinking(true);

    let aiResponseText = '';
    let bullets: ChatMessage['bullets'] = undefined;

    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          client: currentClient.name,
          locale,
          retainerEGP: currentClient.retainerAmountEGP,
          recipientEmail: adminEmail
        })
      });

      if (res.ok) {
        const data = await res.json();
        aiResponseText = data.reply;
        if (data.bullets) bullets = data.bullets;
      }
    } catch {
      // Fallback
    }

    if (!aiResponseText) {
      aiResponseText =
        locale === 'ar'
          ? `تم استلام طلبك وتحديث معايير أمر العمل ومواءمتها مع حصة الرتينر بالجنيه المصري (${currentClient.retainerAmountEGP.toLocaleString()} ج.م). يمكنك إرسال الطلب مباشرة إلى بريدك الإلكتروني (${adminEmail}) بضغطة واحدة.`
          : `Understood. I have integrated your creative direction into the production brief and aligned it with your monthly retainer (${currentClient.retainerAmountEGP.toLocaleString()} EGP). You can dispatch this complete brief directly to your email (${adminEmail}) anytime.`;

      bullets = [
        {
          icon: 'mail',
          title: locale === 'ar' ? 'وجهة البريد المباشر' : 'Direct Email Dispatch',
          desc: adminEmail
        },
        {
          icon: 'play_circle',
          title: locale === 'ar' ? 'نوع المخرجة' : 'Deliverable Scope',
          desc: '4K Cinematic Fashion Reel (9:16) + 2x Editorial Stills'
        },
        {
          icon: 'payments',
          title: locale === 'ar' ? 'ميزانية الرتينر' : 'Retainer Balance',
          desc: `${currentClient.retainerAmountEGP.toLocaleString()} EGP / mo (14/18 used)`
        },
        {
          icon: 'photo_camera',
          title: locale === 'ar' ? 'المعدات وطاقم التصوير' : 'Production Rig',
          desc: 'Sony FX6 · Cooke Anamorphic · Sarah T. (Lead DP)'
        }
      ];
    }

    setIsAiThinking(false);

    const aiReply: ChatMessage = {
      id: `ai-${Date.now()}`,
      sender: 'ai',
      author: '91 Studio AI Director',
      time: locale === 'ar' ? 'الآن' : 'Just now',
      text: aiResponseText,
      bullets
    };
    setChatMessages((prev) => [...prev, aiReply]);
  };

  const addClientAccount = async (data: Partial<ClientAccount>) => {
    const rawName = data.name || 'New Client Partner';
    const payload = {
      name: rawName,
      nameAr: data.nameAr || rawName,
      industry: data.industry || 'Luxury Fashion & Creative',
      industryAr: data.industryAr || 'أزياء فاخرة وإبداع',
      location: data.location || 'Cairo & Dubai',
      locationAr: data.locationAr || 'القاهرة ودبي',
      primaryContact: data.primaryContact || 'Managing Director',
      email: data.email || 'contact@brand.com',
      phone: data.phone || '+20 100 000 0000',
      retainerTier: data.retainerTier || 'Tier B — Custom Retainer',
      retainerTierAr: data.retainerTierAr || 'الفئة ب — رتينر مخصص',
      retainerAmountEGP: Number(data.retainerAmountEGP) || 650000,
      totalDeliverablesQuota: Number(data.totalDeliverablesQuota) || 14,
      activeShootsCount: Number(data.activeShootsCount) || 1,
      badgeColor: data.badgeColor || '#ff7bb4',
      loginCode: data.loginCode,
      dueDay: data.dueDay,
      graceDays: data.graceDays,
    };

    try {
      const res = await fetch('/api/clients', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const result = await res.json();
      if (res.ok && result.client) {
        // Use the server's record as the source of truth — it has the real,
        // guaranteed-unique login code the client will actually sign in with.
        setClientAccounts((prev) => [result.client, ...prev]);
        showToast(
          locale === 'ar'
            ? `تم إضافة العميل الجديد (${result.client.name}) — كود الدخول: ${result.client.loginCode}`
            : `Client created for ${result.client.name} — login code: ${result.client.loginCode}`
        );
      } else {
        showToast(locale === 'ar' ? `فشل إنشاء العميل: ${result.error || ''}` : `Failed to create client: ${result.error || ''}`);
      }
    } catch {
      showToast(locale === 'ar' ? 'تعذر الاتصال بالخادم' : 'Could not reach the server.');
    }
  };

  const updateClientAccount = (id: string, updates: Partial<ClientAccount>) => {
    setClientAccounts((prev) =>
      prev.map((c) => (c.id === id ? { ...c, ...updates } : c))
    );
    showToast(
      locale === 'ar' ? 'تم تحديث صلاحيات وحساب العميل' : 'Client settings updated'
    );

    fetch(`/api/clients/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates)
    }).catch(() => {});
  };

  const deleteClientAccount = (id: string) => {
    setClientAccounts((prev) => prev.filter((c) => c.id !== id));
    showToast(
      locale === 'ar' ? 'تم إزالة حساب العميل' : 'Client account removed'
    );

    fetch(`/api/clients/${id}`, {
      method: 'DELETE'
    }).catch(() => {});
  };

  const toggleClientStatus = (id: string) => {
    setClientAccounts((prev) =>
      prev.map((c) => {
        if (c.id === id) {
          const nextStatus = c.status === 'active' ? 'suspended' : 'active';
          showToast(
            locale === 'ar'
              ? `تم تغيير حالة العميل إلى: ${nextStatus === 'active' ? 'نشط' : 'معلّق'}`
              : `Client account marked as ${nextStatus.toUpperCase()}`
          );
          fetch(`/api/clients/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status: nextStatus })
          }).catch(() => {});
          return { ...c, status: nextStatus };
        }
        return c;
      })
    );
  };

  return (
    <AppContext.Provider
      value={{
        locale,
        setLocale,
        toggleLocale,
        userRole,
        setUserRole,
        activeClientId,
        setActiveClientId,
        currentClient,
        clientAccounts,
        addClientAccount,
        updateClientAccount,
        deleteClientAccount,
        toggleClientStatus,
        clientUpdates,
        addClientUpdate,
        activeTab,
        setActiveTab,
        isVaultLocked,
        setIsVaultLocked,
        isLoadingClients,
        loginAsAdmin,
        loginAsClient,
        logout,
        updateClientPayment,
        activeDeliverableId,
        setActiveDeliverableId,
        isBriefModalOpen,
        setIsBriefModalOpen,
        deliverables,
        setDeliverables,
        addDeliverable,
        updateDeliverableStatus,
        requests,
        setRequests,
        updateRequestStatus,
        invoices,
        chatMessages,
        approveDeliverable,
        requestRevision,
        submitBrief,
        addChatMessage,
        isAiThinking,
        adminEmail,
        setAdminEmail,
        dispatchBriefToEmail,
        toastMessage,
        showToast
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
