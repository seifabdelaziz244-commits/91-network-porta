import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { CURRENT_CALL_SHEET, ASSETS } from '../data/mockData';
import { formatEGP } from '../utils/currency';
import { computeAccountStatus, STATUS_LABEL, STATUS_COLOR } from '../utils/accountStatus';

export const HomeDashboard: React.FC = () => {
  const {
    locale,
    userRole,
    currentClient,
    clientUpdates,
    setActiveTab,
    setActiveDeliverableId,
    setIsBriefModalOpen,
    deliverables,
    requests,
    showToast
  } = useApp();

  const isAr = locale === 'ar';
  const isAdmin = userRole === 'agency_admin';
  const [aiPrompt, setAiPrompt] = useState('');

  const handleSendPrompt = (textToSend?: string) => {
    const prompt = textToSend || aiPrompt;
    if (!prompt.trim()) return;
    setIsBriefModalOpen(true);
    setAiPrompt('');
  };

  const pendingDeliverable = deliverables.find((d) => d.status === 'action_required') || deliverables[0];

  return (
    <div className="pt-20 pb-24 px-4 max-w-xl mx-auto space-y-6">
      {/* Admin Quick Control Strip (Shown if viewing as admin) */}
      {isAdmin && (
        <div className="p-3 rounded-2xl bg-gradient-to-r from-[#201f21] to-[#1b1b1d] border border-[#ff7bb4]/50 flex items-center justify-between shadow-lg">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#ff7bb4] animate-pulse"></span>
            <span className="text-xs font-mono text-[#ffb0cd] font-bold">
              {isAr
                ? `وضع مسؤول الوكالة · تدير حالياً: ${currentClient.nameAr}`
                : `Agency Admin Mode · Managing: ${currentClient.name}`}
            </span>
          </div>
          <button
            onClick={() => setActiveTab('admin')}
            className="px-2.5 py-1 rounded-lg bg-[#ff7bb4] text-[#780846] text-xs font-bold font-mono hover:opacity-95 transition-opacity flex items-center gap-1"
          >
            <span className="material-symbols-outlined text-[15px]">admin_panel_settings</span>
            <span>{isAr ? 'لوحة الإدارة' : 'Admin Hub'}</span>
          </button>
        </div>
      )}

      {/* Welcome Banner */}
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span className="font-mono text-[10px] text-emerald-400 font-bold uppercase tracking-widest">
              {isAr ? 'كافة الأنظمة تعمل بكفاءة' : 'ALL SYSTEMS CLEAR'}
            </span>
          </div>
          <h1 className="font-headline text-2xl font-bold text-[#e5e1e4] tracking-tight">
            {isAdmin
              ? isAr
                ? 'مرحباً، كريم م. (مدير الوكالة)'
                : 'Welcome, Karim M. (Agency Admin)'
              : isAr
              ? `صباح الخير، ${currentClient.primaryContact}`
              : `Good morning, ${currentClient.primaryContact}`}
          </h1>
          <p className="text-xs text-[#dbc0c7] mt-0.5">
            {isAr
              ? `${currentClient.nameAr} · إنتاج الأسبوع 43 نشط`
              : `${currentClient.name} · Week 43 Production Active`}
          </p>
        </div>
        <div className="px-2.5 py-1 rounded-full bg-[#1b1b1d] border border-[#2a2a2c] text-[10px] font-mono text-[#ffb0cd]">
          {isAr ? currentClient.retainerTierAr : currentClient.retainerTier}
        </div>
      </div>

      {/* Payment / Contract Status (client-facing) */}
      {!isAdmin &&
        (() => {
          const st = computeAccountStatus(currentClient);
          if (st === 'paid') return null; // don't clutter the home screen when everything's fine
          return (
            <div
              className="p-3 rounded-2xl border flex items-center gap-3"
              style={{ backgroundColor: `${STATUS_COLOR[st]}14`, borderColor: `${STATUS_COLOR[st]}55` }}
            >
              <span className="material-symbols-outlined text-[20px]" style={{ color: STATUS_COLOR[st] }}>
                {st === 'critical' || st === 'terminated' ? 'error' : 'info'}
              </span>
              <div className="flex-1">
                <div className="text-xs font-bold font-headline" style={{ color: STATUS_COLOR[st] }}>
                  {STATUS_LABEL[st][isAr ? 'ar' : 'en']}
                </div>
                <div className="text-[10px] text-[#a38a92] font-mono mt-0.5">
                  {isAr
                    ? `${formatEGP(currentClient.retainerAmountEGP, locale)} شهرياً · يوم الاستحقاق ${currentClient.dueDay ?? 1} · مهلة ${currentClient.graceDays ?? 5} أيام`
                    : `${formatEGP(currentClient.retainerAmountEGP, locale)}/mo · Due day ${currentClient.dueDay ?? 1} · ${currentClient.graceDays ?? 5}-day grace`}
                </div>
              </div>
            </div>
          );
        })()}

      {/* Upcoming Production Hero Shoot Card */}
      <div className="relative rounded-2xl overflow-hidden border border-[#554248]/40 bg-[#1b1b1d] shadow-xl group">
        <div className="relative h-48 sm:h-52 w-full overflow-hidden">
          <img
            src={CURRENT_CALL_SHEET.heroImage}
            alt="Shoot Hero"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#1b1b1d] via-[#1b1b1d]/40 to-transparent"></div>

          {/* Top Badges */}
          <div className="absolute top-3 inset-x-3 flex items-center justify-between">
            <span className="px-2.5 py-1 rounded-md bg-[#131315]/80 backdrop-blur-md text-[10px] font-mono font-bold text-[#ffb0cd] border border-[#ff7bb4]/30 uppercase tracking-wider">
              {isAr ? 'جلسة إنتاج قادمة' : 'UPCOMING PRODUCTION'}
            </span>
            <span className="px-2.5 py-1 rounded-md bg-emerald-500/20 backdrop-blur-md text-[10px] font-mono font-bold text-emerald-300 border border-emerald-500/30 uppercase tracking-wider flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              {isAr ? CURRENT_CALL_SHEET.countdownAr : CURRENT_CALL_SHEET.countdown}
            </span>
          </div>

          {/* Bottom Overlay Info */}
          <div className="absolute bottom-3 inset-x-3">
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2 py-0.5 rounded bg-[#131315]/80 backdrop-blur-md text-[10px] font-mono text-[#dbc0c7]">
                Sony FX6 · 35mm
              </span>
              <span className="px-2 py-0.5 rounded bg-[#131315]/80 backdrop-blur-md text-[10px] font-mono text-[#dbc0c7]">
                Cooke Anamorphic
              </span>
            </div>
            <h3 className="font-headline text-lg sm:text-xl font-bold text-[#e5e1e4] leading-snug drop-shadow-md">
              {isAr ? CURRENT_CALL_SHEET.titleAr : CURRENT_CALL_SHEET.title}
            </h3>
          </div>
        </div>

        {/* Card Body Details */}
        <div className="p-4 space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-[#dbc0c7]">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-[16px] text-[#ff7bb4]">event</span>
              <span>{isAr ? CURRENT_CALL_SHEET.dateAr : CURRENT_CALL_SHEET.date}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-[16px] text-[#ff7bb4]">schedule</span>
              <span>{isAr ? CURRENT_CALL_SHEET.timeAr : CURRENT_CALL_SHEET.time}</span>
            </div>
            <div className="flex items-center gap-2 sm:col-span-2">
              <span className="material-symbols-outlined text-[16px] text-[#ff7bb4]">pin_drop</span>
              <span className="truncate">
                {isAr ? CURRENT_CALL_SHEET.locationAr : CURRENT_CALL_SHEET.location}
              </span>
            </div>
          </div>

          {/* Crew Avatar Strip */}
          <div className="pt-2 border-t border-[#2a2a2c] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="flex -space-x-2">
                {CURRENT_CALL_SHEET.crew.slice(0, 3).map((c, i) => (
                  <div
                    key={i}
                    className="w-7 h-7 rounded-full bg-[#2a2a2c] border-2 border-[#1b1b1d] flex items-center justify-center text-[10px] font-mono font-bold text-[#ffb0cd]"
                    title={`${c.name} (${c.role})`}
                  >
                    {c.initials}
                  </div>
                ))}
              </div>
              <span className="text-[11px] font-mono text-[#dbc0c7]">
                {isAr ? '3 أفراد طاقم أساسيون' : '3 CREW CONFIRMED'}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveTab('shoots')}
                className="px-3 py-1.5 rounded-lg bg-[#201f21] hover:bg-[#2a2a2c] text-xs font-mono text-[#dbc0c7] hover:text-[#e5e1e4] border border-[#2a2a2c] transition-colors"
              >
                {isAr ? 'أمر العمل (Call Sheet)' : 'Call Sheet'}
              </button>
              <button
                onClick={() => setActiveTab('shoots')}
                className="px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-[#ff7bb4] to-[#ffb0cd] text-[#780846] text-xs font-headline font-bold hover:opacity-95 shadow-sm transition-all"
              >
                {isAr ? 'إدارة الجلسة' : 'Manage'}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Account Retainer Progress Card */}
      <div className="p-4 rounded-2xl bg-[#1b1b1d] border border-[#2a2a2c] space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-[10px] font-mono uppercase text-[#a38a92] tracking-wider">
              {isAr ? 'باقة الحساب الجارية' : 'ACCOUNT RETAINER (EGP)'}
            </div>
            <div className="text-sm font-headline font-bold text-[#e5e1e4]">
              {isAr ? currentClient.retainerTierAr : currentClient.retainerTier} · <span className="text-[#ffb0cd] font-mono">{formatEGP(currentClient.retainerAmountEGP, locale)}/mo</span>
            </div>
          </div>
          <button
            onClick={() => setActiveTab('more')}
            className="text-[11px] font-mono text-[#ffb0cd] hover:underline"
          >
            {isAr ? 'سجل الفواتير ←' : 'View Ledger →'}
          </button>
        </div>

        {/* Deliverables Bar */}
        <div className="space-y-1">
          <div className="flex items-center justify-between text-[11px]">
            <span className="text-[#dbc0c7]">
              {isAr ? 'مخرجات المحتوى الرقمي' : 'Digital Content Deliverables'}
            </span>
            <span className="font-mono text-[#e5e1e4]">
              <strong className="text-[#ff7bb4]">{currentClient.activeDeliverablesCount}</strong> / {currentClient.totalDeliverablesQuota} ({isAr ? `${currentClient.totalDeliverablesQuota - currentClient.activeDeliverablesCount} متبقية` : `${currentClient.totalDeliverablesQuota - currentClient.activeDeliverablesCount} remaining`})
            </span>
          </div>
          <div className="w-full h-2 rounded-full bg-[#201f21] overflow-hidden">
            <div
              className="h-full rounded-full bg-gradient-to-r from-[#ff7bb4] to-[#ffb0cd]"
              style={{ width: `${Math.round((currentClient.activeDeliverablesCount / currentClient.totalDeliverablesQuota) * 100)}%` }}
            ></div>
          </div>
        </div>

        {/* Shoots & Hours Grid */}
        <div className="grid grid-cols-2 gap-3 pt-1 text-[11px]">
          <div className="p-2.5 rounded-xl bg-[#201f21] border border-[#2a2a2c]/60">
            <div className="text-[#a38a92] font-mono text-[10px]">
              {isAr ? 'جلسات التصوير الميداني' : 'Production Shoots'}
            </div>
            <div className="text-xs font-bold text-[#e5e1e4] mt-0.5">{currentClient.activeShootsCount} Shoots</div>
            <div className="text-[10px] text-emerald-400 mt-0.5">
              {isAr ? 'مجدولة بالكامل' : 'Locked on Schedule'}
            </div>
          </div>
          <div className="p-2.5 rounded-xl bg-[#201f21] border border-[#2a2a2c]/60">
            <div className="text-[#a38a92] font-mono text-[10px]">
              {isAr ? 'ساعات التصميم الإبداعي' : 'Creative Design Hours'}
            </div>
            <div className="text-xs font-bold text-[#e5e1e4] mt-0.5">32 / 40 Hours</div>
            <div className="text-[10px] text-[#ffb0cd] mt-0.5">
              {isAr ? '8 ساعات متبقية' : '8 hrs reserve'}
            </div>
          </div>
        </div>
      </div>

      {/* Agency Live Updates Feed (Keeps clients updated in real-time) */}
      <div className="p-4 rounded-2xl bg-[#1b1b1d] border border-[#2a2a2c] space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span className="font-headline text-xs font-bold text-[#e5e1e4] uppercase tracking-wider">
              {isAr ? 'تحديثات إدارة الوكالة المباشرة' : 'Live Updates from Agency Operations'}
            </span>
          </div>
          <span className="text-[10px] font-mono text-[#ffb0cd]">91 NETWORK DISPATCH</span>
        </div>

        <div className="space-y-2">
          {clientUpdates.slice(0, 2).map((upd) => (
            <div
              key={upd.id}
              className="p-3 rounded-xl bg-[#201f21] border border-[#2a2a2c]/60 space-y-1 text-xs"
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-[#e5e1e4]">
                  {isAr ? upd.titleAr : upd.title}
                </span>
                <span className="text-[10px] font-mono text-[#a38a92]">{upd.timestamp}</span>
              </div>
              <p className="text-[11px] text-[#dbc0c7] leading-relaxed">
                {isAr ? upd.bodyAr : upd.body}
              </p>
              <div className="text-[10px] font-mono text-[#ffb0cd] pt-1 flex items-center justify-between">
                <span>By {upd.author} ({upd.authorRole})</span>
                <span className="text-emerald-400 uppercase tracking-wider">{upd.type}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Review Pending Deliverables Quick Action Banner */}
      {pendingDeliverable && (
        <div
          onClick={() => setActiveDeliverableId(pendingDeliverable.id)}
          className="p-3.5 rounded-xl bg-gradient-to-r from-[#7c2d4c]/40 to-[#1b1b1d] border border-[#ff7bb4]/50 flex items-center justify-between cursor-pointer hover:border-[#ff7bb4] transition-all shadow-md group"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#ff7bb4] text-[#780846] flex items-center justify-center font-bold group-hover:scale-105 transition-transform">
              <span className="material-symbols-outlined text-[24px]">play_arrow</span>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-[#e5e1e4]">
                  {isAr ? 'مراجعة المخرجات المعلقة' : 'Review Pending Deliverable'}
                </span>
                <span className="px-1.5 py-0.2 rounded bg-[#ff7bb4] text-[#780846] text-[9px] font-mono font-bold">
                  ACTION REQUIRED
                </span>
              </div>
              <p className="text-[11px] text-[#dbc0c7] truncate max-w-xs mt-0.5">
                {isAr ? pendingDeliverable.titleAr : pendingDeliverable.title}
              </p>
            </div>
          </div>
          <span className="material-symbols-outlined text-[#ffb0cd] group-hover:translate-x-1 transition-transform">
            {isAr ? 'arrow_back' : 'arrow_forward'}
          </span>
        </div>
      )}

      {/* Upcoming Content Horizontal Reel */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <h2 className="font-headline text-sm font-bold text-[#e5e1e4] uppercase tracking-wider">
            {isAr ? 'مخرجات المحتوى القادمة' : 'Upcoming Content'}
          </h2>
          <button
            onClick={() => setActiveTab('content')}
            className="text-[11px] font-mono text-[#ffb0cd] hover:underline"
          >
            {isAr ? 'عرض الجدول الزمني ←' : 'Full Calendar →'}
          </button>
        </div>

        <div className="flex gap-3 overflow-x-auto no-scrollbar pb-1">
          {deliverables.map((item) => (
            <div
              key={item.id}
              onClick={() => setActiveDeliverableId(item.id)}
              className="flex-shrink-0 w-64 p-3 rounded-xl bg-[#1b1b1d] border border-[#2a2a2c] hover:border-[#ff7bb4]/50 transition-all cursor-pointer space-y-2 group"
            >
              <div className="relative h-32 rounded-lg overflow-hidden bg-[#201f21]">
                <img
                  src={item.posterImage}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                />
                <div className="absolute top-2 left-2 px-1.5 py-0.5 rounded bg-[#131315]/80 text-[10px] font-mono text-[#ffb0cd] uppercase">
                  {item.type}
                </div>
                {item.duration && (
                  <div className="absolute bottom-2 right-2 px-1.5 py-0.5 rounded bg-black/80 text-[10px] font-mono text-white">
                    {item.duration}
                  </div>
                )}
              </div>
              <div>
                <div className="text-xs font-semibold text-[#e5e1e4] line-clamp-1">
                  {isAr ? item.titleAr : item.title}
                </div>
                <div className="flex items-center justify-between text-[10px] text-[#dbc0c7] mt-1 font-mono">
                  <span>{item.scheduledDate}</span>
                  <span
                    className={
                      item.status === 'action_required'
                        ? 'text-[#ff7bb4] font-bold'
                        : item.status === 'scheduled'
                        ? 'text-emerald-400'
                        : 'text-amber-400'
                    }
                  >
                    {item.status.replace('_', ' ').toUpperCase()}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Active Requests Mini-Board */}
      <div className="p-4 rounded-2xl bg-[#1b1b1d] border border-[#2a2a2c] space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="font-headline text-sm font-bold text-[#e5e1e4] uppercase tracking-wider">
              {isAr ? 'طلبات الإنتاج النشطة' : 'Active Production Requests'}
            </span>
            <span className="px-2 py-0.5 rounded-full bg-[#201f21] text-[#ff7bb4] font-mono text-[10px]">
              {requests.length}
            </span>
          </div>
          <button
            onClick={() => setIsBriefModalOpen(true)}
            className="px-2.5 py-1 rounded-lg bg-[#201f21] hover:bg-[#2a2a2c] text-[#ffb0cd] text-[11px] font-mono border border-[#554248]/40 transition-colors flex items-center gap-1"
          >
            <span>+</span>
            <span>{isAr ? 'طلب جديد' : 'New Request'}</span>
          </button>
        </div>

        <div className="space-y-2">
          {requests.slice(0, 3).map((req) => (
            <div
              key={req.id}
              onClick={() => setActiveTab('requests')}
              className="p-2.5 rounded-xl bg-[#201f21] hover:bg-[#2a2a2c] transition-colors border border-[#2a2a2c]/60 flex items-center justify-between cursor-pointer"
            >
              <div className="min-w-0 pr-2">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-[10px] text-[#ff7bb4] font-bold">{req.code}</span>
                  <span className="text-xs font-semibold text-[#e5e1e4] truncate">
                    {isAr ? req.titleAr : req.title}
                  </span>
                </div>
                <div className="text-[10px] text-[#a38a92] mt-0.5 flex items-center gap-2 font-mono">
                  <span>{isAr ? req.typeLabelAr : req.typeLabel}</span>
                  <span>·</span>
                  <span>{isAr ? req.dueTextAr : req.dueText}</span>
                </div>
              </div>
              <span
                className={`px-2 py-0.5 rounded text-[9px] font-mono font-bold flex-shrink-0 ${
                  req.status === 'in_progress'
                    ? 'bg-[#ff7bb4]/20 text-[#ffb0cd]'
                    : req.status === 'awaiting_feedback'
                    ? 'bg-amber-500/20 text-amber-300'
                    : 'bg-[#2a2a2c] text-[#dbc0c7]'
                }`}
              >
                {isAr ? req.statusLabelAr : req.statusLabel}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Ask AI Account Director Prompt Dock */}
      <div className="p-4 rounded-2xl bg-gradient-to-b from-[#1b1b1d] to-[#131315] border border-[#ff7bb4]/30 shadow-lg space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[18px] text-[#ff7bb4] animate-spin">
              auto_awesome
            </span>
            <span className="font-headline text-xs font-bold text-[#e5e1e4] uppercase tracking-wider">
              {isAr ? 'المدير الإبداعي الذكي (Lumen AI)' : 'Ask AI Account Director'}
            </span>
          </div>
          <span className="text-[10px] font-mono text-[#a38a92]">v2.4 ONLINE</span>
        </div>

        {/* Quick Suggestion Chips */}
        <div className="flex gap-1.5 flex-wrap">
          {[
            {
              en: '⚡ Request a new Reel',
              ar: '⚡ طلب ريل جديد',
              prompt: 'We need a new 4K 9:16 Fashion Reel for the Trench Coat collection.'
            },
            {
              en: '📸 Book extra shoot',
              ar: '📸 حجز جلسة إضافية',
              prompt: 'We want to book a half-day studio session in Alserkal Avenue.'
            },
            {
              en: '🎨 Ask for revisions',
              ar: '🎨 طلب تعديل الألوان',
              prompt: 'Please adjust color grade on the Lookbook stills to match Kodak 5219.'
            }
          ].map((chip, idx) => (
            <button
              key={idx}
              onClick={() => handleSendPrompt(chip.prompt)}
              className="px-2.5 py-1 rounded-full bg-[#201f21] hover:bg-[#2a2a2c] border border-[#2a2a2c] text-[11px] text-[#dbc0c7] hover:text-[#ffb0cd] transition-colors"
            >
              {isAr ? chip.ar : chip.en}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="relative">
          <input
            type="text"
            value={aiPrompt}
            onChange={(e) => setAiPrompt(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleSendPrompt();
            }}
            placeholder={
              isAr
                ? 'اكتب طلبك الإبداعي أو استفسر عن جدول الإنتاج...'
                : 'Describe a deliverable, request revisions, or ask anything...'
            }
            className={`w-full h-11 rounded-xl bg-[#201f21] border border-[#2a2a2c] focus:border-[#ff7bb4] text-xs text-[#e5e1e4] placeholder-[#554248] focus:outline-none transition-colors ${
              isAr ? 'pr-3 pl-11' : 'pl-3 pr-11'
            }`}
          />
          <button
            onClick={() => handleSendPrompt()}
            className={`absolute top-1/2 -translate-y-1/2 w-8 h-8 rounded-lg bg-[#ff7bb4] hover:bg-[#ffb0cd] text-[#780846] flex items-center justify-center transition-colors cursor-pointer ${
              isAr ? 'left-1.5' : 'right-1.5'
            }`}
          >
            <span className="material-symbols-outlined text-[18px]">
              {isAr ? 'arrow_back' : 'arrow_forward'}
            </span>
          </button>
        </div>
      </div>

      {/* Lumen Studio Cloud Vault Shortcut */}
      <div className="p-3.5 rounded-xl bg-[#1b1b1d] border border-[#2a2a2c] flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-[#201f21] border border-[#2a2a2c] flex items-center justify-center text-[#ffb0cd]">
            <span className="material-symbols-outlined text-[20px]">cloud_download</span>
          </div>
          <div>
            <div className="text-xs font-semibold text-[#e5e1e4]">
              {isAr ? 'سحابة أرشيف لومن الرقمية' : 'Lumen Studio Cloud Vault'}
            </div>
            <div className="text-[10px] font-mono text-[#a38a92]">
              Master 4K RAWs, ProRes Deliverables & Brand Guidelines
            </div>
          </div>
        </div>
        <button
          onClick={() =>
            showToast(
              isAr
                ? 'جاري فتح مجلد الأرشيف السحابي الرئيسي (Drive Vault)...'
                : 'Opening Master Cloud Archive Vault...'
            )
          }
          className="px-2.5 py-1 rounded bg-[#201f21] hover:bg-[#2a2a2c] text-[#dbc0c7] hover:text-[#e5e1e4] text-[11px] font-mono border border-[#554248]/40 transition-colors"
        >
          {isAr ? 'فتح السحابة' : 'Open Vault'}
        </button>
      </div>
    </div>
  );
};
