import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ASSETS } from '../data/mockData';

export const VaultLogin: React.FC = () => {
  const { locale, loginAsAdmin, loginAsClient } = useApp();
  const isAr = locale === 'ar';

  const [selectedRole, setSelectedRole] = useState<'client' | 'agency_admin'>('agency_admin');
  const [password, setPassword] = useState('');
  const [code, setCode] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleLogin = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setError(null);
    setIsAuthenticating(true);

    const result =
      selectedRole === 'agency_admin' ? await loginAsAdmin(password) : await loginAsClient(code);

    setIsAuthenticating(false);
    if (!result.success) {
      setError(result.error || (isAr ? 'فشل تسجيل الدخول.' : 'Sign in failed.'));
    }
  };

  return (
    <div className="relative min-h-screen bg-[#131315] text-[#e5e1e4] flex flex-col justify-between overflow-x-hidden pt-20 pb-12 px-4 selection:bg-[#ff7bb4] selection:text-[#780846]">
      <div className="absolute top-0 inset-x-0 h-96 bg-gradient-to-b from-[#ff7bb4]/10 via-[#7c2d4c]/5 to-transparent pointer-events-none blur-3xl"></div>

      <div className="max-w-md w-full mx-auto relative z-10 flex flex-col items-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#1b1b1d] border border-[#2a2a2c] text-[#dbc0c7] text-[11px] font-mono tracking-wider mb-5 shadow-sm">
          <span className="material-symbols-outlined text-[14px] text-[#ff7bb4]">verified_user</span>
          <span>
            {isAr
              ? 'نظام الوصول الموحد للوكالة والعملاء · بالجنيه المصري (EGP)'
              : 'Unified Agency & Client Access · EGP Currency Protocol'}
          </span>
        </div>

        <div className="relative mb-4 group">
          <div className="w-16 h-16 rounded-2xl bg-[#1b1b1d] border border-[#554248]/50 flex items-center justify-center p-2.5 shadow-[0_0_30px_rgba(255,123,180,0.15)] group-hover:border-[#ff7bb4] transition-all">
            <img src={ASSETS.emblem} alt="91 NET WORK Emblem" className="w-full h-full object-contain filter drop-shadow" />
          </div>
          <div className="absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full bg-emerald-500 ring-2 ring-[#131315] flex items-center justify-center">
            <div className="w-1.5 h-1.5 rounded-full bg-white animate-pulse"></div>
          </div>
        </div>

        <div className="text-center mb-5">
          <h1 className="font-headline text-xl font-bold text-[#e5e1e4] tracking-tight">
            {isAr ? 'بوابة شبكة 91 للإنتاج الفاخر' : '91` Network Luxury Intelligence'}
          </h1>
          <p className="font-sans text-xs text-[#dbc0c7] mt-0.5 tracking-wide">
            {isAr ? 'تسجيل الدخول كوكالة (مسؤول) أو كعميل' : 'Sign in as Agency Admin or Client Account'}
          </p>
        </div>

        <div className="w-full p-1.5 rounded-2xl bg-[#1b1b1d] border border-[#ff7bb4]/30 mb-4 grid grid-cols-2 gap-1.5 shadow-lg">
          <button
            type="button"
            onClick={() => {
              setSelectedRole('agency_admin');
              setError(null);
            }}
            className={`py-2.5 px-3 rounded-xl text-xs font-headline font-bold flex flex-col items-center justify-center gap-0.5 transition-all cursor-pointer ${
              selectedRole === 'agency_admin'
                ? 'bg-gradient-to-r from-[#ff7bb4] to-[#ffb0cd] text-[#780846] shadow-md'
                : 'text-[#dbc0c7] hover:text-[#e5e1e4] hover:bg-[#201f21]'
            }`}
          >
            <div className="flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[16px]">shield_person</span>
              <span>{isAr ? 'دخول الوكالة (مسؤول)' : 'Agency Admin'}</span>
            </div>
            <span className={`text-[9px] font-mono ${selectedRole === 'agency_admin' ? 'text-[#780846]/90' : 'text-[#a38a92]'}`}>
              {isAr ? 'إدارة كل العملاء والمحتوى' : 'Manage All Clients & Content'}
            </span>
          </button>

          <button
            type="button"
            onClick={() => {
              setSelectedRole('client');
              setError(null);
            }}
            className={`py-2.5 px-3 rounded-xl text-xs font-headline font-bold flex flex-col items-center justify-center gap-0.5 transition-all cursor-pointer ${
              selectedRole === 'client'
                ? 'bg-gradient-to-r from-[#ff7bb4] to-[#ffb0cd] text-[#780846] shadow-md'
                : 'text-[#dbc0c7] hover:text-[#e5e1e4] hover:bg-[#201f21]'
            }`}
          >
            <div className="flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[16px]">person</span>
              <span>{isAr ? 'دخول العميل' : 'Client Portal'}</span>
            </div>
            <span className={`text-[9px] font-mono ${selectedRole === 'client' ? 'text-[#780846]/90' : 'text-[#a38a92]'}`}>
              {isAr ? 'مراجعة المخرجات والرتينر' : 'Review Deliverables & Shoots'}
            </span>
          </button>
        </div>

        <form onSubmit={handleLogin} className="w-full space-y-3.5">
          {selectedRole === 'agency_admin' ? (
            <div>
              <label className="text-[11px] font-mono uppercase text-[#dbc0c7] block mb-1 px-0.5">
                {isAr ? 'كلمة مرور مسؤول الوكالة' : 'Agency Admin Password'}
              </label>
              <div className="relative">
                <span className={`material-symbols-outlined absolute top-1/2 -translate-y-1/2 text-[18px] text-[#a38a92] ${isAr ? 'right-3' : 'left-3'}`}>
                  lock
                </span>
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  autoFocus
                  className={`w-full h-10 rounded-xl bg-[#1b1b1d] border border-[#2a2a2c] focus:border-[#ff7bb4] text-xs font-mono text-[#e5e1e4] placeholder-[#554248] focus:outline-none transition-colors ${
                    isAr ? 'pr-10 pl-10' : 'pl-10 pr-10'
                  }`}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className={`absolute top-1/2 -translate-y-1/2 text-[#a38a92] hover:text-[#e5e1e4] transition-colors ${isAr ? 'left-3' : 'right-3'}`}
                >
                  <span className="material-symbols-outlined text-[18px]">{showPassword ? 'visibility_off' : 'visibility'}</span>
                </button>
              </div>
            </div>
          ) : (
            <div>
              <label className="text-[11px] font-mono uppercase text-[#dbc0c7] block mb-1 px-0.5">
                {isAr ? 'كود دخول العميل' : 'Client Login Code'}
              </label>
              <div className="relative">
                <span className={`material-symbols-outlined absolute top-1/2 -translate-y-1/2 text-[18px] text-[#a38a92] ${isAr ? 'right-3' : 'left-3'}`}>
                  key
                </span>
                <input
                  type="text"
                  value={code}
                  onChange={(e) => setCode(e.target.value.toUpperCase())}
                  autoFocus
                  placeholder={isAr ? 'مثال: K7XQ2P' : 'e.g. K7XQ2P'}
                  className={`w-full h-10 rounded-xl bg-[#1b1b1d] border border-[#2a2a2c] focus:border-[#ff7bb4] text-xs font-mono tracking-[0.2em] text-[#e5e1e4] placeholder-[#554248] focus:outline-none transition-colors ${
                    isAr ? 'pr-10 pl-3' : 'pl-10 pr-3'
                  }`}
                />
              </div>
              <p className="text-[10px] text-[#a38a92] mt-1.5">
                {isAr ? 'هذا الكود بتاعك من الوكالة.' : "This is the code your agency gave you."}
              </p>
            </div>
          )}

          {error && <div className="text-[11px] font-mono text-rose-400 px-0.5">{error}</div>}

          <button
            type="submit"
            disabled={isAuthenticating}
            className="w-full h-11 rounded-xl bg-gradient-to-r from-[#ff7bb4] to-[#ffb0cd] hover:opacity-95 text-[#780846] font-headline font-bold text-xs flex items-center justify-center gap-2 shadow-[0_0_24px_rgba(255,123,180,0.3)] transition-all cursor-pointer disabled:opacity-50"
          >
            {isAuthenticating ? (
              <div className="flex items-center gap-2">
                <span className="w-4 h-4 rounded-full border-2 border-[#780846] border-t-transparent animate-spin"></span>
                <span>{isAr ? 'جاري التحقق...' : 'Signing in...'}</span>
              </div>
            ) : (
              <>
                <span>
                  {selectedRole === 'agency_admin'
                    ? isAr
                      ? 'دخول كمسؤول وكالة'
                      : 'Sign In as Agency Admin'
                    : isAr
                    ? 'دخول بوابة العميل'
                    : 'Sign In to Client Portal'}
                </span>
                <span className="material-symbols-outlined text-[18px]">{isAr ? 'arrow_back' : 'arrow_forward'}</span>
              </>
            )}
          </button>
        </form>

        <div className="w-full mt-5 p-2 rounded-xl bg-[#0e0e10] border border-[#2a2a2c]/60 flex items-center justify-between text-[10px] font-mono text-[#a38a92]">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>
              {isAr ? 'خوادم الإنتاج: القاهرة ودبي · الحسابات بالجنيه المصري (EGP)' : 'Nodes: Cairo & Dubai · Currency: Egyptian Pound (EGP)'}
            </span>
          </div>
          <span className="text-emerald-400 font-bold">100% ONLINE</span>
        </div>
      </div>
    </div>
  );
};
