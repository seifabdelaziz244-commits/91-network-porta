// Vercel routes every request under /api/* to this single serverless function.
// The Express app itself (server.ts) defines all the real routes.
import app from '../server';

export default app;
