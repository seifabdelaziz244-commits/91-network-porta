import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { formatEGP } from '../utils/currency';

export const RetainerBilling: React.FC = () => {
  const { locale, invoices, currentClient, showToast } = useApp();
  const isAr = locale === 'ar';

  const [invoiceFilter, setInvoiceFilter] = useState<'all' | 'paid' | 'upcoming'>('all');

  const filteredInvoices = invoices.filter((inv) => {
    if (invoiceFilter === 'paid') return inv.status === 'paid';
    if (invoiceFilter === 'upcoming') return inv.status === 'scheduled';
    return true;
  });

  const addons = [
    {
      titleEn: '1x 4K Fashion Reel Add-on',
      titleAr: 'إضافة ريل أزياء 4K سينمائي',
      descEn: 'Includes Lead DP, color grade & sound sync',
      descAr: 'يشمل مدير التصوير، تدرج الألوان وهندسة الصوت',
      amountEGP: 110000
    },
    {
      titleEn: 'Half-Day Studio Shoot (Alserkal / Zamalek)',
      titleAr: 'نصف يوم تصوير استوديو (الزمالك / السركال)',
      descEn: 'Warehouse 4 with 3 core crew members',
      descAr: 'المستودع 4 مع 3 أفراد من طاقم العمل الأساسي',
      amountEGP: 175000
    },
    {
      titleEn: 'Express Color Grade & Master (24h)',
      titleAr: 'تلوين فوري وتسليم ماستر (24 ساعة)',
      descEn: 'Custom Kodak 5219 LUT calibrated output',
      descAr: 'مخرجات بمعايرة كوداك 5219 LUT الخاصة',
      amountEGP: 37500
    }
  ];

  return (
    <div className="pt-20 pb-24 px-4 max-w-xl mx-auto space-y-5">
      {/* Header */}
      <div>
        <div className="flex items-center justify-between">
          <h1 className="font-headline text-xl font-bold text-[#e5e1e4] tracking-tight">
            {isAr ? 'حساب الرتينر والفواتير (بالجنيه المصري)' : 'Retainer & Billing (EGP Ledger)'}
          </h1>
          <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-mono text-[10px] border border-emerald-500/30">
            EGP PROTOCOL
          </span>
        </div>
        <p className="text-xs text-[#dbc0c7] mt-0.5">
          {isAr
            ? `إدارة عقود ${currentClient.nameAr}، الوحدات الإنتاجية وسجل المدفوعات بالجنيه المصري`
            : `Capacity units, agreement allocation & financial ledger for ${currentClient.name}`}
        </p>
      </div>

      {/* Active Agreement Card */}
      <div className="p-4 rounded-2xl bg-[#1b1b1d] border border-[#2a2a2c] space-y-4 shadow-xl">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-[10px] font-mono uppercase text-[#a38a92] tracking-wider">
              {isAr ? 'العقد النشط' : 'ACTIVE AGREEMENT'}
            </div>
            <h2 className="font-headline text-base font-bold text-[#e5e1e4] mt-0.5">
              {isAr ? currentClient.retainerTierAr : currentClient.retainerTier}
            </h2>
            <div className="text-xs font-mono text-[#ffb0cd] mt-0.5">
              {formatEGP(currentClient.retainerAmountEGP, locale)} / {isAr ? 'شهرياً' : 'month'}
            </div>
          </div>
          <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-mono font-bold">
            ACTIVE
          </span>
        </div>

        {/* Quota Progress */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <span className="text-[#dbc0c7]">
              {isAr ? 'المخرجات المستهلكة هذا الشهر' : 'Quota Utilized this Cycle'}
            </span>
            <span className="font-mono text-[#e5e1e4]">
              <strong>{currentClient.activeDeliverablesCount}</strong> / {currentClient.totalDeliverablesQuota} Deliverables ({Math.round((currentClient.activeDeliverablesCount / currentClient.totalDeliverablesQuota) * 100)}%)
            </span>
          </div>
          <div className="w-full h-2.5 rounded-full bg-[#201f21] overflow-hidden">
            <div
              className="h-full rounded-full bg-gradient-to-r from-[#ff7bb4] to-[#ffb0cd]"
              style={{ width: `${Math.round((currentClient.activeDeliverablesCount / currentClient.totalDeliverablesQuota) * 100)}%` }}
            ></div>
          </div>
        </div>

        {/* Breakdown Grid */}
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="p-2.5 rounded-xl bg-[#201f21] border border-[#2a2a2c]/60">
            <div className="text-[10px] font-mono text-[#a38a92]">4K VIDEO REELS</div>
            <div className="font-bold text-[#e5e1e4] mt-0.5">6 / 8 Reels</div>
            <div className="text-[10px] text-[#ffb0cd] mt-0.5">2 Available</div>
          </div>

          <div className="p-2.5 rounded-xl bg-[#201f21] border border-[#2a2a2c]/60">
            <div className="text-[10px] font-mono text-[#a38a92]">EDITORIAL STILLS</div>
            <div className="font-bold text-[#e5e1e4] mt-0.5">6 / 6 Stills</div>
            <div className="text-[10px] text-emerald-400 mt-0.5">Quota Full</div>
          </div>

          <div className="p-2.5 rounded-xl bg-[#201f21] border border-[#2a2a2c]/60">
            <div className="text-[10px] font-mono text-[#a38a92]">PRODUCTION SHOOTS</div>
            <div className="font-bold text-[#e5e1e4] mt-0.5">{currentClient.activeShootsCount} Shoots</div>
            <div className="text-[10px] text-emerald-400 mt-0.5">100% Utilized</div>
          </div>

          <div className="p-2.5 rounded-xl bg-[#201f21] border border-[#2a2a2c]/60">
            <div className="text-[10px] font-mono text-[#a38a92]">CREATIVE DESIGN HOURS</div>
            <div className="font-bold text-[#e5e1e4] mt-0.5">32 / 40 Hours</div>
            <div className="text-[10px] text-[#ffb0cd] mt-0.5">8 hrs reserve</div>
          </div>
        </div>

        {/* Actions */}
        <div className="pt-2 border-t border-[#2a2a2c] flex items-center justify-between">
          <button
            onClick={() =>
              showToast(
                isAr
                  ? 'جاري تنزيل عقد الرتينر الرسمي بصيغة PDF...'
                  : 'Downloading Retainer Agreement .PDF...'
              )
            }
            className="text-xs font-mono text-[#ffb0cd] hover:underline flex items-center gap-1 cursor-pointer"
          >
            <span className="material-symbols-outlined text-[15px]">picture_as_pdf</span>
            <span>{isAr ? 'عرض العقد (.PDF)' : 'View Agreement (.PDF)'}</span>
          </button>
          <button
            onClick={() =>
              showToast(
                isAr ? 'تم فتح نافذة شراء وحدات إضافية' : 'Top-up capacity drawer opened'
              )
            }
            className="px-3 py-1.5 rounded-lg bg-[#201f21] hover:bg-[#2a2a2c] text-xs font-mono text-[#e5e1e4] border border-[#2a2a2c] transition-colors cursor-pointer"
          >
            {isAr ? '+ شحن وحدات إنتاج' : '+ Top-up Units'}
          </button>
        </div>
      </div>

      {/* Account Standing Banner */}
      <div className="p-3 rounded-xl bg-[#1b1b1d] border border-emerald-500/30 flex items-center gap-3">
        <span className="material-symbols-outlined text-[20px] text-emerald-400">verified</span>
        <div className="text-xs">
          <span className="font-bold text-[#e5e1e4]">
            {isAr ? 'الحساب في وضع مالي ممتاز' : 'Account in Good Standing'}
          </span>
          <p className="text-[11px] text-[#dbc0c7]">
            {isAr
              ? 'التجديد التلقائي مجدول في 01 نوفمبر 2024 (فترة سماح 7 أيام مفعلة بالجنيه المصري).'
              : 'Auto-renew scheduled for Nov 01, 2024 in EGP. 7-Day Grace Period active.'}
          </p>
        </div>
      </div>

      {/* Pre-negotiated Capacity (Add-ons in EGP) */}
      <div className="p-4 rounded-2xl bg-[#1b1b1d] border border-[#2a2a2c] space-y-3">
        <div className="flex items-center justify-between">
          <span className="font-headline text-xs font-bold text-[#e5e1e4] uppercase tracking-wider">
            {isAr ? 'توسيع سعة الإنتاج المسبقة' : 'Pre-negotiated Capacity Extensions'}
          </span>
          <span className="text-[10px] font-mono text-[#ffb0cd]">SPECIAL EGP CLIENT RATES</span>
        </div>

        <div className="space-y-2">
          {addons.map((addon, i) => (
            <div
              key={i}
              className="p-3 rounded-xl bg-[#201f21] border border-[#2a2a2c]/60 flex items-center justify-between text-xs"
            >
              <div>
                <div className="font-bold text-[#e5e1e4]">
                  {isAr ? addon.titleAr : addon.titleEn}
                </div>
                <div className="text-[10px] text-[#a38a92] mt-0.5">
                  {isAr ? addon.descAr : addon.descEn}
                </div>
                <div className="text-xs font-mono text-[#ffb0cd] font-bold mt-1">
                  {formatEGP(addon.amountEGP, locale)}
                </div>
              </div>

              <button
                onClick={() =>
                  showToast(
                    isAr
                      ? `تمت إضافة "${addon.titleAr}" إلى دورة الفوترة (${formatEGP(addon.amountEGP, locale)})`
                      : `Added "${addon.titleEn}" (${formatEGP(addon.amountEGP, locale)}) to production cycle`
                  )
                }
                className="px-3 py-1.5 rounded-lg bg-[#2a2a2c] hover:bg-[#ff7bb4] hover:text-[#780846] text-[#dbc0c7] font-mono text-xs transition-colors cursor-pointer"
              >
                {isAr ? '+ إضافة' : '+ Add'}
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Invoices & Ledger in EGP */}
      <div className="p-4 rounded-2xl bg-[#1b1b1d] border border-[#2a2a2c] space-y-3">
        <div className="flex items-center justify-between">
          <span className="font-headline text-xs font-bold text-[#e5e1e4] uppercase tracking-wider">
            {isAr ? 'سجل الفواتير والمطالبات (EGP)' : 'Invoices & Ledger (EGP)'}
          </span>

          <div className="flex items-center gap-1 p-0.5 rounded-lg bg-[#201f21]">
            {(['all', 'paid', 'upcoming'] as const).map((f) => (
              <button
                key={f}
                onClick={() => setInvoiceFilter(f)}
                className={`px-2 py-0.5 rounded text-[10px] font-mono uppercase transition-all cursor-pointer ${
                  invoiceFilter === f
                    ? 'bg-[#2a2a2c] text-[#ffb0cd] font-bold'
                    : 'text-[#dbc0c7]'
                }`}
              >
                {f}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-2">
          {filteredInvoices.map((inv) => (
            <div
              key={inv.id}
              className="p-3 rounded-xl bg-[#201f21] border border-[#2a2a2c]/60 flex items-center justify-between text-xs"
            >
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-[#ffb0cd] font-bold">{inv.invoiceNumber}</span>
                  <span
                    className={`px-1.5 py-0.2 rounded text-[9px] font-mono font-bold ${
                      inv.status === 'paid'
                        ? 'bg-emerald-500/20 text-emerald-300'
                        : 'bg-amber-500/20 text-amber-300'
                    }`}
                  >
                    {inv.statusLabel}
                  </span>
                </div>
                <div className="font-semibold text-[#e5e1e4] mt-1">
                  {isAr ? inv.titleAr : inv.title}
                </div>
                <div className="text-[10px] font-mono text-[#a38a92] mt-0.5">
                  {isAr ? inv.cycleAr : inv.cycle} · {inv.paymentMethod}
                </div>
              </div>

              <div className="text-right flex flex-col items-end gap-1">
                <div className="font-mono font-bold text-[#e5e1e4]">{inv.amount}</div>
                {inv.hasTaxPdf && (
                  <button
                    onClick={() =>
                      showToast(
                        isAr
                          ? `جاري تنزيل الفاتورة الضريبية الرسمية لـ ${inv.invoiceNumber}...`
                          : `Exporting Tax Invoice ${inv.invoiceNumber} (PDF)...`
                      )
                    }
                    className="text-[10px] font-mono text-[#ffb0cd] hover:underline flex items-center gap-0.5 cursor-pointer"
                  >
                    <span className="material-symbols-outlined text-[13px]">download</span>
                    <span>Tax PDF</span>
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Payment Source & Tax Profile */}
      <div className="p-4 rounded-2xl bg-[#1b1b1d] border border-[#2a2a2c] space-y-3 text-xs">
        <span className="font-headline text-xs font-bold text-[#e5e1e4] uppercase tracking-wider">
          {isAr ? 'الملف الضريبي وطريقة السداد' : 'Payment Source & Tax Profile'}
        </span>

        <div className="space-y-2">
          <div className="p-2.5 rounded-xl bg-[#201f21] flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <span className="material-symbols-outlined text-[18px] text-[#ffb0cd]">
                credit_card
              </span>
              <div>
                <div className="font-semibold text-[#e5e1e4]">Corporate Account •••• 9412</div>
                <div className="text-[10px] font-mono text-[#a38a92]">
                  CIB / Commercial International Bank (EGP Currency Settled)
                </div>
              </div>
            </div>
            <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[9px] font-mono">
              DEFAULT
            </span>
          </div>

          <div className="p-2.5 rounded-xl bg-[#201f21] flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <span className="material-symbols-outlined text-[18px] text-[#ffb0cd]">
                account_balance
              </span>
              <div>
                <div className="font-semibold text-[#e5e1e4]">
                  TRN Tax Profile: {currentClient.id.toUpperCase()}-TAX-2024
                </div>
                <div className="text-[10px] text-[#a38a92]">
                  {currentClient.name} · Registered Client Production Entity
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
