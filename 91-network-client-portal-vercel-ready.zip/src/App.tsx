import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { VaultLogin } from './components/VaultLogin';
import { HomeDashboard } from './components/HomeDashboard';
import { ContentCalendar } from './components/ContentCalendar';
import { RequestsHub } from './components/RequestsHub';
import { ProductionShoots } from './components/ProductionShoots';
import { RetainerBilling } from './components/RetainerBilling';
import { AdminHub } from './components/AdminHub';
import { DeliverableReviewModal } from './components/DeliverableReviewModal';
import { AiBriefWorkspaceModal } from './components/AiBriefWorkspaceModal';
import { Toast } from './components/Toast';

const MainPortal: React.FC = () => {
  const { activeTab, isVaultLocked } = useApp();

  if (isVaultLocked) {
    return (
      <main className="min-h-screen bg-[#131315]">
        <Header />
        <VaultLogin />
        <Toast />
      </main>
    );
  }

  return (
    <div className="min-h-screen bg-[#131315] text-[#e5e1e4] flex flex-col justify-between selection:bg-[#ff7bb4] selection:text-[#780846] overflow-x-hidden">
      {/* Fixed Header */}
      <Header />

      {/* Main View Area */}
      <main className="flex-1">
        {activeTab === 'admin' && <AdminHub />}
        {activeTab === 'home' && <HomeDashboard />}
        {activeTab === 'content' && <ContentCalendar />}
        {activeTab === 'requests' && <RequestsHub />}
        {activeTab === 'shoots' && <ProductionShoots />}
        {activeTab === 'more' && <RetainerBilling />}
      </main>

      {/* Bottom Navigation */}
      <BottomNav />

      {/* Overlays / Modals */}
      <DeliverableReviewModal />
      <AiBriefWorkspaceModal />

      {/* Toast Banner */}
      <Toast />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainPortal />
    </AppProvider>
  );
}

