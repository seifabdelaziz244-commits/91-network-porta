import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { CURRENT_CALL_SHEET, ASSETS } from '../data/mockData';

export const ProductionShoots: React.FC = () => {
  const { locale, showToast } = useApp();
  const isAr = locale === 'ar';

  const [activeTab, setActiveTab] = useState<'upcoming' | 'past' | 'archive'>('upcoming');

  return (
    <div className="pt-20 pb-24 px-4 max-w-xl mx-auto space-y-5">
      {/* Top Banner & Shoot Quota */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-headline text-xl font-bold text-[#e5e1e4] tracking-tight">
            {isAr ? 'جلسات الإنتاج والتصوير' : 'Production Shoots'}
          </h1>
          <p className="text-xs text-[#dbc0c7] mt-0.5 font-mono">
            {isAr
              ? '2 من 2 جلسات رتينر مكتملة · تم حجز جلسة إضافية'
              : '2 of 2 Retainer Shoots Used · 1 Add-on Booked'}
          </p>
        </div>
        <button
          onClick={() =>
            showToast(
              isAr
                ? 'تم فتح نموذج حجز جلسة تصوير استوديو أو موقع جديد'
                : 'Shoot booking intake requested'
            )
          }
          className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-[#ff7bb4] to-[#ffb0cd] text-[#780846] text-xs font-headline font-bold hover:opacity-95 shadow-sm transition-all flex items-center gap-1 cursor-pointer"
        >
          <span>+</span>
          <span>{isAr ? 'طلب جلسة' : 'Request Shoot'}</span>
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
        {[
          { id: 'upcoming', labelEn: 'Upcoming (1)', labelAr: 'القادمة (1)' },
          { id: 'past', labelEn: 'Past Shoots (2)', labelAr: 'السابقة (2)' },
          { id: 'archive', labelEn: 'Archive', labelAr: 'الأرشيف' }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-3 py-1.5 rounded-full text-xs font-mono flex-shrink-0 transition-all ${
              activeTab === tab.id
                ? 'bg-[#2a2a2c] text-[#ffb0cd] border border-[#ff7bb4]/40 font-bold'
                : 'bg-[#1b1b1d] text-[#dbc0c7] border border-[#2a2a2c] hover:border-[#554248]'
            }`}
          >
            {isAr ? tab.labelAr : tab.labelEn}
          </button>
        ))}
      </div>

      {activeTab === 'upcoming' ? (
        <div className="space-y-5">
          {/* Confirmed Call Sheet Card */}
          <div className="rounded-2xl bg-[#1b1b1d] border border-[#554248]/40 overflow-hidden shadow-2xl space-y-4">
            {/* Hero Image Section */}
            <div className="relative h-52 sm:h-56 w-full">
              <img
                src={CURRENT_CALL_SHEET.heroImage}
                alt="Alserkal Avenue Shoot"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#1b1b1d] via-[#1b1b1d]/40 to-transparent"></div>

              {/* Badges Overlay */}
              <div className="absolute top-3 inset-x-3 flex items-center justify-between">
                <span className="px-2.5 py-1 rounded-md bg-[#131315]/85 backdrop-blur-md text-[10px] font-mono font-bold text-[#ffb0cd] border border-[#ff7bb4]/30 uppercase">
                  {isAr ? CURRENT_CALL_SHEET.statusAr : CURRENT_CALL_SHEET.status}
                </span>
                <span className="px-2.5 py-1 rounded-md bg-emerald-500/20 backdrop-blur-md text-[10px] font-mono font-bold text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
                  {isAr ? CURRENT_CALL_SHEET.countdownAr : CURRENT_CALL_SHEET.countdown}
                </span>
              </div>

              {/* Title Overlay */}
              <div className="absolute bottom-3 inset-x-3">
                <div className="text-[10px] font-mono text-[#dbc0c7] uppercase">
                  {isAr ? CURRENT_CALL_SHEET.collectionAr : CURRENT_CALL_SHEET.collection}
                </div>
                <h2 className="font-headline text-xl font-bold text-[#e5e1e4] leading-snug">
                  {isAr ? CURRENT_CALL_SHEET.titleAr : CURRENT_CALL_SHEET.title}
                </h2>
              </div>
            </div>

            {/* Shoot Logistics Grid */}
            <div className="px-4 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-[#dbc0c7]">
              <div className="p-3 rounded-xl bg-[#201f21] border border-[#2a2a2c] flex items-start gap-2.5">
                <span className="material-symbols-outlined text-[18px] text-[#ff7bb4] flex-shrink-0 mt-0.5">
                  calendar_today
                </span>
                <div>
                  <div className="text-[10px] font-mono uppercase text-[#a38a92]">
                    {isAr ? 'تاريخ الجلسة' : 'Shoot Date'}
                  </div>
                  <div className="text-xs font-bold text-[#e5e1e4] mt-0.5">
                    {isAr ? CURRENT_CALL_SHEET.dateAr : CURRENT_CALL_SHEET.date}
                  </div>
                  <div className="text-[11px] text-[#ffb0cd] font-mono mt-0.5">
                    {isAr ? CURRENT_CALL_SHEET.timeAr : CURRENT_CALL_SHEET.time}
                  </div>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-[#201f21] border border-[#2a2a2c] flex items-start gap-2.5">
                <span className="material-symbols-outlined text-[18px] text-[#ff7bb4] flex-shrink-0 mt-0.5">
                  location_on
                </span>
                <div>
                  <div className="text-[10px] font-mono uppercase text-[#a38a92]">
                    {isAr ? 'موقع التصوير' : 'Location'}
                  </div>
                  <div className="text-xs font-bold text-[#e5e1e4] mt-0.5">
                    {isAr ? CURRENT_CALL_SHEET.locationAr : CURRENT_CALL_SHEET.location}
                  </div>
                  <div className="text-[10px] font-mono text-emerald-400 mt-0.5">
                    {isAr ? CURRENT_CALL_SHEET.weatherAr : CURRENT_CALL_SHEET.weather} ·{' '}
                    {CURRENT_CALL_SHEET.sunset}
                  </div>
                </div>
              </div>
            </div>

            {/* Map & Gate Access Strip */}
            <div className="px-4">
              <div className="p-3 rounded-xl bg-[#201f21] border border-[#2a2a2c] flex flex-col sm:flex-row items-center gap-3">
                <div className="relative w-full sm:w-28 h-20 rounded-lg overflow-hidden flex-shrink-0 border border-[#2a2a2c]">
                  <img
                    src={CURRENT_CALL_SHEET.mapImage}
                    alt="Map Gate 3"
                    className="w-full h-full object-cover"
                  />
                  <span className="absolute bottom-1 left-1 px-1 py-0.2 rounded bg-black/70 text-[9px] font-mono text-white">
                    Alserkal Map
                  </span>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-[#e5e1e4]">
                      {isAr ? CURRENT_CALL_SHEET.gateAccessAr : CURRENT_CALL_SHEET.gateAccess}
                    </span>
                    <span className="px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-400 text-[9px] font-mono">
                      RESERVED
                    </span>
                  </div>
                  <p className="text-[11px] text-[#dbc0c7] mt-0.5">
                    {isAr ? CURRENT_CALL_SHEET.gateNoteAr : CURRENT_CALL_SHEET.gateNote}
                  </p>
                </div>
              </div>
            </div>

            {/* Run of Show / Call Times Timeline */}
            <div className="px-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-headline text-xs font-bold text-[#e5e1e4] uppercase tracking-wider">
                  {isAr ? 'جدول ساعات العمل والإنتاج (Run of Show)' : 'Run of Show / Call Times'}
                </span>
                <span className="text-[10px] font-mono text-[#ffb0cd]">6 KEY MILESTONES</span>
              </div>

              <div className="relative pl-4 space-y-4 before:absolute before:left-1.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-[#2a2a2c]">
                {CURRENT_CALL_SHEET.timeline.map((step, idx) => (
                  <div key={idx} className="relative group">
                    <div className="absolute -left-[19px] top-1 w-3 h-3 rounded-full bg-[#ff7bb4] ring-4 ring-[#1b1b1d] group-hover:scale-125 transition-transform"></div>
                    <div className="p-3 rounded-xl bg-[#201f21] border border-[#2a2a2c] hover:border-[#554248] transition-colors">
                      <div className="flex items-center justify-between text-xs font-mono">
                        <span className="font-bold text-[#ffb0cd]">
                          {isAr ? step.timeAr : step.time}
                        </span>
                        <span className="px-1.5 py-0.5 rounded bg-[#2a2a2c] text-[10px] text-[#dbc0c7]">
                          {isAr ? step.locationAr : step.location}
                        </span>
                      </div>
                      <div className="text-xs font-bold text-[#e5e1e4] mt-1">
                        {isAr ? step.titleAr : step.title}
                      </div>
                      <div className="text-[11px] text-[#dbc0c7] mt-0.5">
                        {isAr ? step.descriptionAr : step.description}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Key Crew & Contacts */}
            <div className="px-4 space-y-3">
              <span className="font-headline text-xs font-bold text-[#e5e1e4] uppercase tracking-wider">
                {isAr ? 'طاقم العمل ومسؤولو الاتصال' : 'Crew & Key Contacts'}
              </span>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {CURRENT_CALL_SHEET.crew.map((member, i) => (
                  <div
                    key={i}
                    className="p-2.5 rounded-xl bg-[#201f21] border border-[#2a2a2c] flex items-center justify-between"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-full bg-[#2a2a2c] text-[#ffb0cd] flex items-center justify-center font-mono font-bold text-xs border border-[#ff7bb4]/30">
                        {member.initials}
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs font-bold text-[#e5e1e4]">
                            {isAr ? member.nameAr : member.name}
                          </span>
                          {member.badge && (
                            <span className="px-1 py-0.2 rounded bg-[#ff7bb4]/20 text-[#ffb0cd] text-[8px] font-mono">
                              {member.badge}
                            </span>
                          )}
                        </div>
                        <div className="text-[10px] text-[#a38a92] truncate max-w-[140px]">
                          {isAr ? member.roleAr : member.role}
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() =>
                        showToast(
                          isAr
                            ? `جاري الاتصال بـ ${member.nameAr} (${member.phone})...`
                            : `Calling ${member.name} (${member.phone})...`
                        )
                      }
                      className="w-8 h-8 rounded-lg bg-[#2a2a2c] hover:bg-[#ff7bb4] hover:text-[#780846] text-[#dbc0c7] flex items-center justify-center transition-colors"
                      title="Call"
                    >
                      <span className="material-symbols-outlined text-[16px]">call</span>
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Camera & Technical Specs Bento */}
            <div className="px-4 space-y-2">
              <span className="font-headline text-xs font-bold text-[#e5e1e4] uppercase tracking-wider">
                {isAr ? 'المواصفات التقنية والمعدات' : 'Camera & Technical Specs'}
              </span>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-3 rounded-xl bg-[#201f21] border border-[#2a2a2c]">
                  <div className="text-[10px] font-mono text-[#a38a92]">CINEMA CAMERA</div>
                  <div className="font-bold text-[#e5e1e4] mt-0.5">
                    {CURRENT_CALL_SHEET.gear.cinemaCamera}
                  </div>
                  <div className="text-[10px] text-[#ffb0cd] font-mono">
                    {CURRENT_CALL_SHEET.gear.cinemaSpecs}
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-[#201f21] border border-[#2a2a2c]">
                  <div className="text-[10px] font-mono text-[#a38a92]">STILLS CAMERA</div>
                  <div className="font-bold text-[#e5e1e4] mt-0.5">
                    {CURRENT_CALL_SHEET.gear.stillsCamera}
                  </div>
                  <div className="text-[10px] text-[#ffb0cd] font-mono">
                    {CURRENT_CALL_SHEET.gear.stillsSpecs}
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-[#201f21] border border-[#2a2a2c]">
                  <div className="text-[10px] font-mono text-[#a38a92]">ASPECT RATIOS</div>
                  <div className="font-bold text-[#e5e1e4] mt-0.5">
                    {CURRENT_CALL_SHEET.gear.aspectRatios}
                  </div>
                  <div className="text-[10px] text-[#dbc0c7]">
                    {isAr
                      ? CURRENT_CALL_SHEET.gear.aspectNoteAr
                      : CURRENT_CALL_SHEET.gear.aspectNote}
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-[#201f21] border border-[#2a2a2c]">
                  <div className="text-[10px] font-mono text-[#a38a92]">GLASS / LENSES</div>
                  <div className="font-bold text-[#e5e1e4] mt-0.5">
                    {CURRENT_CALL_SHEET.gear.lenses}
                  </div>
                  <div className="text-[10px] text-[#dbc0c7]">
                    {CURRENT_CALL_SHEET.gear.lensNote}
                  </div>
                </div>
              </div>
            </div>

            {/* Footer Actions */}
            <div className="p-4 bg-[#18181a] border-t border-[#2a2a2c] space-y-3">
              <div className="flex items-center justify-between text-[11px] font-mono text-[#a38a92]">
                <span className="flex items-center gap-1 text-emerald-400">
                  <span className="material-symbols-outlined text-[15px]">verified</span>
                  <span>{isAr ? CURRENT_CALL_SHEET.confirmedByAr : CURRENT_CALL_SHEET.confirmedBy}</span>
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() =>
                    showToast(
                      isAr
                        ? 'جاري تنزيل ملف أمر العمل الرسمي بصيغة PDF...'
                        : 'Official Call Sheet #CS-04 PDF exported'
                    )
                  }
                  className="py-2.5 px-3 rounded-xl bg-[#201f21] hover:bg-[#2a2a2c] border border-[#2a2a2c] text-xs font-mono text-[#dbc0c7] hover:text-[#e5e1e4] flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[16px] text-[#ff7bb4]">
                    picture_as_pdf
                  </span>
                  <span>{isAr ? 'تنزيل PDF' : 'Download PDF'}</span>
                </button>

                <button
                  onClick={() =>
                    showToast(
                      isAr
                        ? 'تمت إضافة موعد الجلسة إلى تقويم Google وتقويم Apple'
                        : 'Added to Google Calendar & Apple iCal'
                    )
                  }
                  className="py-2.5 px-3 rounded-xl bg-gradient-to-r from-[#ff7bb4] to-[#ffb0cd] text-[#780846] text-xs font-headline font-bold hover:opacity-95 shadow-md flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[16px]">event_available</span>
                  <span>{isAr ? 'إضافة للتقويم' : 'Add to Calendar'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* Past Shoots List */
        <div className="space-y-3">
          <div className="p-3.5 rounded-2xl bg-[#1b1b1d] border border-[#2a2a2c] flex items-center gap-3">
            <div className="w-16 h-16 rounded-xl overflow-hidden bg-[#201f21] flex-shrink-0">
              <img src={ASSETS.pastShootDusk} alt="Past Shoot" className="w-full h-full object-cover" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-xs font-bold text-[#e5e1e4]">
                Alserkal Dusk Minimalist Reels
              </div>
              <div className="text-[10px] font-mono text-[#a38a92] mt-0.5">
                Completed Oct 12 · 4K ProRes Delivered
              </div>
              <button
                onClick={() =>
                  showToast(isAr ? 'جاري فتح أرشيف المواد المصورة...' : 'Opening raw footage archive...')
                }
                className="text-[11px] font-mono text-[#ffb0cd] hover:underline mt-1 block"
              >
                Drive Raw Vault →
              </button>
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-[#1b1b1d] border border-[#2a2a2c] flex items-center gap-3">
            <div className="w-16 h-16 rounded-xl overflow-hidden bg-[#201f21] flex-shrink-0">
              <img src={ASSETS.pastShootSilk} alt="Past Shoot 2" className="w-full h-full object-cover" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-xs font-bold text-[#e5e1e4]">
                Silk Trench Studio Portraits
              </div>
              <div className="text-[10px] font-mono text-[#a38a92] mt-0.5">
                Completed Oct 04 · 50MP Sony A1 Master RAW
              </div>
              <button
                onClick={() =>
                  showToast(isAr ? 'جاري فتح أرشيف المواد المصورة...' : 'Opening raw footage archive...')
                }
                className="text-[11px] font-mono text-[#ffb0cd] hover:underline mt-1 block"
              >
                Drive Raw Vault →
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
