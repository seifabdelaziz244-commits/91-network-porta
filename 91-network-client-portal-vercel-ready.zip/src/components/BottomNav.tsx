import React from 'react';
import { useApp } from '../context/AppContext';
import { TabType } from '../types';

export const BottomNav: React.FC = () => {
  const { activeTab, setActiveTab, locale, isVaultLocked, userRole } = useApp();

  if (isVaultLocked) return null;

  const isAr = locale === 'ar';
  const isAdmin = userRole === 'agency_admin';

  const tabs: Array<{ id: TabType; icon: string; labelEn: string; labelAr: string }> = isAdmin
    ? [
        { id: 'admin', icon: 'admin_panel_settings', labelEn: 'ADMIN', labelAr: 'الإدارة' },
        { id: 'home', icon: 'visibility', labelEn: 'PORTAL', labelAr: 'البوابة' },
        { id: 'content', icon: 'view_kanban', labelEn: 'CONTENT', labelAr: 'المحتوى' },
        { id: 'requests', icon: 'task_alt', labelEn: 'REQUESTS', labelAr: 'الطلبات' },
        { id: 'more', icon: 'account_balance_wallet', labelEn: 'EGP LEDGER', labelAr: 'الفواتير' }
      ]
    : [
        { id: 'home', icon: 'dashboard', labelEn: 'HOME', labelAr: 'الرئيسية' },
        { id: 'content', icon: 'view_kanban', labelEn: 'CONTENT', labelAr: 'المحتوى' },
        { id: 'requests', icon: 'task_alt', labelEn: 'REQUESTS', labelAr: 'الطلبات' },
        { id: 'shoots', icon: 'photo_camera', labelEn: 'SHOOTS', labelAr: 'جلسات التصوير' },
        { id: 'more', icon: 'menu', labelEn: 'MORE', labelAr: 'المزيد' }
      ];

  return (
    <nav className="fixed bottom-0 inset-x-0 z-40 pb-safe bg-[#131315]/90 backdrop-blur-2xl border-t border-[#2a2a2c]/80 shadow-[0_-4px_24px_rgba(0,0,0,0.6)]">
      <div className="flex justify-around items-center h-16 px-2 max-w-md mx-auto">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex flex-col items-center justify-center w-16 h-12 gap-0.5 transition-all relative cursor-pointer ${
                isActive
                  ? 'text-[#ff7bb4]'
                  : 'text-[#dbc0c7]/70 hover:text-[#e5e1e4]'
              }`}
            >
              <span
                className="material-symbols-outlined text-[22px] transition-transform"
                style={{ fontVariationSettings: isActive ? "'FILL' 1" : "'FILL' 0" }}
              >
                {tab.icon}
              </span>
              <span className="font-sans text-[10px] tracking-wider uppercase font-medium leading-none truncate max-w-full">
                {isAr ? tab.labelAr : tab.labelEn}
              </span>
              {isActive && (
                <span className="absolute -bottom-1.5 w-5 h-1 rounded-full bg-[#ff7bb4] shadow-[0_0_8px_#ff7bb4]"></span>
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
