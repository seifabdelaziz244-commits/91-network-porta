import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ASSETS } from '../data/mockData';

export const ContentCalendar: React.FC = () => {
  const {
    locale,
    userRole,
    activeClientId,
    deliverables,
    setActiveDeliverableId,
    approveDeliverable,
    requestRevision,
    setActiveTab,
    showToast
  } = useApp();

  const isAr = locale === 'ar';
  const [viewMode, setViewMode] = useState<'timeline' | 'grid'>('timeline');
  const [selectedDay, setSelectedDay] = useState(24);
  const [activeFilter, setActiveFilter] = useState<'all' | 'review' | 'scheduled' | 'production'>('all');
  const [showAiBanner, setShowAiBanner] = useState(true);

  const days = [
    { dayNum: 21, dayNameEn: 'Mon', dayNameAr: 'الإثنين' },
    { dayNum: 22, dayNameEn: 'Tue', dayNameAr: 'الثلاثاء' },
    { dayNum: 23, dayNameEn: 'Wed', dayNameAr: 'الأربعاء' },
    { dayNum: 24, dayNameEn: 'Thu', dayNameAr: 'الخميس', isToday: true },
    { dayNum: 25, dayNameEn: 'Fri', dayNameAr: 'الجمعة' },
    { dayNum: 26, dayNameEn: 'Sat', dayNameAr: 'السبت' },
    { dayNum: 27, dayNameEn: 'Sun', dayNameAr: 'الأحد' }
  ];

  const clientScopedDeliverables = deliverables.filter((d) => {
    if (userRole === 'agency_admin') return true;
    return !d.clientId || d.clientId === activeClientId;
  });

  const filteredDeliverables = clientScopedDeliverables.filter((d) => {
    if (activeFilter === 'review') return d.status === 'action_required';
    if (activeFilter === 'scheduled') return d.status === 'scheduled';
    if (activeFilter === 'production') return d.status === 'in_revision';
    return true;
  });

  return (
    <div className="pt-20 pb-24 px-4 max-w-xl mx-auto space-y-5">
      {/* Top Header & View Switcher */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-headline text-xl font-bold text-[#e5e1e4] tracking-tight">
            {isAr ? 'جدول المحتوى الرقمي' : 'Content Pipeline'}
          </h1>
          <p className="text-xs text-[#dbc0c7] mt-0.5">
            {isAr ? 'أكتوبر 2024 · الأسبوع 43' : 'October 2024 · Week 43'}
          </p>
        </div>

        {/* Timeline vs Grid Switcher */}
        <div className="flex items-center p-1 rounded-xl bg-[#1b1b1d] border border-[#2a2a2c]">
          <button
            onClick={() => setViewMode('timeline')}
            className={`px-2.5 py-1 rounded-lg text-xs font-mono transition-all flex items-center gap-1 ${
              viewMode === 'timeline'
                ? 'bg-[#2a2a2c] text-[#ffb0cd] shadow-sm'
                : 'text-[#dbc0c7] hover:text-[#e5e1e4]'
            }`}
          >
            <span className="material-symbols-outlined text-[15px]">view_timeline</span>
            <span>{isAr ? 'قائمة' : 'List'}</span>
          </button>
          <button
            onClick={() => setViewMode('grid')}
            className={`px-2.5 py-1 rounded-lg text-xs font-mono transition-all flex items-center gap-1 ${
              viewMode === 'grid'
                ? 'bg-[#2a2a2c] text-[#ffb0cd] shadow-sm'
                : 'text-[#dbc0c7] hover:text-[#e5e1e4]'
            }`}
          >
            <span className="material-symbols-outlined text-[15px]">grid_view</span>
            <span>{isAr ? 'شبكة' : 'Grid'}</span>
          </button>
        </div>
      </div>

      {/* Week Day Scrubber */}
      <div className="flex items-center justify-between gap-1 p-2 rounded-2xl bg-[#1b1b1d] border border-[#2a2a2c] overflow-x-auto no-scrollbar">
        {days.map((item) => {
          const isSelected = selectedDay === item.dayNum;
          return (
            <button
              key={item.dayNum}
              onClick={() => setSelectedDay(item.dayNum)}
              className={`flex-1 min-w-[44px] py-2 px-1 rounded-xl flex flex-col items-center justify-center transition-all ${
                isSelected
                  ? 'bg-gradient-to-b from-[#ff7bb4] to-[#ffb0cd] text-[#780846] font-bold shadow-md'
                  : item.isToday
                  ? 'bg-[#201f21] text-[#ffb0cd] border border-[#ff7bb4]/40 font-semibold'
                  : 'text-[#dbc0c7] hover:bg-[#201f21]'
              }`}
            >
              <span className="text-[10px] font-mono uppercase tracking-wider">
                {isAr ? item.dayNameAr : item.dayNameEn}
              </span>
              <span className="text-sm font-bold font-mono mt-0.5">{item.dayNum}</span>
              {item.isToday && !isSelected && (
                <span className="w-1 h-1 rounded-full bg-[#ff7bb4] mt-0.5"></span>
              )}
            </button>
          );
        })}
      </div>

      {/* Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
        {[
          { id: 'all', labelEn: 'All (18)', labelAr: 'الكل (18)' },
          { id: 'review', labelEn: 'Needs Review (2)', labelAr: 'يحتاج مراجعة (2)' },
          { id: 'scheduled', labelEn: 'Scheduled (2)', labelAr: 'مجدول (2)' },
          { id: 'production', labelEn: 'In Production (3)', labelAr: 'قيد الإنتاج (3)' }
        ].map((f) => (
          <button
            key={f.id}
            onClick={() => setActiveFilter(f.id as any)}
            className={`px-3 py-1.5 rounded-full text-xs font-mono flex-shrink-0 transition-all ${
              activeFilter === f.id
                ? 'bg-[#2a2a2c] text-[#ffb0cd] border border-[#ff7bb4]/40 font-bold'
                : 'bg-[#1b1b1d] text-[#dbc0c7] border border-[#2a2a2c] hover:border-[#554248]'
            }`}
          >
            {isAr ? f.labelAr : f.labelEn}
          </button>
        ))}
      </div>

      {/* Lumen AI Predictive Slot Banner */}
      {showAiBanner && (
        <div className="p-3.5 rounded-2xl bg-gradient-to-r from-[#2a1a24] to-[#1b1b1d] border border-[#ff7bb4]/40 flex items-start gap-3 shadow-md animate-in fade-in duration-200">
          <div className="w-8 h-8 rounded-lg bg-[#ff7bb4] text-[#780846] flex items-center justify-center flex-shrink-0 mt-0.5 font-bold">
            <span className="material-symbols-outlined text-[18px]">insights</span>
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-bold text-[#e5e1e4]">
                {isAr ? 'مُحسِّن الجدولة الذكي (Lumen AI)' : 'Predictive Slot Optimizer'}
              </span>
              <span className="px-1.5 py-0.2 rounded bg-[#ff7bb4]/20 text-[#ffb0cd] text-[9px] font-mono">
                +24% REACH
              </span>
            </div>
            <p className="text-[11px] text-[#dbc0c7] mt-1">
              {isAr
                ? 'ذروة تفاعل الجمهور متوقعة مساء الجمعة 7:30 م. هل ترغب بترحيل موعد ريل المعطف الحريري بنقرة واحدة؟'
                : 'High engagement spike predicted Friday at 7:30 PM GST. Auto-reschedule Reel 04 to capture +24% more organic reach?'}
            </p>
            <div className="flex items-center gap-2 mt-2.5">
              <button
                onClick={() => {
                  showToast(
                    isAr
                      ? 'تم تحسين الموعد بنجاح وجدولة النشر في الجمعة 7:30 م'
                      : 'Slot optimized: Rescheduled to Friday 7:30 PM GST'
                  );
                  setShowAiBanner(false);
                }}
                className="px-3 py-1 rounded-lg bg-[#ff7bb4] hover:bg-[#ffb0cd] text-[#780846] text-xs font-headline font-bold transition-colors cursor-pointer"
              >
                {isAr ? 'تحسين الموعد' : 'Optimize Slot'}
              </button>
              <button
                onClick={() => setShowAiBanner(false)}
                className="px-2.5 py-1 rounded-lg bg-[#201f21] hover:bg-[#2a2a2c] text-[#dbc0c7] text-xs font-mono transition-colors cursor-pointer"
              >
                {isAr ? 'تجاهل' : 'Dismiss'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Deliverables List View */}
      {viewMode === 'timeline' ? (
        <div className="space-y-4">
          {filteredDeliverables.map((item) => (
            <div
              key={item.id}
              className="p-4 rounded-2xl bg-[#1b1b1d] border border-[#2a2a2c] hover:border-[#554248] transition-all space-y-3 shadow-lg"
            >
              {/* Card Header */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-[18px] text-[#ff7bb4]">
                    {item.type === 'reel'
                      ? 'movie'
                      : item.type === 'carousel'
                      ? 'photo_library'
                      : 'video_camera_back'}
                  </span>
                  <span className="text-xs font-mono text-[#dbc0c7]">{item.platform}</span>
                  <span className="text-[#554248]">·</span>
                  <span className="text-xs font-mono text-[#e5e1e4]">
                    {isAr ? item.scheduledTimeAr : item.scheduledTime}
                  </span>
                </div>

                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase tracking-wider ${
                    item.status === 'action_required'
                      ? 'bg-[#ff7bb4] text-[#780846]'
                      : item.status === 'scheduled'
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                  }`}
                >
                  {item.status === 'action_required'
                    ? isAr
                      ? 'مطلوب إجراء'
                      : 'ACTION REQUIRED'
                    : item.status === 'scheduled'
                    ? isAr
                      ? 'مجدول'
                      : 'SCHEDULED'
                    : isAr
                    ? 'قيد التعديل R2'
                    : 'IN REVISION R2'}
                </span>
              </div>

              {/* Title & Code */}
              <div>
                <div className="text-[10px] font-mono text-[#ffb0cd]">{item.code}</div>
                <h3
                  onClick={() => setActiveDeliverableId(item.id)}
                  className="font-headline text-base font-bold text-[#e5e1e4] hover:text-[#ffb0cd] transition-colors cursor-pointer"
                >
                  {isAr ? item.titleAr : item.title}
                </h3>
                <p className="text-xs text-[#dbc0c7] mt-1 line-clamp-2">
                  {isAr ? item.descriptionAr : item.description}
                </p>
              </div>

              {/* Preview Media Section */}
              {item.type === 'reel' && (
                <div
                  onClick={() => setActiveDeliverableId(item.id)}
                  className="relative h-48 rounded-xl overflow-hidden bg-[#201f21] border border-[#2a2a2c] cursor-pointer group"
                >
                  <img
                    src={item.posterImage}
                    alt={item.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex flex-col justify-between p-3">
                    <div className="flex items-center justify-between">
                      <span className="px-2 py-0.5 rounded bg-black/60 backdrop-blur-md text-[10px] font-mono text-white">
                        {item.format} · {item.duration}
                      </span>
                      <span className="px-2 py-0.5 rounded bg-black/60 backdrop-blur-md text-[10px] font-mono text-emerald-400">
                        {item.viralityScore}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5 text-white text-xs font-mono">
                        <span className="material-symbols-outlined text-[16px] text-[#ff7bb4]">
                          music_note
                        </span>
                        <span className="truncate max-w-[200px]">{item.audioTrack}</span>
                      </div>
                      <div className="w-9 h-9 rounded-full bg-[#ff7bb4] text-[#780846] flex items-center justify-center font-bold shadow-lg group-hover:scale-110 transition-transform">
                        <span className="material-symbols-outlined text-[20px]">play_arrow</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {item.type === 'carousel' && item.slideImages && (
                <div
                  onClick={() => setActiveDeliverableId(item.id)}
                  className="grid grid-cols-3 gap-2 cursor-pointer"
                >
                  {item.slideImages.map((img, i) => (
                    <div key={i} className="relative h-24 rounded-lg overflow-hidden bg-[#201f21]">
                      <img src={img} alt="slide" className="w-full h-full object-cover" />
                      {i === 2 && (
                        <div className="absolute inset-0 bg-black/60 flex items-center justify-center text-white font-mono text-xs font-bold">
                          +5 MORE
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}

              {item.type === 'tiktok' && (
                <div className="p-3 rounded-xl bg-[#201f21] border border-[#2a2a2c] flex items-center gap-3">
                  <div className="w-12 h-16 rounded-lg overflow-hidden flex-shrink-0">
                    <img src={item.posterImage} alt="bts" className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-[11px] font-mono text-amber-300 font-bold">
                      {isAr ? 'ملاحظة مدير التصوير (سارة ت.):' : 'Lead DP Note (Sarah T.):'}
                    </div>
                    <p className="text-[11px] text-[#dbc0c7] truncate mt-0.5">
                      {isAr ? item.dpNoteAr : item.dpNote}
                    </p>
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="pt-2 border-t border-[#2a2a2c] flex items-center justify-between">
                <button
                  onClick={() => setActiveDeliverableId(item.id)}
                  className="text-xs font-mono text-[#ffb0cd] hover:underline flex items-center gap-1"
                >
                  <span>{isAr ? 'فتح المشغل والملاحظات ←' : 'Open Review Player →'}</span>
                </button>

                <div className="flex items-center gap-2">
                  {item.status === 'action_required' ? (
                    <>
                      <button
                        onClick={() => requestRevision(item.id)}
                        className="px-3 py-1.5 rounded-lg bg-[#201f21] hover:bg-[#2a2a2c] text-xs font-mono text-[#dbc0c7] hover:text-[#e5e1e4] border border-[#2a2a2c] transition-colors"
                      >
                        {isAr ? 'طلب تعديل' : 'Request Revision'}
                      </button>
                      <button
                        onClick={() => approveDeliverable(item.id)}
                        className="px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-[#ff7bb4] to-[#ffb0cd] text-[#780846] text-xs font-headline font-bold hover:opacity-95 shadow-md transition-all cursor-pointer"
                      >
                        {isAr ? 'اعتماد ونشر' : 'Approve Reel'}
                      </button>
                    </>
                  ) : item.status === 'scheduled' ? (
                    <span className="inline-flex items-center gap-1 text-xs font-mono text-emerald-400">
                      <span className="material-symbols-outlined text-[16px]">check_circle</span>
                      <span>{isAr ? 'معتمد من جوزيف' : 'Approved & Locked'}</span>
                    </span>
                  ) : (
                    <button
                      onClick={() => setActiveTab('requests')}
                      className="px-3 py-1.5 rounded-lg bg-[#201f21] hover:bg-[#2a2a2c] text-xs font-mono text-[#ffb0cd] border border-[#2a2a2c]"
                    >
                      {isAr ? 'مقارنة التعديل (Diff)' : 'Compare Diff'}
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* Calendar Grid View */
        <div className="grid grid-cols-2 gap-3">
          {filteredDeliverables.map((item) => (
            <div
              key={item.id}
              onClick={() => setActiveDeliverableId(item.id)}
              className="p-3 rounded-xl bg-[#1b1b1d] border border-[#2a2a2c] hover:border-[#ff7bb4]/50 cursor-pointer space-y-2 group"
            >
              <div className="relative aspect-[9/16] rounded-lg overflow-hidden bg-[#201f21]">
                <img
                  src={item.posterImage}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                />
                <span className="absolute top-2 left-2 px-1.5 py-0.5 rounded bg-black/70 text-[9px] font-mono text-white">
                  {item.scheduledDate}
                </span>
              </div>
              <div>
                <div className="text-xs font-bold text-[#e5e1e4] line-clamp-1">
                  {isAr ? item.titleAr : item.title}
                </div>
                <div className="text-[10px] font-mono text-[#dbc0c7] mt-0.5">
                  {item.scheduledTime}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Performance Snapshot Card */}
      <div className="p-4 rounded-2xl bg-[#1b1b1d] border border-[#2a2a2c] space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-[10px] font-mono uppercase text-[#a38a92]">
              {isAr ? 'مؤشرات الأداء الأخيرة' : 'RECENT PERFORMANCE'}
            </div>
            <div className="text-xs font-headline font-bold text-[#e5e1e4] mt-0.5">
              Reel 02: Silk Minimalist Drop
            </div>
          </div>
          <div className="text-right">
            <div className="font-mono text-sm font-bold text-emerald-400">+18.4%</div>
            <div className="text-[10px] text-[#dbc0c7]">94.2k Views</div>
          </div>
        </div>

        {/* Dynamic Sparkline Graphic */}
        <div className="h-10 w-full flex items-end gap-1.5 pt-2">
          {[20, 35, 45, 30, 60, 50, 75, 90, 85, 95, 100].map((val, idx) => (
            <div
              key={idx}
              className="flex-1 rounded-t bg-gradient-to-t from-[#7c2d4c] to-[#ff7bb4] hover:opacity-100 transition-all opacity-80"
              style={{ height: `${val}%` }}
              title={`Day ${idx + 1}: ${val * 940} views`}
            ></div>
          ))}
        </div>
      </div>
    </div>
  );
};
