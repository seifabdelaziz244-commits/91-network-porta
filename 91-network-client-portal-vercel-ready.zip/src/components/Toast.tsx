import React from 'react';
import { useApp } from '../context/AppContext';

export const Toast: React.FC = () => {
  const { toastMessage } = useApp();

  if (!toastMessage) return null;

  return (
    <div className="fixed bottom-20 inset-x-4 z-50 flex justify-center pointer-events-none animate-in fade-in slide-in-from-bottom-3 duration-200">
      <div className="max-w-md w-full px-4 py-3 rounded-xl bg-[#1b1b1d]/95 backdrop-blur-xl border border-[#ff7bb4]/50 shadow-[0_0_24px_rgba(255,123,180,0.25)] flex items-center gap-3 text-xs text-[#e5e1e4] pointer-events-auto">
        <span className="material-symbols-outlined text-[18px] text-[#ff7bb4] flex-shrink-0">
          info
        </span>
        <span className="flex-1 leading-snug">{toastMessage}</span>
      </div>
    </div>
  );
};
