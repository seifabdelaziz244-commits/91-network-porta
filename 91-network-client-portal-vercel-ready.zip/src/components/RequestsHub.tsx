import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { RequestItem } from '../types';

export const RequestsHub: React.FC = () => {
  const {
    locale,
    userRole,
    activeClientId,
    currentClient,
    requests,
    setIsBriefModalOpen,
    setActiveDeliverableId,
    showToast
  } = useApp();
  const isAr = locale === 'ar';

  const [activeTab, setActiveTab] = useState<'all' | 'pending' | 'in_progress' | 'completed'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [diffViewMode, setDiffViewMode] = useState<'split' | 'graded' | 'original'>('split');

  const clientScopedRequests = requests.filter((r) => {
    if (userRole === 'agency_admin') return true;
    return !r.clientId || r.clientId === activeClientId;
  });

  const filteredRequests = clientScopedRequests.filter((r) => {
    if (activeTab === 'pending') return r.status === 'pending_review' || r.status === 'awaiting_feedback';
    if (activeTab === 'in_progress') return r.status === 'in_progress';
    if (activeTab === 'completed') return r.status === 'completed';
    return true;
  }).filter((r) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      r.title.toLowerCase().includes(q) ||
      r.code.toLowerCase().includes(q) ||
      r.typeLabel.toLowerCase().includes(q)
    );
  });

  return (
    <div className="pt-20 pb-24 px-4 max-w-xl mx-auto space-y-5">
      {/* Header & Retainer Allocation */}
      <div className="p-4 rounded-2xl bg-[#1b1b1d] border border-[#2a2a2c] space-y-3 shadow-lg">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-[10px] font-mono uppercase text-[#a38a92] tracking-wider">
              {isAr ? 'حصة الرتينر الحالية' : 'RETAINER ALLOCATION'}
            </div>
            <div className="text-sm font-headline font-bold text-[#e5e1e4] mt-0.5">
              14 {isAr ? 'معتمدة' : 'Approved'} / <span className="text-[#ff7bb4]">4 {isAr ? 'متاحة' : 'Available'}</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() =>
                showToast(isAr ? 'تم فتح خيارات شحن وحدات الإنتاج' : 'Top-up options opened')
              }
              className="px-2.5 py-1 rounded-lg bg-[#201f21] hover:bg-[#2a2a2c] text-[#dbc0c7] hover:text-[#e5e1e4] text-xs font-mono border border-[#2a2a2c] transition-colors"
            >
              {isAr ? 'شحن وحدات +' : '+ Top-up Units'}
            </button>
            <button
              onClick={() => setIsBriefModalOpen(true)}
              className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-[#ff7bb4] to-[#ffb0cd] text-[#780846] text-xs font-headline font-bold hover:opacity-95 shadow-sm transition-all flex items-center gap-1 cursor-pointer"
            >
              <span>+</span>
              <span>{isAr ? 'طلب جديد' : 'New Request'}</span>
            </button>
          </div>
        </div>

        {/* Search Bar */}
        <div className="relative">
          <span
            className={`material-symbols-outlined absolute top-1/2 -translate-y-1/2 text-[18px] text-[#a38a92] ${
              isAr ? 'right-3' : 'left-3'
            }`}
          >
            search
          </span>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={
              isAr
                ? 'البحث برقم الطلب (#REQ) أو نوع المخرجة أو اسم الطاقم...'
                : 'Search by ID (#REQ-881), deliverable, or team...'
            }
            className={`w-full h-10 rounded-xl bg-[#201f21] border border-[#2a2a2c] focus:border-[#ff7bb4] text-xs text-[#e5e1e4] placeholder-[#554248] focus:outline-none transition-colors ${
              isAr ? 'pr-9 pl-3' : 'pl-9 pr-3'
            }`}
          />
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
        {[
          { id: 'all', labelEn: 'All (7)', labelAr: 'الكل (7)' },
          { id: 'pending', labelEn: 'Pending (2)', labelAr: 'معلق (2)' },
          { id: 'in_progress', labelEn: 'In Progress (3)', labelAr: 'قيد التنفيذ (3)' },
          { id: 'completed', labelEn: 'Completed', labelAr: 'مكتمل' }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-3 py-1.5 rounded-full text-xs font-mono flex-shrink-0 transition-all ${
              activeTab === tab.id
                ? 'bg-[#2a2a2c] text-[#ffb0cd] border border-[#ff7bb4]/40 font-bold'
                : 'bg-[#1b1b1d] text-[#dbc0c7] border border-[#2a2a2c] hover:border-[#554248]'
            }`}
          >
            {isAr ? tab.labelAr : tab.labelEn}
          </button>
        ))}
      </div>

      {/* Pipeline Requests Feed */}
      <div className="space-y-4">
        {filteredRequests.map((req) => (
          <div
            key={req.id}
            className="p-4 rounded-2xl bg-[#1b1b1d] border border-[#2a2a2c] hover:border-[#554248] transition-all space-y-3 shadow-lg"
          >
            {/* Header with Badges */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs font-bold text-[#ffb0cd]">{req.code}</span>
                <span className="text-[#554248]">·</span>
                <span className="text-[10px] font-mono text-[#a38a92]">
                  {isAr ? req.typeLabelAr : req.typeLabel}
                </span>
              </div>
              <span
                className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                  req.status === 'in_progress'
                    ? 'bg-[#ff7bb4]/20 text-[#ffb0cd]'
                    : req.status === 'awaiting_feedback'
                    ? 'bg-amber-500/20 text-amber-300'
                    : req.status === 'pending_review'
                    ? 'bg-purple-500/20 text-purple-300'
                    : 'bg-[#2a2a2c] text-[#dbc0c7]'
                }`}
              >
                {isAr ? req.statusLabelAr : req.statusLabel}
              </span>
            </div>

            {/* Title & Desc */}
            <div>
              <h3 className="font-headline text-base font-bold text-[#e5e1e4]">
                {isAr ? req.titleAr : req.title}
              </h3>
              <p className="text-xs text-[#dbc0c7] mt-1">
                {isAr ? req.descriptionAr : req.description}
              </p>
            </div>

            {/* Special 4-Stage Progress Tracker for REQ-881 */}
            {req.code === '#REQ-881' && (
              <div className="p-3 rounded-xl bg-[#201f21] border border-[#2a2a2c] space-y-2">
                <div className="flex items-center justify-between text-[11px] font-mono text-[#dbc0c7]">
                  <span>{isAr ? 'مراحل الإنتاج والتسليم' : 'Production Pipeline'}</span>
                  <span className="text-[#ff7bb4]">Stage 2 of 4 (Grading)</span>
                </div>
                <div className="grid grid-cols-4 gap-1.5 text-center text-[9px] font-mono">
                  <div className="py-1 rounded bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">
                    ✓ BRIEF
                  </div>
                  <div className="py-1 rounded bg-[#ff7bb4] text-[#780846] font-bold shadow-sm animate-pulse">
                    PRODUCTION
                  </div>
                  <div className="py-1 rounded bg-[#2a2a2c] text-[#a38a92]">CLIENT QA</div>
                  <div className="py-1 rounded bg-[#2a2a2c] text-[#a38a92]">DELIVERED</div>
                </div>
              </div>
            )}

            {/* Color Grade Diff Interactive View for REQ-879 */}
            {req.code === '#REQ-879' && req.diffImages && (
              <div className="p-3 rounded-xl bg-[#201f21] border border-[#2a2a2c] space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="text-[11px] font-mono text-amber-300 flex items-center gap-1.5">
                    <span className="material-symbols-outlined text-[15px]">compare</span>
                    <span>{isAr ? 'مقارنة التعديل اللوني (LUT Diff):' : 'Color Grade Side-by-Side:'}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => setDiffViewMode('split')}
                      className={`px-2 py-0.5 rounded text-[10px] font-mono ${
                        diffViewMode === 'split' ? 'bg-[#ff7bb4] text-[#780846]' : 'text-[#dbc0c7]'
                      }`}
                    >
                      Split
                    </button>
                    <button
                      onClick={() => setDiffViewMode('graded')}
                      className={`px-2 py-0.5 rounded text-[10px] font-mono ${
                        diffViewMode === 'graded' ? 'bg-[#ff7bb4] text-[#780846]' : 'text-[#dbc0c7]'
                      }`}
                    >
                      Graded
                    </button>
                  </div>
                </div>

                {/* Diff Viewer */}
                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-1">
                    <div className="relative h-28 rounded-lg overflow-hidden border border-[#2a2a2c]">
                      <img
                        src={req.diffImages.original}
                        alt="Original"
                        className="w-full h-full object-cover"
                      />
                      <span className="absolute bottom-1 left-1 px-1.5 py-0.5 rounded bg-black/70 text-[9px] font-mono text-white">
                        Camera Raw
                      </span>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <div className="relative h-28 rounded-lg overflow-hidden border border-[#ff7bb4]/50 shadow-sm">
                      <img
                        src={req.diffImages.graded}
                        alt="Graded"
                        className="w-full h-full object-cover"
                      />
                      <span className="absolute bottom-1 left-1 px-1.5 py-0.5 rounded bg-[#ff7bb4] text-[9px] font-mono text-[#780846] font-bold">
                        Kodak 5219 v2.2
                      </span>
                    </div>
                  </div>
                </div>

                <p className="text-[11px] text-[#dbc0c7] italic">
                  "{isAr ? req.agencyNoteAr : req.agencyNote}"
                </p>
              </div>
            )}

            {/* Bottom Actions Footer */}
            <div className="pt-2 border-t border-[#2a2a2c] flex items-center justify-between text-xs">
              <div className="flex items-center gap-2 font-mono text-[11px] text-[#a38a92]">
                <span className="material-symbols-outlined text-[15px]">schedule</span>
                <span>{isAr ? req.dueTextAr : req.dueText}</span>
              </div>

              <div className="flex items-center gap-2">
                {req.code === '#REQ-882' ? (
                  <button
                    onClick={() => setIsBriefModalOpen(true)}
                    className="px-3 py-1.5 rounded-lg bg-[#201f21] hover:bg-[#2a2a2c] text-[#ffb0cd] font-mono text-xs border border-[#ff7bb4]/40"
                  >
                    {isAr ? 'عرض مسودة الموجز' : 'View Brief Preview'}
                  </button>
                ) : req.code === '#REQ-879' ? (
                  <>
                    <button
                      onClick={() =>
                        showToast(
                          isAr
                            ? 'تم فتح نافذة كتابة الملاحظات الزمنية'
                            : 'Timestamp note editor opened'
                        )
                      }
                      className="px-2.5 py-1.5 rounded-lg bg-[#201f21] hover:bg-[#2a2a2c] text-[#dbc0c7] font-mono text-xs border border-[#2a2a2c]"
                    >
                      {isAr ? 'ملاحظة زمنية' : 'Timestamp Note'}
                    </button>
                    <button
                      onClick={() =>
                        showToast(
                          isAr
                            ? 'تم اعتماد التعديل اللوني للوك بوك بنجاح'
                            : 'Color grade v2.2 approved!'
                        )
                      }
                      className="px-3.5 py-1.5 rounded-lg bg-[#ff7bb4] text-[#780846] font-headline font-bold text-xs"
                    >
                      {isAr ? 'اعتماد الألوان' : 'Approve Grade'}
                    </button>
                  </>
                ) : (
                  <button
                    onClick={() =>
                      showToast(
                        isAr
                          ? 'جاري فتح مساحة مراجعة المقاطع على Frame.io...'
                          : 'Opening review clips in Frame.io player...'
                      )
                    }
                    className="px-3 py-1.5 rounded-lg bg-[#201f21] hover:bg-[#2a2a2c] text-[#dbc0c7] hover:text-[#e5e1e4] font-mono text-xs border border-[#2a2a2c]"
                  >
                    {isAr ? 'مراجعة على Frame.io' : 'Review on Frame.io'}
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Recently Completed Section */}
      <div className="p-4 rounded-2xl bg-[#1b1b1d] border border-[#2a2a2c] space-y-3">
        <div className="flex items-center justify-between">
          <span className="font-headline text-xs font-bold text-[#e5e1e4] uppercase tracking-wider">
            {isAr ? 'المخرجات المسلّمة مؤخراً' : 'Recently Completed & Delivered'}
          </span>
          <span className="text-[10px] font-mono text-emerald-400">OCTOBER 2024</span>
        </div>

        <div className="space-y-2 text-xs">
          <div className="p-2.5 rounded-xl bg-[#201f21] flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <span className="material-symbols-outlined text-[18px] text-emerald-400">
                check_circle
              </span>
              <div>
                <div className="font-semibold text-[#e5e1e4]">
                  Reel 01: Silk Storm Coat Sunset Cut
                </div>
                <div className="text-[10px] font-mono text-[#a38a92]">
                  Delivered Oct 18 · 1.2GB ProRes 422
                </div>
              </div>
            </div>
            <button
              onClick={() =>
                showToast(
                  isAr ? 'جاري تنزيل ملف 1.2GB من درايف...' : 'Downloading 1.2GB ProRes asset...'
                )
              }
              className="p-1.5 rounded-lg bg-[#2a2a2c] text-[#ffb0cd] hover:bg-[#ff7bb4] hover:text-[#780846] transition-colors"
            >
              <span className="material-symbols-outlined text-[16px]">download</span>
            </button>
          </div>

          <div className="p-2.5 rounded-xl bg-[#201f21] flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <span className="material-symbols-outlined text-[18px] text-emerald-400">
                check_circle
              </span>
              <div>
                <div className="font-semibold text-[#e5e1e4]">
                  Editorial Stills Lookbook Batch 01
                </div>
                <div className="text-[10px] font-mono text-[#a38a92]">
                  Delivered Oct 16 · 850MB 50MP RAWs
                </div>
              </div>
            </div>
            <button
              onClick={() =>
                showToast(isAr ? 'جاري تنزيل حزمة الصور...' : 'Downloading 850MB stills archive...')
              }
              className="p-1.5 rounded-lg bg-[#2a2a2c] text-[#ffb0cd] hover:bg-[#ff7bb4] hover:text-[#780846] transition-colors"
            >
              <span className="material-symbols-outlined text-[16px]">download</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
