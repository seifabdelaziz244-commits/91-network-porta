export type Locale = 'en' | 'ar';

export type UserRole = 'agency_admin' | 'client';

export type TabType = 'home' | 'content' | 'requests' | 'shoots' | 'more' | 'admin';

export interface ClientAccount {
  id: string;
  name: string;
  nameAr: string;
  industry: string;
  industryAr: string;
  location: string;
  locationAr: string;
  primaryContact: string;
  email: string;
  phone: string;
  retainerTier: string;
  retainerTierAr: string;
  retainerAmountEGP: number;
  activeDeliverablesCount: number;
  totalDeliverablesQuota: number;
  activeShootsCount: number;
  status: 'active' | 'review' | 'pending' | 'suspended';
  badgeColor?: string;
  passkey?: string;
  loginCode?: string;
  dueDay?: number;
  graceDays?: number;
  payments?: Record<string, boolean>;
  excusedMonths?: string[];
  terminated?: boolean;
  accountStatus?: 'paid' | 'due' | 'critical' | 'excused' | 'terminated';
  createdAt?: string;
}

export interface ClientUpdate {
  id: string;
  clientId: string; // 'all' or specific client ID e.g. 'client-lumen'
  title: string;
  titleAr: string;
  body: string;
  bodyAr: string;
  author: string;
  authorRole: string;
  timestamp: string;
  type: 'production' | 'creative' | 'dispatch' | 'billing';
  priority?: 'urgent' | 'normal' | 'log';
}

export interface CrewMember {
  name: string;
  nameAr: string;
  role: string;
  roleAr: string;
  initials: string;
  phone: string;
  badge?: string;
  isClient?: boolean;
}

export interface ShootTimelineItem {
  time: string;
  timeAr: string;
  location: string;
  locationAr: string;
  title: string;
  titleAr: string;
  description: string;
  descriptionAr: string;
  type: 'prep' | 'styling' | 'stills' | 'lunch' | 'video' | 'wrap';
}

export interface ShootCallSheet {
  id: string;
  code: string;
  collection: string;
  collectionAr: string;
  title: string;
  titleAr: string;
  status: string;
  statusAr: string;
  countdown: string;
  countdownAr: string;
  date: string;
  dateAr: string;
  time: string;
  timeAr: string;
  location: string;
  locationAr: string;
  gateAccess: string;
  gateAccessAr: string;
  gateNote: string;
  gateNoteAr: string;
  heroImage: string;
  mapImage: string;
  weather: string;
  weatherAr: string;
  sunset: string;
  timeline: ShootTimelineItem[];
  crew: CrewMember[];
  gear: {
    cinemaCamera: string;
    cinemaSpecs: string;
    stillsCamera: string;
    stillsSpecs: string;
    aspectRatios: string;
    aspectNote: string;
    aspectNoteAr: string;
    lenses: string;
    lensNote: string;
    rawVaultUrl: string;
  };
  confirmedBy: string;
  confirmedByAr: string;
}

export interface ContentDeliverable {
  id: string;
  code: string;
  clientId?: string;
  type: 'reel' | 'carousel' | 'tiktok';
  platform: string;
  title: string;
  titleAr: string;
  description: string;
  descriptionAr: string;
  status: 'action_required' | 'scheduled' | 'in_revision' | 'published';
  scheduledDate: string;
  scheduledTime: string;
  scheduledTimeAr: string;
  duration?: string;
  format?: string;
  aspectRatio: string;
  posterImage: string;
  slideImages?: string[];
  audioTrack?: string;
  viralityScore?: string;
  approvedBy?: string;
  rawVaultUrl: string;
  cameraSpecs?: string;
  dpNote?: string;
  dpNoteAr?: string;
  dpAuthor?: string;
  captionEn?: string;
  captionAr?: string;
  hashtags?: string;
  firstComment?: string;
  firstCommentAr?: string;
  revisionRound?: number;
  commentsCount?: number;
}

export interface RequestItem {
  id: string;
  code: string;
  clientId?: string;
  emailDispatched?: boolean;
  emailTarget?: string;
  title: string;
  titleAr: string;
  type: 'video' | 'brief' | 'revision' | 'design';
  typeLabel: string;
  typeLabelAr: string;
  status: 'in_progress' | 'pending_review' | 'awaiting_feedback' | 'queued' | 'completed';
  statusLabel: string;
  statusLabelAr: string;
  dueText: string;
  dueTextAr: string;
  createdTime: string;
  createdTimeAr: string;
  description: string;
  descriptionAr: string;
  team: string;
  stage?: 'brief_approved' | 'production' | 'qa' | 'delivered';
  diffImages?: {
    original: string;
    graded: string;
  };
  agencyNote?: string;
  agencyNoteAr?: string;
  deliverablesSummary?: string;
  retainerImpact?: string;
}

export interface InvoiceItem {
  id: string;
  invoiceNumber: string;
  title: string;
  titleAr: string;
  cycle: string;
  cycleAr: string;
  clearedDate: string;
  clearedDateAr: string;
  amount: string;
  status: 'scheduled' | 'paid';
  statusLabel: string;
  paymentMethod: string;
  hasTaxPdf: boolean;
}

export interface ChatMessage {
  id: string;
  sender: 'client' | 'ai';
  author: string;
  time: string;
  text: string;
  bullets?: Array<{
    icon: string;
    title: string;
    desc: string;
  }>;
}
