import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ASSETS } from '../data/mockData';

export const Header: React.FC = () => {
  const {
    locale,
    toggleLocale,
    isVaultLocked,
    setIsVaultLocked,
    userRole,
    setUserRole,
    activeTab,
    setActiveTab,
    currentClient,
    clientUpdates,
    showToast
  } = useApp();
  const [showNotifications, setShowNotifications] = useState(false);

  const isAr = locale === 'ar';
  const isAdmin = userRole === 'agency_admin';

  return (
    <header className="fixed top-0 inset-x-0 z-50 bg-[#131315]/90 backdrop-blur-xl border-b border-[#2a2a2c]/60 pt-safe transition-colors">
      <div className="h-16 px-4 max-w-xl mx-auto flex items-center justify-between gap-2">
        {/* Left: Brand Identity & Active Profile / Role */}
        <div className="flex items-center gap-2.5 min-w-0 flex-1">
          <img
            src={ASSETS.logo}
            alt="91` Network Logo"
            className="h-8 w-auto object-contain flex-shrink-0 cursor-pointer hover:opacity-90 transition-opacity"
            onClick={() => setIsVaultLocked(!isVaultLocked)}
            title="Click to toggle Vault login / sign in screen"
          />
          <div className="flex flex-col min-w-0">
            <div className="flex items-center gap-1.5">
              <span className="font-headline font-bold text-base text-[#e5e1e4] tracking-tight leading-none">
                91`
              </span>
              <button
                onClick={() => {
                  if (isAdmin) {
                    setUserRole('client');
                    setActiveTab('home');
                    showToast(isAr ? 'تم التبديل إلى بوابة العميل' : 'Switched to Client Portal');
                  } else {
                    setUserRole('agency_admin');
                    setActiveTab('admin');
                    showToast(isAr ? 'تم التبديل إلى لوحة تحكم الوكالة' : 'Switched to Agency Admin Hub');
                  }
                }}
                className={`px-2 py-0.5 rounded font-mono text-[10px] font-bold uppercase tracking-wider truncate border transition-all cursor-pointer ${
                  isAdmin
                    ? 'bg-[#ff7bb4]/20 text-[#ffb0cd] border-[#ff7bb4]/40 hover:bg-[#ff7bb4]/30'
                    : 'bg-[#2a2a2c] text-[#dbc0c7] border-[#554248]/40 hover:text-[#e5e1e4]'
                }`}
                title="Click to toggle Agency Admin / Client role"
              >
                {isAdmin
                  ? isAr
                    ? 'إدارة الوكالة'
                    : 'AGENCY ADMIN'
                  : isAr
                  ? currentClient.nameAr
                  : currentClient.name.toUpperCase()}
              </button>

              <span className="px-1.5 py-0.2 rounded bg-[#201f21] text-emerald-400 font-mono text-[9px] border border-emerald-500/30">
                EGP
              </span>
            </div>

            <div className="flex items-center gap-1.5 mt-0.5">
              <span className="font-sans text-[10px] text-[#dbc0c7] uppercase tracking-wider opacity-80 truncate">
                {isAdmin
                  ? isAr
                    ? 'الملف الشخصي للمسؤول · إدارة العملاء'
                    : 'Admin Profile · Content Control'
                  : isAr
                  ? 'بوابة العميل الرقمية'
                  : 'Client Portal'}
              </span>
              <span className="text-[#554248] text-[9px]">·</span>
              <button
                onClick={() => {
                  const newRole = isAdmin ? 'client' : 'agency_admin';
                  setUserRole(newRole);
                  setActiveTab(newRole === 'agency_admin' ? 'admin' : 'home');
                  showToast(
                    newRole === 'agency_admin'
                      ? isAr
                        ? 'مرحباً بالمدير العام (سيف عبد العزيز — SEIF ABD ELAZIZ)'
                        : 'Switched to Agency Admin View (SEIF ABD ELAZIZ)'
                      : isAr
                      ? `مرحباً بالعميل (${currentClient.primaryContact})`
                      : `Switched to Client View (${currentClient.name})`
                  );
                }}
                className="text-[9px] font-mono text-[#ffb0cd] hover:underline cursor-pointer"
              >
                {isAdmin
                  ? isAr
                    ? 'عرض كعميل'
                    : 'View Client'
                  : isAr
                  ? 'عرض كمسؤول'
                  : 'Switch Admin'}
              </button>
            </div>
          </div>
        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-1.5 flex-shrink-0">
          {/* Language Switcher */}
          <button
            onClick={toggleLocale}
            aria-label={isAr ? 'تبديل اللغة' : 'Switch Language'}
            className="h-9 px-2 rounded-lg bg-[#1b1b1d] border border-[#2a2a2c] flex items-center gap-1 text-[#dbc0c7] hover:text-[#e5e1e4] hover:border-[#ff7bb4]/50 transition-all cursor-pointer"
            title="Switch Language / تبديل اللغة"
          >
            <span
              className={`px-1.5 py-0.5 rounded text-[11px] font-mono font-bold transition-all ${
                !isAr
                  ? 'bg-[#ff7bb4] text-[#780846] shadow-sm'
                  : 'text-[#dbc0c7] hover:text-[#e5e1e4]'
              }`}
            >
              EN
            </span>
            <span className="text-[#554248] text-xs">/</span>
            <span
              className={`px-1.5 py-0.5 rounded text-[11px] font-mono font-bold transition-all ${
                isAr
                  ? 'bg-[#ff7bb4] text-[#780846] shadow-sm'
                  : 'text-[#dbc0c7] hover:text-[#e5e1e4]'
              }`}
            >
              عربي
            </span>
          </button>

          {/* Notifications Trigger */}
          <div className="relative">
            <button
              onClick={() => setShowNotifications(!showNotifications)}
              aria-label={isAr ? 'الإشعارات' : 'Notifications'}
              className="relative w-9 h-9 rounded-lg bg-[#1b1b1d] border border-[#2a2a2c] flex items-center justify-center text-[#dbc0c7] hover:text-[#ffb0cd] hover:border-[#ff7bb4]/40 transition-colors cursor-pointer"
            >
              <span className="material-symbols-outlined text-[19px]">notifications</span>
              <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-[#ff7bb4] ring-2 ring-[#131315] shadow-[0_0_8px_#ff7bb4]"></span>
            </button>

            {/* Notifications Dropdown populated with live ClientUpdates */}
            {showNotifications && (
              <div
                className={`absolute top-11 ${
                  isAr ? 'left-0' : 'right-0'
                } w-80 rounded-2xl bg-[#1b1b1d] border border-[#2a2a2c] p-3 shadow-2xl z-50 animate-in fade-in slide-in-from-top-2 duration-150`}
              >
                <div className="flex items-center justify-between pb-2 border-b border-[#2a2a2c]">
                  <span className="font-headline text-xs font-bold text-[#e5e1e4] uppercase tracking-wider">
                    {isAr ? 'تحديثات الوكالة المباشرة' : 'Agency Live Bulletins'}
                  </span>
                  <span className="font-mono text-[10px] text-[#ffb0cd]">
                    {clientUpdates.length} UPDATES
                  </span>
                </div>

                <div className="flex flex-col gap-2 pt-2 max-h-72 overflow-y-auto no-scrollbar">
                  {clientUpdates.map((upd) => (
                    <div
                      key={upd.id}
                      className="p-2.5 rounded-xl bg-[#201f21] hover:bg-[#2a2a2c] transition-colors cursor-pointer space-y-1"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5 text-[11px] text-[#ff7bb4] font-semibold">
                          <span className="w-1.5 h-1.5 rounded-full bg-[#ff7bb4] animate-pulse"></span>
                          <span className="truncate">{isAr ? upd.titleAr : upd.title}</span>
                        </div>
                        <span className="text-[9px] font-mono text-[#a38a92]">{upd.timestamp}</span>
                      </div>
                      <p className="text-[11px] text-[#dbc0c7] line-clamp-2">
                        {isAr ? upd.bodyAr : upd.body}
                      </p>
                      <div className="text-[9px] font-mono text-[#a38a92]">
                        {upd.author} ({upd.authorRole})
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* User Profile / Vault Lock Avatar */}
          <button
            onClick={() => {
              if (isAdmin) {
                setActiveTab(activeTab === 'admin' ? 'home' : 'admin');
              } else {
                setIsVaultLocked(true);
              }
            }}
            title={isAdmin ? 'Admin Profile / Content Manager' : 'Lock to Vault Sign In'}
            className={`w-9 h-9 rounded-xl border flex items-center justify-center transition-all cursor-pointer ${
              isAdmin
                ? 'bg-[#ff7bb4]/20 border-[#ff7bb4]/50 text-[#ffb0cd] hover:bg-[#ff7bb4] hover:text-[#780846]'
                : 'bg-[#1b1b1d] border-[#2a2a2c] text-[#dbc0c7] hover:text-[#ffb0cd]'
            }`}
          >
            <span className="material-symbols-outlined text-[18px]">
              {isAdmin ? 'admin_panel_settings' : 'account_circle'}
            </span>
          </button>
        </div>
      </div>
    </header>
  );
};
