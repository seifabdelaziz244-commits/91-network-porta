import React, { useState } from 'react';
import { useApp } from '../context/AppContext';

export const DeliverableReviewModal: React.FC = () => {
  const {
    locale,
    activeDeliverableId,
    setActiveDeliverableId,
    deliverables,
    approveDeliverable,
    requestRevision,
    showToast
  } = useApp();

  const isAr = locale === 'ar';
  const [selectedVersion, setSelectedVersion] = useState<'v2' | 'v1'>('v2');
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [copiedCaption, setCopiedCaption] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [comments, setComments] = useState<string[]>([
    'Color graded to match the muted concrete tones requested in the last session. Sound sync locked precisely at 0:14 beat drop.'
  ]);

  if (!activeDeliverableId) return null;

  const deliverable = deliverables.find((d) => d.id === activeDeliverableId) || deliverables[0];

  const handleCopyCaption = () => {
    const text = isAr ? deliverable.captionAr : deliverable.captionEn;
    if (text) {
      navigator.clipboard?.writeText(text);
      setCopiedCaption(true);
      showToast(isAr ? 'تم نسخ النص التحريري إلى الحافظة' : 'Caption copied to clipboard!');
      setTimeout(() => setCopiedCaption(false), 2500);
    }
  };

  const handleAddComment = () => {
    if (!commentText.trim()) return;
    setComments((prev) => [...prev, `Joseph K. (Client): ${commentText}`]);
    setCommentText('');
    showToast(isAr ? 'تمت إضافة الملاحظة الزمنية' : 'Timestamped comment added');
  };

  const handleApprove = () => {
    approveDeliverable(deliverable.id);
    setActiveDeliverableId(null);
  };

  const handleRevision = () => {
    requestRevision(deliverable.id, 'Revision requested from review player');
    setActiveDeliverableId(null);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-[#131315]/95 backdrop-blur-2xl text-[#e5e1e4] flex flex-col justify-between animate-in fade-in duration-200">
      {/* Top Header */}
      <div className="sticky top-0 inset-x-0 z-10 bg-[#131315]/90 backdrop-blur-md border-b border-[#2a2a2c] pt-safe px-4 py-3 flex items-center justify-between">
        <button
          onClick={() => setActiveDeliverableId(null)}
          className="flex items-center gap-1.5 text-xs font-mono text-[#dbc0c7] hover:text-[#e5e1e4] transition-colors cursor-pointer"
        >
          <span className="material-symbols-outlined text-[18px]">
            {isAr ? 'arrow_forward' : 'arrow_back'}
          </span>
          <span>{isAr ? 'العودة للجدول' : 'Back to Calendar'}</span>
        </button>

        {/* Version Toggle */}
        <div className="flex items-center p-1 rounded-xl bg-[#1b1b1d] border border-[#2a2a2c]">
          <button
            onClick={() => setSelectedVersion('v2')}
            className={`px-2.5 py-0.5 rounded-lg text-xs font-mono transition-all ${
              selectedVersion === 'v2'
                ? 'bg-[#2a2a2c] text-[#ffb0cd] font-bold'
                : 'text-[#dbc0c7]'
            }`}
          >
            V2 (Current)
          </button>
          <button
            onClick={() => setSelectedVersion('v1')}
            className={`px-2.5 py-0.5 rounded-lg text-xs font-mono transition-all ${
              selectedVersion === 'v1'
                ? 'bg-[#2a2a2c] text-[#ffb0cd] font-bold'
                : 'text-[#dbc0c7]'
            }`}
          >
            V1 (Rough)
          </button>
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={() =>
              showToast(isAr ? 'تم نسخ رابط المراجعة للمشاركة' : 'Review link copied to clipboard')
            }
            className="w-8 h-8 rounded-lg bg-[#1b1b1d] border border-[#2a2a2c] flex items-center justify-center text-[#dbc0c7] hover:text-[#ffb0cd] transition-colors"
          >
            <span className="material-symbols-outlined text-[16px]">share</span>
          </button>
        </div>
      </div>

      {/* Main Content Scrollable Area */}
      <div className="flex-1 px-4 py-4 max-w-xl mx-auto w-full space-y-5 pb-28">
        {/* Title & Metadata */}
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] font-mono text-[#ffb0cd] font-bold">
              {deliverable.code}
            </span>
            <span className="text-[#554248]">·</span>
            <span className="text-[10px] font-mono text-emerald-400">
              DP VERIFIED · Sarah T.
            </span>
          </div>
          <h1 className="font-headline text-xl font-bold text-[#e5e1e4]">
            {isAr ? deliverable.titleAr : deliverable.title}
          </h1>
          <p className="text-xs text-[#dbc0c7] mt-1">
            {isAr ? deliverable.descriptionAr : deliverable.description}
          </p>
        </div>

        {/* 9:16 Video Stage */}
        <div className="relative aspect-[9/16] max-h-[480px] mx-auto rounded-2xl overflow-hidden bg-black border border-[#554248]/50 shadow-2xl group flex items-center justify-center">
          <img
            src={deliverable.posterImage}
            alt="Video Frame"
            className="w-full h-full object-cover"
          />

          {/* Player Controls Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/40 flex flex-col justify-between p-3">
            {/* Top Bar */}
            <div className="flex items-center justify-between text-[11px] font-mono text-white/90">
              <span className="px-2 py-0.5 rounded bg-black/60 backdrop-blur-md">
                4K ProRes · 0:28
              </span>
              <button
                onClick={() => setIsMuted(!isMuted)}
                className="w-8 h-8 rounded-full bg-black/60 backdrop-blur-md flex items-center justify-center"
              >
                <span className="material-symbols-outlined text-[16px]">
                  {isMuted ? 'volume_off' : 'volume_up'}
                </span>
              </button>
            </div>

            {/* Center Play/Pause */}
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="self-center w-14 h-14 rounded-full bg-[#ff7bb4]/90 text-[#780846] flex items-center justify-center shadow-[0_0_20px_rgba(255,123,180,0.5)] group-hover:scale-110 transition-transform cursor-pointer"
            >
              <span className="material-symbols-outlined text-[32px]">
                {isPlaying ? 'pause' : 'play_arrow'}
              </span>
            </button>

            {/* Bottom Scrubber & Timecode */}
            <div className="space-y-1.5">
              <div className="w-full h-1.5 rounded-full bg-white/20 cursor-pointer overflow-hidden">
                <div className="h-full w-1/2 bg-[#ff7bb4] rounded-full"></div>
              </div>
              <div className="flex items-center justify-between text-[10px] font-mono text-white/80">
                <span>00:14 / 00:28</span>
                <span className="flex items-center gap-1">
                  <span className="material-symbols-outlined text-[14px] text-[#ff7bb4]">
                    graphic_eq
                  </span>
                  <span>Lykke Li · Neon Twilight</span>
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Master RAWs & Cloud Archive Banner */}
        <div className="p-3 rounded-xl bg-[#1b1b1d] border border-[#2a2a2c] flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[18px] text-[#ffb0cd]">
              inventory_2
            </span>
            <div>
              <div className="font-semibold text-[#e5e1e4]">Master ProRes & Camera RAW</div>
              <div className="text-[10px] font-mono text-[#a38a92]">{deliverable.rawVaultUrl}</div>
            </div>
          </div>
          <button
            onClick={() =>
              showToast(isAr ? 'جاري فتح مجلد التحميل المباشر...' : 'Opening raw direct download...')
            }
            className="px-2.5 py-1 rounded bg-[#201f21] hover:bg-[#2a2a2c] text-[#dbc0c7] font-mono text-xs border border-[#2a2a2c]"
          >
            {isAr ? 'فتح' : 'Open'}
          </button>
        </div>

        {/* Caption & Social Copy Section */}
        <div className="p-4 rounded-2xl bg-[#1b1b1d] border border-[#2a2a2c] space-y-3">
          <div className="flex items-center justify-between">
            <span className="font-headline text-xs font-bold text-[#e5e1e4] uppercase tracking-wider">
              {isAr ? 'النص التحريري والوسوم (Social Copy)' : 'Caption & Social Copy'}
            </span>
            <button
              onClick={handleCopyCaption}
              className="px-2.5 py-1 rounded-lg bg-[#201f21] hover:bg-[#2a2a2c] text-xs font-mono text-[#ffb0cd] flex items-center gap-1 transition-colors cursor-pointer"
            >
              <span className="material-symbols-outlined text-[15px]">
                {copiedCaption ? 'check' : 'content_copy'}
              </span>
              <span>
                {copiedCaption
                  ? isAr
                    ? 'تم النسخ'
                    : 'Copied!'
                  : isAr
                  ? 'نسخ النص'
                  : 'Copy'}
              </span>
            </button>
          </div>

          <div className="p-3 rounded-xl bg-[#201f21] text-xs text-[#e5e1e4] font-sans whitespace-pre-line leading-relaxed border border-[#2a2a2c]/60">
            {isAr ? deliverable.captionAr : deliverable.captionEn}
          </div>

          {/* First Comment */}
          <div className="space-y-1">
            <div className="text-[10px] font-mono uppercase text-[#a38a92]">
              {isAr ? 'التعليق الأول المجدول' : 'SCHEDULED FIRST COMMENT'}
            </div>
            <div className="p-2 rounded-lg bg-[#201f21] text-xs text-[#dbc0c7] font-sans italic border border-[#2a2a2c]/40">
              {isAr ? deliverable.firstCommentAr : deliverable.firstComment}
            </div>
          </div>
        </div>

        {/* DP Notes & Feedback Thread */}
        <div className="p-4 rounded-2xl bg-[#1b1b1d] border border-[#2a2a2c] space-y-3">
          <div className="flex items-center justify-between">
            <span className="font-headline text-xs font-bold text-[#e5e1e4] uppercase tracking-wider">
              {isAr ? 'ملاحظات الطاقم الفني وتعديل الألوان' : 'DP Notes & Feedback Thread'}
            </span>
            <span className="text-[10px] font-mono text-[#ff7bb4]">
              {comments.length} NOTES
            </span>
          </div>

          <div className="space-y-2">
            {comments.map((cmt, i) => (
              <div key={i} className="p-2.5 rounded-xl bg-[#201f21] text-xs text-[#dbc0c7]">
                <div className="text-[10px] font-mono text-[#ffb0cd] font-bold mb-0.5">
                  Sarah T. (Lead DP) · 10:45 AM
                </div>
                <p>{cmt}</p>
              </div>
            ))}
          </div>

          {/* Comment Input */}
          <div className="flex items-center gap-2 pt-1">
            <input
              type="text"
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleAddComment();
              }}
              placeholder={
                isAr
                  ? 'أضف ملاحظة زمنية للمخرج (مثال: عدل درجة الظل عند 0:14)...'
                  : 'Add timestamped note (e.g., soften contrast at 0:14)...'
              }
              className="flex-1 h-9 rounded-xl bg-[#201f21] border border-[#2a2a2c] px-3 text-xs text-[#e5e1e4] placeholder-[#554248] focus:outline-none focus:border-[#ff7bb4]"
            />
            <button
              onClick={handleAddComment}
              className="px-3 h-9 rounded-xl bg-[#2a2a2c] hover:bg-[#ff7bb4] hover:text-[#780846] text-xs font-mono text-[#dbc0c7] transition-colors"
            >
              {isAr ? 'إرسال' : 'Send'}
            </button>
          </div>
        </div>
      </div>

      {/* Sticky Bottom Approval Bar */}
      <div className="fixed bottom-0 inset-x-0 z-20 pb-safe bg-[#131315]/95 backdrop-blur-xl border-t border-[#2a2a2c] p-4 shadow-2xl">
        <div className="max-w-xl mx-auto flex items-center justify-between gap-3">
          <button
            onClick={handleRevision}
            className="flex-1 py-3 px-4 rounded-xl bg-[#201f21] hover:bg-[#2a2a2c] text-xs font-mono font-bold text-[#dbc0c7] hover:text-[#e5e1e4] border border-[#2a2a2c] transition-colors cursor-pointer"
          >
            {isAr ? 'طلب تعديل (Revisions)' : 'Request Revisions'}
          </button>
          <button
            onClick={handleApprove}
            className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-[#ff7bb4] to-[#ffb0cd] text-[#780846] font-headline font-bold text-xs hover:opacity-95 shadow-[0_0_20px_rgba(255,123,180,0.4)] flex items-center justify-center gap-1.5 transition-all cursor-pointer"
          >
            <span className="material-symbols-outlined text-[18px]">check_circle</span>
            <span>{isAr ? 'اعتماد ونشر المخرجة' : 'Approve for Post'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
