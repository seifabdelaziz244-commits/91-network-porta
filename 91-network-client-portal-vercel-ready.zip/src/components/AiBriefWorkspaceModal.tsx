import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ASSETS } from '../data/mockData';

export const AiBriefWorkspaceModal: React.FC = () => {
  const {
    locale,
    isBriefModalOpen,
    setIsBriefModalOpen,
    chatMessages,
    addChatMessage,
    submitBrief
  } = useApp();

  const isAr = locale === 'ar';
  const [inputText, setInputText] = useState('');

  if (!isBriefModalOpen) return null;

  const handleSend = () => {
    if (!inputText.trim()) return;
    addChatMessage(inputText);
    setInputText('');
  };

  const handleChipClick = (chipText: string) => {
    addChatMessage(chipText);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-[#131315]/95 backdrop-blur-2xl text-[#e5e1e4] flex flex-col justify-between animate-in fade-in duration-200">
      {/* Top Header */}
      <div className="sticky top-0 inset-x-0 z-10 bg-[#131315]/90 backdrop-blur-md border-b border-[#2a2a2c] pt-safe px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-[#ff7bb4]/20 border border-[#ff7bb4]/40 flex items-center justify-center text-[#ffb0cd]">
            <span className="material-symbols-outlined text-[16px] animate-spin">
              auto_awesome
            </span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-headline text-xs font-bold text-[#e5e1e4] uppercase tracking-wider">
                {isAr ? 'محرر الموجز الذكي' : 'Lumen Intelligence v2.4'}
              </span>
              <span className="inline-flex items-center gap-1 text-[9px] font-mono text-emerald-400">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                CONNECTED
              </span>
            </div>
            <div className="text-[10px] text-[#dbc0c7]">
              {isAr ? 'توليد أمر عمل وإنتاج ذكي فوري' : 'Automated Production Synthesis'}
            </div>
          </div>
        </div>

        <button
          onClick={() => setIsBriefModalOpen(false)}
          className="w-8 h-8 rounded-lg bg-[#1b1b1d] border border-[#2a2a2c] flex items-center justify-center text-[#dbc0c7] hover:text-[#e5e1e4] transition-colors cursor-pointer"
        >
          <span className="material-symbols-outlined text-[18px]">close</span>
        </button>
      </div>

      {/* Main Body */}
      <div className="flex-1 px-4 py-4 max-w-xl mx-auto w-full space-y-5 pb-28">
        {/* Real-time Synthesis Indicator */}
        <div className="p-3 rounded-xl bg-gradient-to-r from-[#201f21] to-[#1b1b1d] border border-[#ff7bb4]/40 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-mono text-[#ffb0cd]">
            <span className="material-symbols-outlined text-[16px] animate-pulse">bolt</span>
            <span>
              {isAr
                ? 'جاري مواءمة الطلب مع ميزانية الرتينر وأصول FW24...'
                : 'Auto-Synthesizing Production Brief #REQ-882...'}
            </span>
          </div>
          <span className="px-2 py-0.5 rounded bg-[#ff7bb4]/20 text-[#ffb0cd] text-[10px] font-mono font-bold">
            LIVE DRAFT
          </span>
        </div>

        {/* Live Dialogue Intake */}
        <div className="space-y-3">
          <span className="font-headline text-xs font-bold text-[#e5e1e4] uppercase tracking-wider">
            {isAr ? 'سجل المحادثة وتحديد المعايير' : 'Live Dialogue Intake'}
          </span>

          <div className="space-y-3">
            {chatMessages.map((msg) => (
              <div
                key={msg.id}
                className={`p-3.5 rounded-2xl text-xs space-y-2 ${
                  msg.sender === 'client'
                    ? 'bg-[#201f21] border border-[#2a2a2c] text-[#e5e1e4] mr-4'
                    : 'bg-[#1b1b1d] border border-[#ff7bb4]/30 text-[#dbc0c7] ml-2'
                }`}
              >
                <div className="flex items-center justify-between text-[10px] font-mono text-[#a38a92]">
                  <span className="font-bold text-[#ffb0cd]">{msg.author}</span>
                  <span>{msg.time}</span>
                </div>
                <p className="leading-relaxed">{msg.text}</p>

                {msg.bullets && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                    {msg.bullets.map((b, i) => (
                      <div
                        key={i}
                        className="p-2 rounded-xl bg-[#131315] border border-[#2a2a2c] flex items-center gap-2"
                      >
                        <span className="material-symbols-outlined text-[16px] text-[#ff7bb4]">
                          {b.icon}
                        </span>
                        <div>
                          <div className="text-[10px] font-mono text-[#a38a92] uppercase">
                            {b.title}
                          </div>
                          <div className="text-[11px] font-semibold text-[#e5e1e4]">
                            {b.desc}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Quick Suggestion Chips */}
          <div className="flex gap-1.5 flex-wrap pt-1">
            {[
              isAr ? '+ إضافة مواصفات العارضين' : '+ Add Talent Specs',
              isAr ? '+ طلب هندسة صوتية مخصصة' : '+ Request Custom Audio',
              isAr ? '+ تسليم عاجل (24 ساعة)' : '+ Expedite Delivery (24h)'
            ].map((chip, idx) => (
              <button
                key={idx}
                onClick={() => handleChipClick(chip)}
                className="px-2.5 py-1 rounded-full bg-[#1b1b1d] hover:bg-[#201f21] border border-[#2a2a2c] text-[11px] text-[#dbc0c7] hover:text-[#ffb0cd] transition-colors cursor-pointer"
              >
                {chip}
              </button>
            ))}
          </div>

          {/* Chat Input Bar */}
          <div className="relative">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleSend();
              }}
              placeholder={
                isAr
                  ? 'أضف أي تفاصيل أخرى للموجز الإبداعي...'
                  : 'Type to refine parameters or specify references...'
              }
              className={`w-full h-10 rounded-xl bg-[#201f21] border border-[#2a2a2c] focus:border-[#ff7bb4] text-xs text-[#e5e1e4] placeholder-[#554248] focus:outline-none transition-colors ${
                isAr ? 'pr-3 pl-10' : 'pl-3 pr-10'
              }`}
            />
            <button
              onClick={handleSend}
              className={`absolute top-1/2 -translate-y-1/2 w-7 h-7 rounded-lg bg-[#2a2a2c] hover:bg-[#ff7bb4] hover:text-[#780846] text-[#dbc0c7] flex items-center justify-center transition-colors ${
                isAr ? 'left-1.5' : 'right-1.5'
              }`}
            >
              <span className="material-symbols-outlined text-[16px]">send</span>
            </button>
          </div>
        </div>

        {/* Structured Brief Preview Card */}
        <div className="p-4 rounded-2xl bg-[#1b1b1d] border border-[#2a2a2c] space-y-4 shadow-xl">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[10px] font-mono text-[#ffb0cd] font-bold">
                {isAr ? 'موجز الإنتاج المُجمّع' : 'STRUCTURED BRIEF PREVIEW'}
              </span>
              <h2 className="font-headline text-base font-bold text-[#e5e1e4] mt-0.5">
                {isAr
                  ? 'ريل حملة معطف الحرير الخام عند الغسق'
                  : 'Raw Silk Trench Coat Dusk Campaign Reel'}
              </h2>
            </div>
            <span className="px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 font-mono text-[10px] font-bold">
              #REQ-882
            </span>
          </div>

          {/* Moodboard Photos Duo */}
          <div className="grid grid-cols-2 gap-2">
            <div className="relative h-28 rounded-xl overflow-hidden border border-[#2a2a2c]">
              <img
                src={ASSETS.briefAestheticSample}
                alt="Aesthetic sample"
                className="w-full h-full object-cover"
              />
              <span className="absolute bottom-1 left-1 px-1.5 py-0.5 rounded bg-black/70 text-[9px] font-mono text-white">
                Aesthetic: Dusk 35mm
              </span>
            </div>
            <div className="relative h-28 rounded-xl overflow-hidden border border-[#2a2a2c]">
              <img
                src={ASSETS.briefTextureSample}
                alt="Texture sample"
                className="w-full h-full object-cover"
              />
              <span className="absolute bottom-1 left-1 px-1.5 py-0.5 rounded bg-black/70 text-[9px] font-mono text-white">
                Texture: Raw Silk Drape
              </span>
            </div>
          </div>

          {/* Parameters Matrix */}
          <div className="space-y-2 text-xs divide-y divide-[#2a2a2c]">
            <div className="pt-2 flex items-center justify-between">
              <span className="text-[#a38a92] font-mono text-[11px]">
                {isAr ? 'الهدف التسويقي' : 'Campaign Objective'}
              </span>
              <span className="text-[#e5e1e4] font-semibold text-right">
                {isAr ? 'فتح الحجز المسبق لكبسولة الحرير' : 'Drive VIP Capsule Pre-orders'}
              </span>
            </div>

            <div className="pt-2 flex items-center justify-between">
              <span className="text-[#a38a92] font-mono text-[11px]">
                {isAr ? 'المخرجات المعتمدة' : 'Deliverables'}
              </span>
              <span className="text-[#ffb0cd] font-mono font-bold text-right">
                1x 4K Cinematic Reel (30s) + 2x Stills
              </span>
            </div>

            <div className="pt-2 flex items-center justify-between">
              <span className="text-[#a38a92] font-mono text-[11px]">
                {isAr ? 'منصات النشر' : 'Distribution'}
              </span>
              <span className="text-[#e5e1e4]">Instagram Reels, TikTok & Meta Ads</span>
            </div>

            <div className="pt-2 flex items-center justify-between">
              <span className="text-[#a38a92] font-mono text-[11px]">
                {isAr ? 'الجدول الزمني' : 'Timeline Target'}
              </span>
              <span className="text-[#e5e1e4] font-mono">Shoot Oct 28 · Publish Oct 30</span>
            </div>

            <div className="pt-2 flex items-center justify-between">
              <span className="text-[#a38a92] font-mono text-[11px]">
                {isAr ? 'تأثير باقة الرتينر' : 'Retainer Impact'}
              </span>
              <span className="text-amber-400 font-mono font-bold">
                -1 Video / -1 Photo (3 Remaining)
              </span>
            </div>

            <div className="pt-2 flex items-center justify-between">
              <span className="text-[#a38a92] font-mono text-[11px]">
                {isAr ? 'طاقم العمل المقترح' : 'Crew Assignment'}
              </span>
              <span className="text-[#e5e1e4]">Sarah T. (Lead DP) & SEIF ABD ELAZIZ</span>
            </div>
          </div>

          {/* Direct Admin Transmission Pill */}
          <div className="p-2.5 rounded-xl bg-[#201f21] border border-[#ff7bb4]/30 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 truncate">
              <span className="material-symbols-outlined text-[16px] text-[#ff7bb4]">forward_to_inbox</span>
              <div className="truncate">
                <span className="text-[9px] font-mono uppercase text-[#a38a92] block">
                  {isAr ? 'الوجهة المباشرة: سيف عبد العزيز (المؤسس)' : 'Direct Admin Dispatch: SEIF ABD ELAZIZ'}
                </span>
                <span className="font-mono text-[10px] text-[#ffb0cd] font-bold truncate block">
                  ceo@91network.online · seifabdelaziz@91network.online
                </span>
              </div>
            </div>
            <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono text-[9px]">
              EGP Retainer
            </span>
          </div>

          {/* Synced Agency Assets */}
          <div className="p-3 rounded-xl bg-[#201f21] border border-[#2a2a2c] space-y-1.5">
            <span className="text-[10px] font-mono text-[#a38a92] uppercase">
              {isAr ? 'الأصول الإبداعية المرتبطة' : 'SYNCED AGENCY ASSETS'}
            </span>
            <div className="flex items-center gap-2 text-xs font-mono text-[#ffb0cd]">
              <span className="material-symbols-outlined text-[15px]">attachment</span>
              <span>FW24_Moodboard_v3.pdf · Dusk_Palette_Alserkal.ase</span>
            </div>
          </div>
        </div>
      </div>

      {/* Sticky Bottom Action Bar */}
      <div className="fixed bottom-0 inset-x-0 z-20 pb-safe bg-[#131315]/95 backdrop-blur-xl border-t border-[#2a2a2c] p-4 shadow-2xl">
        <div className="max-w-xl mx-auto flex items-center justify-between gap-3">
          <button
            onClick={() => setIsBriefModalOpen(false)}
            className="flex-1 py-3 px-4 rounded-xl bg-[#201f21] hover:bg-[#2a2a2c] text-xs font-mono font-bold text-[#dbc0c7] border border-[#2a2a2c] transition-colors cursor-pointer"
          >
            {isAr ? 'حفظ كمسودة' : 'Save Draft'}
          </button>
          <button
            onClick={() => submitBrief()}
            className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-[#ff7bb4] to-[#ffb0cd] text-[#780846] font-headline font-bold text-xs hover:opacity-95 shadow-[0_0_20px_rgba(255,123,180,0.4)] flex items-center justify-center gap-1.5 transition-all cursor-pointer"
          >
            <span className="material-symbols-outlined text-[18px]">send</span>
            <span>{isAr ? 'إرسال الطلب للوكالة' : 'Submit Request to Agency'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
