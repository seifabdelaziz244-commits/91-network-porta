import { Locale } from '../types';

export const formatEGP = (amount: number | string, locale: Locale = 'en'): string => {
  const numericAmount = typeof amount === 'string' ? parseFloat(amount.replace(/[^0-9.-]+/g, '')) : amount;
  
  if (isNaN(numericAmount)) {
    return locale === 'ar' ? `${amount} ج.م` : `${amount} EGP`;
  }

  const formattedNumber = numericAmount.toLocaleString('en-US', {
    minimumFractionDigits: numericAmount % 1 === 0 ? 0 : 2,
    maximumFractionDigits: 2,
  });

  if (locale === 'ar') {
    return `${formattedNumber} ج.م`;
  }
  return `${formattedNumber} EGP`;
};
