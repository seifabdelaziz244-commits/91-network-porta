import { sql } from '@vercel/postgres';

let schemaReady: Promise<void> | null = null;

/**
 * Creates all tables if they don't exist yet. Safe to call on every cold start —
 * uses IF NOT EXISTS everywhere, so it's a cheap no-op once the schema exists.
 * We lazily run this before the first query in each serverless invocation instead
 * of requiring a separate manual migration step.
 */
export function ensureSchema(): Promise<void> {
  if (!schemaReady) {
    schemaReady = (async () => {
      await sql`
        CREATE TABLE IF NOT EXISTS clients (
          id text PRIMARY KEY,
          name text NOT NULL,
          name_ar text NOT NULL,
          industry text,
          industry_ar text,
          location text,
          location_ar text,
          primary_contact text,
          email text,
          phone text,
          retainer_tier text,
          retainer_tier_ar text,
          retainer_amount_egp numeric DEFAULT 0,
          active_deliverables_count integer DEFAULT 0,
          total_deliverables_quota integer DEFAULT 12,
          active_shoots_count integer DEFAULT 0,
          status text DEFAULT 'active',
          badge_color text,
          login_code text UNIQUE,
          due_day integer DEFAULT 1,
          grace_days integer DEFAULT 5,
          payments jsonb DEFAULT '{}'::jsonb,
          excused_months jsonb DEFAULT '[]'::jsonb,
          terminated boolean DEFAULT false,
          created_at timestamptz DEFAULT now()
        );
      `;
      await sql`
        CREATE TABLE IF NOT EXISTS email_logs (
          id text PRIMARY KEY,
          "timestamp" timestamptz DEFAULT now(),
          recipient text,
          subject text,
          client_name text,
          client_id text,
          brief_title text,
          deliverables_requested jsonb DEFAULT '[]'::jsonb,
          specs jsonb DEFAULT '{}'::jsonb,
          status text DEFAULT 'delivered'
        );
      `;
      await sql`
        CREATE TABLE IF NOT EXISTS admin_settings (
          id integer PRIMARY KEY DEFAULT 1,
          admin_email text,
          admin_emails jsonb DEFAULT '[]'::jsonb,
          admin_name text,
          admin_role text,
          agency_name text,
          currency text DEFAULT 'EGP',
          auto_dispatch_email boolean DEFAULT true
        );
      `;
      // Seed a single admin_settings row if none exists yet.
      await sql`
        INSERT INTO admin_settings (id, admin_email, admin_emails, admin_name, admin_role, agency_name, currency, auto_dispatch_email)
        VALUES (
          1,
          'ceo@91network.online, seifabdelaziz@91network.online',
          '["ceo@91network.online","seifabdelaziz@91network.online"]'::jsonb,
          'SEIF ABD ELAZIZ',
          'Founder & CEO / Executive Creative Director',
          '91\` Network Production Agency',
          'EGP',
          true
        )
        ON CONFLICT (id) DO NOTHING;
      `;
    })();
  }
  return schemaReady;
}

export { sql };
